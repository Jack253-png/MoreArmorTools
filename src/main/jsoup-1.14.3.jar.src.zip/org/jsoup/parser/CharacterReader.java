/*     */ package org.jsoup.parser;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javax.annotation.Nullable;
/*     */ import org.jsoup.UncheckedIOException;
/*     */ import org.jsoup.helper.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CharacterReader
/*     */ {
/*     */   static final char EOF = '￿';
/*     */   private static final int maxStringCacheLen = 12;
/*     */   static final int maxBufferLen = 32768;
/*     */   static final int readAheadLimit = 24576;
/*     */   private static final int minReadAheadLen = 1024;
/*     */   private char[] charBuf;
/*     */   private Reader reader;
/*     */   private int bufLength;
/*     */   private int bufSplitPoint;
/*     */   private int bufPos;
/*     */   private int readerPos;
/*  31 */   private int bufMark = -1;
/*     */   private static final int stringCacheSize = 512;
/*  33 */   private String[] stringCache = new String[512];
/*     */   @Nullable
/*  35 */   private ArrayList<Integer> newlinePositions = null;
/*  36 */   private int lineNumberOffset = 1; private boolean readFully;
/*     */   
/*     */   public CharacterReader(Reader input, int sz) {
/*  39 */     Validate.notNull(input);
/*  40 */     Validate.isTrue(input.markSupported());
/*  41 */     this.reader = input;
/*  42 */     this.charBuf = new char[Math.min(sz, 32768)];
/*  43 */     bufferUp();
/*     */   } @Nullable
/*     */   private String lastIcSeq; private int lastIcIndex;
/*     */   public CharacterReader(Reader input) {
/*  47 */     this(input, 32768);
/*     */   }
/*     */   
/*     */   public CharacterReader(String input) {
/*  51 */     this(new StringReader(input), input.length());
/*     */   }
/*     */   
/*     */   public void close() {
/*  55 */     if (this.reader == null)
/*     */       return; 
/*     */     
/*  58 */     try { this.reader.close(); }
/*  59 */     catch (IOException iOException) {  }
/*     */     finally
/*  61 */     { this.reader = null;
/*  62 */       this.charBuf = null;
/*  63 */       this.stringCache = null; }
/*     */   
/*     */   }
/*     */   
/*     */   private void bufferUp() {
/*     */     int pos, offset;
/*  69 */     if (this.readFully || this.bufPos < this.bufSplitPoint) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  74 */     if (this.bufMark != -1) {
/*  75 */       pos = this.bufMark;
/*  76 */       offset = this.bufPos - this.bufMark;
/*     */     } else {
/*  78 */       pos = this.bufPos;
/*  79 */       offset = 0;
/*     */     } 
/*     */     
/*     */     try {
/*  83 */       long skipped = this.reader.skip(pos);
/*  84 */       this.reader.mark(32768);
/*  85 */       int read = 0;
/*  86 */       while (read <= 1024) {
/*  87 */         int thisRead = this.reader.read(this.charBuf, read, this.charBuf.length - read);
/*  88 */         if (thisRead == -1)
/*  89 */           this.readFully = true; 
/*  90 */         if (thisRead <= 0)
/*     */           break; 
/*  92 */         read += thisRead;
/*     */       } 
/*  94 */       this.reader.reset();
/*  95 */       if (read > 0) {
/*  96 */         Validate.isTrue((skipped == pos));
/*  97 */         this.bufLength = read;
/*  98 */         this.readerPos += pos;
/*  99 */         this.bufPos = offset;
/* 100 */         if (this.bufMark != -1)
/* 101 */           this.bufMark = 0; 
/* 102 */         this.bufSplitPoint = Math.min(this.bufLength, 24576);
/*     */       } 
/* 104 */     } catch (IOException e) {
/* 105 */       throw new UncheckedIOException(e);
/*     */     } 
/* 107 */     scanBufferForNewlines();
/* 108 */     this.lastIcSeq = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int pos() {
/* 116 */     return this.readerPos + this.bufPos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trackNewlines(boolean track) {
/* 128 */     if (track && this.newlinePositions == null) {
/* 129 */       this.newlinePositions = new ArrayList<>(409);
/* 130 */       scanBufferForNewlines();
/*     */     }
/* 132 */     else if (!track) {
/* 133 */       this.newlinePositions = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTrackNewlines() {
/* 142 */     return (this.newlinePositions != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lineNumber() {
/* 152 */     if (!isTrackNewlines()) {
/* 153 */       return 1;
/*     */     }
/* 155 */     int i = lineNumIndex();
/* 156 */     if (i == -1)
/* 157 */       return this.lineNumberOffset; 
/* 158 */     if (i < 0)
/* 159 */       return Math.abs(i) + this.lineNumberOffset - 1; 
/* 160 */     return i + this.lineNumberOffset + 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int columnNumber() {
/* 170 */     if (!isTrackNewlines()) {
/* 171 */       return pos() + 1;
/*     */     }
/* 173 */     int i = lineNumIndex();
/* 174 */     if (i == -1)
/* 175 */       return pos() + 1; 
/* 176 */     if (i < 0)
/* 177 */       i = Math.abs(i) - 2; 
/* 178 */     return pos() - ((Integer)this.newlinePositions.get(i)).intValue() + 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String cursorPos() {
/* 189 */     return lineNumber() + ":" + columnNumber();
/*     */   }
/*     */   
/*     */   private int lineNumIndex() {
/* 193 */     if (!isTrackNewlines()) return 0; 
/* 194 */     return Collections.binarySearch((List)this.newlinePositions, Integer.valueOf(pos()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void scanBufferForNewlines() {
/* 201 */     if (!isTrackNewlines()) {
/*     */       return;
/*     */     }
/* 204 */     this.lineNumberOffset += this.newlinePositions.size();
/* 205 */     int lastPos = (this.newlinePositions.size() > 0) ? ((Integer)this.newlinePositions.get(this.newlinePositions.size() - 1)).intValue() : -1;
/* 206 */     this.newlinePositions.clear();
/* 207 */     if (lastPos != -1) {
/* 208 */       this.newlinePositions.add(Integer.valueOf(lastPos));
/* 209 */       this.lineNumberOffset--;
/*     */     } 
/* 211 */     for (int i = this.bufPos; i < this.bufLength; i++) {
/* 212 */       if (this.charBuf[i] == '\n') {
/* 213 */         this.newlinePositions.add(Integer.valueOf(1 + this.readerPos + i));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 222 */     bufferUp();
/* 223 */     return (this.bufPos >= this.bufLength);
/*     */   }
/*     */   
/*     */   private boolean isEmptyNoBufferUp() {
/* 227 */     return (this.bufPos >= this.bufLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char current() {
/* 235 */     bufferUp();
/* 236 */     return isEmptyNoBufferUp() ? Character.MAX_VALUE : this.charBuf[this.bufPos];
/*     */   }
/*     */   
/*     */   char consume() {
/* 240 */     bufferUp();
/* 241 */     char val = isEmptyNoBufferUp() ? Character.MAX_VALUE : this.charBuf[this.bufPos];
/* 242 */     this.bufPos++;
/* 243 */     return val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unconsume() {
/* 250 */     if (this.bufPos < 1) {
/* 251 */       throw new UncheckedIOException(new IOException("WTF: No buffer left to unconsume."));
/*     */     }
/* 253 */     this.bufPos--;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void advance() {
/* 260 */     this.bufPos++;
/*     */   }
/*     */ 
/*     */   
/*     */   void mark() {
/* 265 */     if (this.bufLength - this.bufPos < 1024) {
/* 266 */       this.bufSplitPoint = 0;
/*     */     }
/* 268 */     bufferUp();
/* 269 */     this.bufMark = this.bufPos;
/*     */   }
/*     */   
/*     */   void unmark() {
/* 273 */     this.bufMark = -1;
/*     */   }
/*     */   
/*     */   void rewindToMark() {
/* 277 */     if (this.bufMark == -1) {
/* 278 */       throw new UncheckedIOException(new IOException("Mark invalid"));
/*     */     }
/* 280 */     this.bufPos = this.bufMark;
/* 281 */     unmark();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int nextIndexOf(char c) {
/* 291 */     bufferUp();
/* 292 */     for (int i = this.bufPos; i < this.bufLength; i++) {
/* 293 */       if (c == this.charBuf[i])
/* 294 */         return i - this.bufPos; 
/*     */     } 
/* 296 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int nextIndexOf(CharSequence seq) {
/* 306 */     bufferUp();
/*     */     
/* 308 */     char startChar = seq.charAt(0);
/* 309 */     for (int offset = this.bufPos; offset < this.bufLength; offset++) {
/*     */       
/* 311 */       if (startChar != this.charBuf[offset])
/* 312 */         while (++offset < this.bufLength && startChar != this.charBuf[offset]); 
/* 313 */       int i = offset + 1;
/* 314 */       int last = i + seq.length() - 1;
/* 315 */       if (offset < this.bufLength && last <= this.bufLength) {
/* 316 */         for (int j = 1; i < last && seq.charAt(j) == this.charBuf[i]; ) { i++; j++; }
/* 317 */          if (i == last)
/* 318 */           return offset - this.bufPos; 
/*     */       } 
/*     */     } 
/* 321 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String consumeTo(char c) {
/* 330 */     int offset = nextIndexOf(c);
/* 331 */     if (offset != -1) {
/* 332 */       String consumed = cacheString(this.charBuf, this.stringCache, this.bufPos, offset);
/* 333 */       this.bufPos += offset;
/* 334 */       return consumed;
/*     */     } 
/* 336 */     return consumeToEnd();
/*     */   }
/*     */ 
/*     */   
/*     */   String consumeTo(String seq) {
/* 341 */     int offset = nextIndexOf(seq);
/* 342 */     if (offset != -1) {
/* 343 */       String str = cacheString(this.charBuf, this.stringCache, this.bufPos, offset);
/* 344 */       this.bufPos += offset;
/* 345 */       return str;
/* 346 */     }  if (this.bufLength - this.bufPos < seq.length())
/*     */     {
/* 348 */       return consumeToEnd();
/*     */     }
/*     */ 
/*     */     
/* 352 */     int endPos = this.bufLength - seq.length() + 1;
/* 353 */     String consumed = cacheString(this.charBuf, this.stringCache, this.bufPos, endPos - this.bufPos);
/* 354 */     this.bufPos = endPos;
/* 355 */     return consumed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String consumeToAny(char... chars) {
/* 365 */     bufferUp();
/* 366 */     int pos = this.bufPos;
/* 367 */     int start = pos;
/* 368 */     int remaining = this.bufLength;
/* 369 */     char[] val = this.charBuf;
/* 370 */     int charLen = chars.length;
/*     */ 
/*     */     
/* 373 */     label18: while (pos < remaining) {
/* 374 */       for (int i = 0; i < charLen; i++) {
/* 375 */         if (val[pos] == chars[i])
/*     */           break label18; 
/*     */       } 
/* 378 */       pos++;
/*     */     } 
/*     */     
/* 381 */     this.bufPos = pos;
/* 382 */     return (pos > start) ? cacheString(this.charBuf, this.stringCache, start, pos - start) : "";
/*     */   }
/*     */   
/*     */   String consumeToAnySorted(char... chars) {
/* 386 */     bufferUp();
/* 387 */     int pos = this.bufPos;
/* 388 */     int start = pos;
/* 389 */     int remaining = this.bufLength;
/* 390 */     char[] val = this.charBuf;
/*     */     
/* 392 */     while (pos < remaining && 
/* 393 */       Arrays.binarySearch(chars, val[pos]) < 0)
/*     */     {
/* 395 */       pos++;
/*     */     }
/* 397 */     this.bufPos = pos;
/* 398 */     return (this.bufPos > start) ? cacheString(this.charBuf, this.stringCache, start, pos - start) : "";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   String consumeData() {
/* 404 */     int pos = this.bufPos;
/* 405 */     int start = pos;
/* 406 */     int remaining = this.bufLength;
/* 407 */     char[] val = this.charBuf;
/*     */     
/* 409 */     while (pos < remaining) {
/* 410 */       switch (val[pos]) {
/*     */         case '\000':
/*     */         case '&':
/*     */         case '<':
/*     */           break;
/*     */       } 
/* 416 */       pos++;
/*     */     } 
/*     */     
/* 419 */     this.bufPos = pos;
/* 420 */     return (pos > start) ? cacheString(this.charBuf, this.stringCache, start, pos - start) : "";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   String consumeAttributeQuoted(boolean single) {
/* 426 */     int pos = this.bufPos;
/* 427 */     int start = pos;
/* 428 */     int remaining = this.bufLength;
/* 429 */     char[] val = this.charBuf;
/*     */     
/* 431 */     while (pos < remaining) {
/* 432 */       switch (val[pos]) {
/*     */         case '\000':
/*     */         case '&':
/*     */           break;
/*     */         case '\'':
/* 437 */           if (single)
/*     */             break; 
/* 439 */         case '"': if (!single)
/*     */             break;  break;
/* 441 */       }  pos++;
/*     */     } 
/*     */     
/* 444 */     this.bufPos = pos;
/* 445 */     return (pos > start) ? cacheString(this.charBuf, this.stringCache, start, pos - start) : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String consumeRawData() {
/* 452 */     int pos = this.bufPos;
/* 453 */     int start = pos;
/* 454 */     int remaining = this.bufLength;
/* 455 */     char[] val = this.charBuf;
/*     */     
/* 457 */     while (pos < remaining) {
/* 458 */       switch (val[pos]) {
/*     */         case '\000':
/*     */         case '<':
/*     */           break;
/*     */       } 
/* 463 */       pos++;
/*     */     } 
/*     */     
/* 466 */     this.bufPos = pos;
/* 467 */     return (pos > start) ? cacheString(this.charBuf, this.stringCache, start, pos - start) : "";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   String consumeTagName() {
/* 473 */     bufferUp();
/* 474 */     int pos = this.bufPos;
/* 475 */     int start = pos;
/* 476 */     int remaining = this.bufLength;
/* 477 */     char[] val = this.charBuf;
/*     */     
/* 479 */     while (pos < remaining) {
/* 480 */       switch (val[pos]) {
/*     */         case '\t':
/*     */         case '\n':
/*     */         case '\f':
/*     */         case '\r':
/*     */         case ' ':
/*     */         case '/':
/*     */         case '<':
/*     */         case '>':
/*     */           break;
/*     */       } 
/* 491 */       pos++;
/*     */     } 
/*     */     
/* 494 */     this.bufPos = pos;
/* 495 */     return (pos > start) ? cacheString(this.charBuf, this.stringCache, start, pos - start) : "";
/*     */   }
/*     */   
/*     */   String consumeToEnd() {
/* 499 */     bufferUp();
/* 500 */     String data = cacheString(this.charBuf, this.stringCache, this.bufPos, this.bufLength - this.bufPos);
/* 501 */     this.bufPos = this.bufLength;
/* 502 */     return data;
/*     */   }
/*     */   
/*     */   String consumeLetterSequence() {
/* 506 */     bufferUp();
/* 507 */     int start = this.bufPos;
/* 508 */     while (this.bufPos < this.bufLength) {
/* 509 */       char c = this.charBuf[this.bufPos];
/* 510 */       if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || Character.isLetter(c)) {
/* 511 */         this.bufPos++;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 516 */     return cacheString(this.charBuf, this.stringCache, start, this.bufPos - start);
/*     */   }
/*     */   
/*     */   String consumeLetterThenDigitSequence() {
/* 520 */     bufferUp();
/* 521 */     int start = this.bufPos;
/* 522 */     while (this.bufPos < this.bufLength) {
/* 523 */       char c = this.charBuf[this.bufPos];
/* 524 */       if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || Character.isLetter(c)) {
/* 525 */         this.bufPos++;
/*     */       }
/*     */     } 
/*     */     
/* 529 */     while (!isEmptyNoBufferUp()) {
/* 530 */       char c = this.charBuf[this.bufPos];
/* 531 */       if (c >= '0' && c <= '9') {
/* 532 */         this.bufPos++;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 537 */     return cacheString(this.charBuf, this.stringCache, start, this.bufPos - start);
/*     */   }
/*     */   
/*     */   String consumeHexSequence() {
/* 541 */     bufferUp();
/* 542 */     int start = this.bufPos;
/* 543 */     while (this.bufPos < this.bufLength) {
/* 544 */       char c = this.charBuf[this.bufPos];
/* 545 */       if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f')) {
/* 546 */         this.bufPos++;
/*     */       }
/*     */     } 
/*     */     
/* 550 */     return cacheString(this.charBuf, this.stringCache, start, this.bufPos - start);
/*     */   }
/*     */   
/*     */   String consumeDigitSequence() {
/* 554 */     bufferUp();
/* 555 */     int start = this.bufPos;
/* 556 */     while (this.bufPos < this.bufLength) {
/* 557 */       char c = this.charBuf[this.bufPos];
/* 558 */       if (c >= '0' && c <= '9') {
/* 559 */         this.bufPos++;
/*     */       }
/*     */     } 
/*     */     
/* 563 */     return cacheString(this.charBuf, this.stringCache, start, this.bufPos - start);
/*     */   }
/*     */   
/*     */   boolean matches(char c) {
/* 567 */     return (!isEmpty() && this.charBuf[this.bufPos] == c);
/*     */   }
/*     */ 
/*     */   
/*     */   boolean matches(String seq) {
/* 572 */     bufferUp();
/* 573 */     int scanLength = seq.length();
/* 574 */     if (scanLength > this.bufLength - this.bufPos) {
/* 575 */       return false;
/*     */     }
/* 577 */     for (int offset = 0; offset < scanLength; offset++) {
/* 578 */       if (seq.charAt(offset) != this.charBuf[this.bufPos + offset])
/* 579 */         return false; 
/* 580 */     }  return true;
/*     */   }
/*     */   
/*     */   boolean matchesIgnoreCase(String seq) {
/* 584 */     bufferUp();
/* 585 */     int scanLength = seq.length();
/* 586 */     if (scanLength > this.bufLength - this.bufPos) {
/* 587 */       return false;
/*     */     }
/* 589 */     for (int offset = 0; offset < scanLength; offset++) {
/* 590 */       char upScan = Character.toUpperCase(seq.charAt(offset));
/* 591 */       char upTarget = Character.toUpperCase(this.charBuf[this.bufPos + offset]);
/* 592 */       if (upScan != upTarget)
/* 593 */         return false; 
/*     */     } 
/* 595 */     return true;
/*     */   }
/*     */   
/*     */   boolean matchesAny(char... seq) {
/* 599 */     if (isEmpty()) {
/* 600 */       return false;
/*     */     }
/* 602 */     bufferUp();
/* 603 */     char c = this.charBuf[this.bufPos];
/* 604 */     for (char seek : seq) {
/* 605 */       if (seek == c)
/* 606 */         return true; 
/*     */     } 
/* 608 */     return false;
/*     */   }
/*     */   
/*     */   boolean matchesAnySorted(char[] seq) {
/* 612 */     bufferUp();
/* 613 */     return (!isEmpty() && Arrays.binarySearch(seq, this.charBuf[this.bufPos]) >= 0);
/*     */   }
/*     */   
/*     */   boolean matchesLetter() {
/* 617 */     if (isEmpty())
/* 618 */       return false; 
/* 619 */     char c = this.charBuf[this.bufPos];
/* 620 */     return ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || Character.isLetter(c));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean matchesAsciiAlpha() {
/* 628 */     if (isEmpty())
/* 629 */       return false; 
/* 630 */     char c = this.charBuf[this.bufPos];
/* 631 */     return ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'));
/*     */   }
/*     */   
/*     */   boolean matchesDigit() {
/* 635 */     if (isEmpty())
/* 636 */       return false; 
/* 637 */     char c = this.charBuf[this.bufPos];
/* 638 */     return (c >= '0' && c <= '9');
/*     */   }
/*     */   
/*     */   boolean matchConsume(String seq) {
/* 642 */     bufferUp();
/* 643 */     if (matches(seq)) {
/* 644 */       this.bufPos += seq.length();
/* 645 */       return true;
/*     */     } 
/* 647 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean matchConsumeIgnoreCase(String seq) {
/* 652 */     if (matchesIgnoreCase(seq)) {
/* 653 */       this.bufPos += seq.length();
/* 654 */       return true;
/*     */     } 
/* 656 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean containsIgnoreCase(String seq) {
/* 668 */     if (seq.equals(this.lastIcSeq)) {
/* 669 */       if (this.lastIcIndex == -1) return false; 
/* 670 */       if (this.lastIcIndex >= this.bufPos) return true; 
/*     */     } 
/* 672 */     this.lastIcSeq = seq;
/*     */     
/* 674 */     String loScan = seq.toLowerCase(Locale.ENGLISH);
/* 675 */     int lo = nextIndexOf(loScan);
/* 676 */     if (lo > -1) {
/* 677 */       this.lastIcIndex = this.bufPos + lo; return true;
/*     */     } 
/*     */     
/* 680 */     String hiScan = seq.toUpperCase(Locale.ENGLISH);
/* 681 */     int hi = nextIndexOf(hiScan);
/* 682 */     boolean found = (hi > -1);
/* 683 */     this.lastIcIndex = found ? (this.bufPos + hi) : -1;
/* 684 */     return found;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 689 */     if (this.bufLength - this.bufPos < 0)
/* 690 */       return ""; 
/* 691 */     return new String(this.charBuf, this.bufPos, this.bufLength - this.bufPos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String cacheString(char[] charBuf, String[] stringCache, int start, int count) {
/* 703 */     if (count > 12)
/* 704 */       return new String(charBuf, start, count); 
/* 705 */     if (count < 1) {
/* 706 */       return "";
/*     */     }
/*     */     
/* 709 */     int hash = 0;
/* 710 */     for (int i = 0; i < count; i++) {
/* 711 */       hash = 31 * hash + charBuf[start + i];
/*     */     }
/*     */ 
/*     */     
/* 715 */     int index = hash & 0x1FF;
/* 716 */     String cached = stringCache[index];
/*     */     
/* 718 */     if (cached != null && rangeEquals(charBuf, start, count, cached)) {
/* 719 */       return cached;
/*     */     }
/* 721 */     cached = new String(charBuf, start, count);
/* 722 */     stringCache[index] = cached;
/*     */ 
/*     */     
/* 725 */     return cached;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean rangeEquals(char[] charBuf, int start, int count, String cached) {
/* 732 */     if (count == cached.length()) {
/* 733 */       int i = start;
/* 734 */       int j = 0;
/* 735 */       while (count-- != 0) {
/* 736 */         if (charBuf[i++] != cached.charAt(j++))
/* 737 */           return false; 
/*     */       } 
/* 739 */       return true;
/*     */     } 
/* 741 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean rangeEquals(int start, int count, String cached) {
/* 746 */     return rangeEquals(this.charBuf, start, count, cached);
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\parser\CharacterReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */