/*     */ package org.jsoup.parser;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import javax.annotation.ParametersAreNonnullByDefault;
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.internal.StringUtil;
/*     */ import org.jsoup.nodes.Attributes;
/*     */ import org.jsoup.nodes.CDataNode;
/*     */ import org.jsoup.nodes.Comment;
/*     */ import org.jsoup.nodes.DataNode;
/*     */ import org.jsoup.nodes.Document;
/*     */ import org.jsoup.nodes.Element;
/*     */ import org.jsoup.nodes.FormElement;
/*     */ import org.jsoup.nodes.Node;
/*     */ import org.jsoup.nodes.TextNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HtmlTreeBuilder
/*     */   extends TreeBuilder
/*     */ {
/*  29 */   static final String[] TagsSearchInScope = new String[] { "applet", "caption", "html", "marquee", "object", "table", "td", "th" };
/*  30 */   static final String[] TagSearchList = new String[] { "ol", "ul" };
/*  31 */   static final String[] TagSearchButton = new String[] { "button" };
/*  32 */   static final String[] TagSearchTableScope = new String[] { "html", "table" };
/*  33 */   static final String[] TagSearchSelectScope = new String[] { "optgroup", "option" };
/*  34 */   static final String[] TagSearchEndTags = new String[] { "dd", "dt", "li", "optgroup", "option", "p", "rb", "rp", "rt", "rtc" };
/*  35 */   static final String[] TagThoroughSearchEndTags = new String[] { "caption", "colgroup", "dd", "dt", "li", "optgroup", "option", "p", "rb", "rp", "rt", "rtc", "tbody", "td", "tfoot", "th", "thead", "tr" };
/*  36 */   static final String[] TagSearchSpecial = new String[] { "address", "applet", "area", "article", "aside", "base", "basefont", "bgsound", "blockquote", "body", "br", "button", "caption", "center", "col", "colgroup", "command", "dd", "details", "dir", "div", "dl", "dt", "embed", "fieldset", "figcaption", "figure", "footer", "form", "frame", "frameset", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "iframe", "img", "input", "isindex", "li", "link", "listing", "marquee", "menu", "meta", "nav", "noembed", "noframes", "noscript", "object", "ol", "p", "param", "plaintext", "pre", "script", "section", "select", "style", "summary", "table", "tbody", "td", "textarea", "tfoot", "th", "thead", "title", "tr", "ul", "wbr", "xmp" };
/*     */   
/*     */   public static final int MaxScopeSearchDepth = 100;
/*     */   
/*     */   private HtmlTreeBuilderState state;
/*     */   
/*     */   private HtmlTreeBuilderState originalState;
/*     */   
/*     */   private boolean baseUriSetFromDoc;
/*     */   
/*     */   @Nullable
/*     */   private Element headElement;
/*     */   
/*     */   @Nullable
/*     */   private FormElement formElement;
/*     */   
/*     */   @Nullable
/*     */   private Element contextElement;
/*     */   private ArrayList<Element> formattingElements;
/*     */   private ArrayList<HtmlTreeBuilderState> tmplInsertMode;
/*     */   private List<String> pendingTableCharacters;
/*     */   private Token.EndTag emptyEnd;
/*     */   private boolean framesetOk;
/*     */   private boolean fosterInserts;
/*     */   private boolean fragmentParsing;
/*     */   private static final int maxQueueDepth = 256;
/*     */   
/*     */   ParseSettings defaultSettings() {
/*  64 */     return ParseSettings.htmlDefault;
/*     */   }
/*     */ 
/*     */   
/*     */   HtmlTreeBuilder newInstance() {
/*  69 */     return new HtmlTreeBuilder();
/*     */   }
/*     */   
/*     */   @ParametersAreNonnullByDefault
/*     */   protected void initialiseParse(Reader input, String baseUri, Parser parser) {
/*  74 */     super.initialiseParse(input, baseUri, parser);
/*     */ 
/*     */     
/*  77 */     this.state = HtmlTreeBuilderState.Initial;
/*  78 */     this.originalState = null;
/*  79 */     this.baseUriSetFromDoc = false;
/*  80 */     this.headElement = null;
/*  81 */     this.formElement = null;
/*  82 */     this.contextElement = null;
/*  83 */     this.formattingElements = new ArrayList<>();
/*  84 */     this.tmplInsertMode = new ArrayList<>();
/*  85 */     this.pendingTableCharacters = new ArrayList<>();
/*  86 */     this.emptyEnd = new Token.EndTag();
/*  87 */     this.framesetOk = true;
/*  88 */     this.fosterInserts = false;
/*  89 */     this.fragmentParsing = false;
/*     */   }
/*     */ 
/*     */   
/*     */   List<Node> parseFragment(String inputFragment, @Nullable Element context, String baseUri, Parser parser) {
/*  94 */     this.state = HtmlTreeBuilderState.Initial;
/*  95 */     initialiseParse(new StringReader(inputFragment), baseUri, parser);
/*  96 */     this.contextElement = context;
/*  97 */     this.fragmentParsing = true;
/*  98 */     Element root = null;
/*     */     
/* 100 */     if (context != null) {
/* 101 */       if (context.ownerDocument() != null) {
/* 102 */         this.doc.quirksMode(context.ownerDocument().quirksMode());
/*     */       }
/*     */       
/* 105 */       String contextTag = context.normalName();
/* 106 */       switch (contextTag) {
/*     */         case "title":
/*     */         case "textarea":
/* 109 */           this.tokeniser.transition(TokeniserState.Rcdata);
/*     */           break;
/*     */         case "iframe":
/*     */         case "noembed":
/*     */         case "noframes":
/*     */         case "style":
/*     */         case "xml":
/* 116 */           this.tokeniser.transition(TokeniserState.Rawtext);
/*     */           break;
/*     */         case "script":
/* 119 */           this.tokeniser.transition(TokeniserState.ScriptData);
/*     */           break;
/*     */         case "noscript":
/* 122 */           this.tokeniser.transition(TokeniserState.Data);
/*     */           break;
/*     */         case "plaintext":
/* 125 */           this.tokeniser.transition(TokeniserState.PLAINTEXT);
/*     */           break;
/*     */         case "template":
/* 128 */           this.tokeniser.transition(TokeniserState.Data);
/* 129 */           pushTemplateMode(HtmlTreeBuilderState.InTemplate);
/*     */           break;
/*     */         default:
/* 132 */           this.tokeniser.transition(TokeniserState.Data); break;
/*     */       } 
/* 134 */       root = new Element(tagFor(contextTag, this.settings), baseUri);
/* 135 */       this.doc.appendChild((Node)root);
/* 136 */       this.stack.add(root);
/* 137 */       resetInsertionMode();
/*     */ 
/*     */ 
/*     */       
/* 141 */       Element formSearch = context;
/* 142 */       while (formSearch != null) {
/* 143 */         if (formSearch instanceof FormElement) {
/* 144 */           this.formElement = (FormElement)formSearch;
/*     */           break;
/*     */         } 
/* 147 */         formSearch = formSearch.parent();
/*     */       } 
/*     */     } 
/*     */     
/* 151 */     runParser();
/* 152 */     if (context != null) {
/*     */ 
/*     */       
/* 155 */       List<Node> nodes = root.siblingNodes();
/* 156 */       if (!nodes.isEmpty())
/* 157 */         root.insertChildren(-1, nodes); 
/* 158 */       return root.childNodes();
/*     */     } 
/*     */     
/* 161 */     return this.doc.childNodes();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean process(Token token) {
/* 166 */     this.currentToken = token;
/* 167 */     return this.state.process(token, this);
/*     */   }
/*     */   
/*     */   boolean process(Token token, HtmlTreeBuilderState state) {
/* 171 */     this.currentToken = token;
/* 172 */     return state.process(token, this);
/*     */   }
/*     */   
/*     */   void transition(HtmlTreeBuilderState state) {
/* 176 */     this.state = state;
/*     */   }
/*     */   
/*     */   HtmlTreeBuilderState state() {
/* 180 */     return this.state;
/*     */   }
/*     */   
/*     */   void markInsertionMode() {
/* 184 */     this.originalState = this.state;
/*     */   }
/*     */   
/*     */   HtmlTreeBuilderState originalState() {
/* 188 */     return this.originalState;
/*     */   }
/*     */   
/*     */   void framesetOk(boolean framesetOk) {
/* 192 */     this.framesetOk = framesetOk;
/*     */   }
/*     */   
/*     */   boolean framesetOk() {
/* 196 */     return this.framesetOk;
/*     */   }
/*     */   
/*     */   Document getDocument() {
/* 200 */     return this.doc;
/*     */   }
/*     */   
/*     */   String getBaseUri() {
/* 204 */     return this.baseUri;
/*     */   }
/*     */   
/*     */   void maybeSetBaseUri(Element base) {
/* 208 */     if (this.baseUriSetFromDoc) {
/*     */       return;
/*     */     }
/* 211 */     String href = base.absUrl("href");
/* 212 */     if (href.length() != 0) {
/* 213 */       this.baseUri = href;
/* 214 */       this.baseUriSetFromDoc = true;
/* 215 */       this.doc.setBaseUri(href);
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean isFragmentParsing() {
/* 220 */     return this.fragmentParsing;
/*     */   }
/*     */   
/*     */   void error(HtmlTreeBuilderState state) {
/* 224 */     if (this.parser.getErrors().canAddError()) {
/* 225 */       this.parser.getErrors().add(new ParseError(this.reader, "Unexpected %s token [%s] when in state [%s]", new Object[] { this.currentToken
/* 226 */               .tokenType(), this.currentToken, state }));
/*     */     }
/*     */   }
/*     */   
/*     */   Element insert(Token.StartTag startTag) {
/* 231 */     if (startTag.hasAttributes() && !startTag.attributes.isEmpty()) {
/* 232 */       int dupes = startTag.attributes.deduplicate(this.settings);
/* 233 */       if (dupes > 0) {
/* 234 */         error("Dropped duplicate attribute(s) in tag [%s]", new Object[] { startTag.normalName });
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 240 */     if (startTag.isSelfClosing()) {
/* 241 */       Element element = insertEmpty(startTag);
/* 242 */       this.stack.add(element);
/* 243 */       this.tokeniser.transition(TokeniserState.Data);
/* 244 */       this.tokeniser.emit(this.emptyEnd.reset().name(element.tagName()));
/* 245 */       return element;
/*     */     } 
/*     */     
/* 248 */     Element el = new Element(tagFor(startTag.name(), this.settings), null, this.settings.normalizeAttributes(startTag.attributes));
/* 249 */     insert(el);
/* 250 */     return el;
/*     */   }
/*     */   
/*     */   Element insertStartTag(String startTagName) {
/* 254 */     Element el = new Element(tagFor(startTagName, this.settings), null);
/* 255 */     insert(el);
/* 256 */     return el;
/*     */   }
/*     */   
/*     */   void insert(Element el) {
/* 260 */     insertNode((Node)el);
/* 261 */     this.stack.add(el);
/*     */   }
/*     */   
/*     */   Element insertEmpty(Token.StartTag startTag) {
/* 265 */     Tag tag = tagFor(startTag.name(), this.settings);
/* 266 */     Element el = new Element(tag, null, this.settings.normalizeAttributes(startTag.attributes));
/* 267 */     insertNode((Node)el);
/* 268 */     if (startTag.isSelfClosing())
/* 269 */       if (tag.isKnownTag()) {
/* 270 */         if (!tag.isEmpty()) {
/* 271 */           this.tokeniser.error("Tag [%s] cannot be self closing; not a void tag", new Object[] { tag.normalName() });
/*     */         }
/*     */       } else {
/* 274 */         tag.setSelfClosing();
/*     */       }  
/* 276 */     return el;
/*     */   }
/*     */   
/*     */   FormElement insertForm(Token.StartTag startTag, boolean onStack, boolean checkTemplateStack) {
/* 280 */     Tag tag = tagFor(startTag.name(), this.settings);
/* 281 */     FormElement el = new FormElement(tag, null, this.settings.normalizeAttributes(startTag.attributes));
/* 282 */     if (checkTemplateStack) {
/* 283 */       if (!onStack("template"))
/* 284 */         setFormElement(el); 
/*     */     } else {
/* 286 */       setFormElement(el);
/*     */     } 
/* 288 */     insertNode((Node)el);
/* 289 */     if (onStack)
/* 290 */       this.stack.add(el); 
/* 291 */     return el;
/*     */   }
/*     */   
/*     */   void insert(Token.Comment commentToken) {
/* 295 */     Comment comment = new Comment(commentToken.getData());
/* 296 */     insertNode((Node)comment);
/*     */   }
/*     */   
/*     */   void insert(Token.Character characterToken) {
/*     */     TextNode textNode;
/* 301 */     Element el = currentElement();
/* 302 */     String tagName = el.normalName();
/* 303 */     String data = characterToken.getData();
/*     */     
/* 305 */     if (characterToken.isCData()) {
/* 306 */       CDataNode cDataNode = new CDataNode(data);
/* 307 */     } else if (isContentForTagData(tagName)) {
/* 308 */       DataNode dataNode = new DataNode(data);
/*     */     } else {
/* 310 */       textNode = new TextNode(data);
/* 311 */     }  el.appendChild((Node)textNode);
/*     */   }
/*     */ 
/*     */   
/*     */   private void insertNode(Node node) {
/* 316 */     if (this.stack.isEmpty()) {
/* 317 */       this.doc.appendChild(node);
/* 318 */     } else if (isFosterInserts() && StringUtil.inSorted(currentElement().normalName(), HtmlTreeBuilderState.Constants.InTableFoster)) {
/* 319 */       insertInFosterParent(node);
/*     */     } else {
/* 321 */       currentElement().appendChild(node);
/*     */     } 
/*     */     
/* 324 */     if (node instanceof Element && ((Element)node).tag().isFormListed() && 
/* 325 */       this.formElement != null) {
/* 326 */       this.formElement.addElement((Element)node);
/*     */     }
/*     */   }
/*     */   
/*     */   Element pop() {
/* 331 */     int size = this.stack.size();
/* 332 */     return this.stack.remove(size - 1);
/*     */   }
/*     */   
/*     */   void push(Element element) {
/* 336 */     this.stack.add(element);
/*     */   }
/*     */   
/*     */   ArrayList<Element> getStack() {
/* 340 */     return this.stack;
/*     */   }
/*     */   
/*     */   boolean onStack(Element el) {
/* 344 */     return onStack(this.stack, el);
/*     */   }
/*     */   
/*     */   boolean onStack(String elName) {
/* 348 */     return (getFromStack(elName) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean onStack(ArrayList<Element> queue, Element element) {
/* 353 */     int bottom = queue.size() - 1;
/* 354 */     int upper = (bottom >= 256) ? (bottom - 256) : 0;
/* 355 */     for (int pos = bottom; pos >= upper; pos--) {
/* 356 */       Element next = queue.get(pos);
/* 357 */       if (next == element) {
/* 358 */         return true;
/*     */       }
/*     */     } 
/* 361 */     return false;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   Element getFromStack(String elName) {
/* 366 */     int bottom = this.stack.size() - 1;
/* 367 */     int upper = (bottom >= 256) ? (bottom - 256) : 0;
/* 368 */     for (int pos = bottom; pos >= upper; pos--) {
/* 369 */       Element next = this.stack.get(pos);
/* 370 */       if (next.normalName().equals(elName)) {
/* 371 */         return next;
/*     */       }
/*     */     } 
/* 374 */     return null;
/*     */   }
/*     */   
/*     */   boolean removeFromStack(Element el) {
/* 378 */     for (int pos = this.stack.size() - 1; pos >= 0; pos--) {
/* 379 */       Element next = this.stack.get(pos);
/* 380 */       if (next == el) {
/* 381 */         this.stack.remove(pos);
/* 382 */         return true;
/*     */       } 
/*     */     } 
/* 385 */     return false;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   Element popStackToClose(String elName) {
/* 390 */     for (int pos = this.stack.size() - 1; pos >= 0; pos--) {
/* 391 */       Element el = this.stack.get(pos);
/* 392 */       this.stack.remove(pos);
/* 393 */       if (el.normalName().equals(elName))
/* 394 */         return el; 
/*     */     } 
/* 396 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   void popStackToClose(String... elNames) {
/* 401 */     for (int pos = this.stack.size() - 1; pos >= 0; pos--) {
/* 402 */       Element next = this.stack.get(pos);
/* 403 */       this.stack.remove(pos);
/* 404 */       if (StringUtil.inSorted(next.normalName(), elNames))
/*     */         break; 
/*     */     } 
/*     */   }
/*     */   
/*     */   void popStackToBefore(String elName) {
/* 410 */     for (int pos = this.stack.size() - 1; pos >= 0; pos--) {
/* 411 */       Element next = this.stack.get(pos);
/* 412 */       if (next.normalName().equals(elName)) {
/*     */         break;
/*     */       }
/* 415 */       this.stack.remove(pos);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void clearStackToTableContext() {
/* 421 */     clearStackToContext(new String[] { "table", "template" });
/*     */   }
/*     */   
/*     */   void clearStackToTableBodyContext() {
/* 425 */     clearStackToContext(new String[] { "tbody", "tfoot", "thead", "template" });
/*     */   }
/*     */   
/*     */   void clearStackToTableRowContext() {
/* 429 */     clearStackToContext(new String[] { "tr", "template" });
/*     */   }
/*     */   
/*     */   private void clearStackToContext(String... nodeNames) {
/* 433 */     for (int pos = this.stack.size() - 1; pos >= 0; pos--) {
/* 434 */       Element next = this.stack.get(pos);
/* 435 */       if (StringUtil.in(next.normalName(), nodeNames) || next.normalName().equals("html")) {
/*     */         break;
/*     */       }
/* 438 */       this.stack.remove(pos);
/*     */     } 
/*     */   }
/*     */   @Nullable
/*     */   Element aboveOnStack(Element el) {
/* 443 */     assert onStack(el);
/* 444 */     for (int pos = this.stack.size() - 1; pos >= 0; pos--) {
/* 445 */       Element next = this.stack.get(pos);
/* 446 */       if (next == el) {
/* 447 */         return this.stack.get(pos - 1);
/*     */       }
/*     */     } 
/* 450 */     return null;
/*     */   }
/*     */   
/*     */   void insertOnStackAfter(Element after, Element in) {
/* 454 */     int i = this.stack.lastIndexOf(after);
/* 455 */     Validate.isTrue((i != -1));
/* 456 */     this.stack.add(i + 1, in);
/*     */   }
/*     */   
/*     */   void replaceOnStack(Element out, Element in) {
/* 460 */     replaceInQueue(this.stack, out, in);
/*     */   }
/*     */   
/*     */   private void replaceInQueue(ArrayList<Element> queue, Element out, Element in) {
/* 464 */     int i = queue.lastIndexOf(out);
/* 465 */     Validate.isTrue((i != -1));
/* 466 */     queue.set(i, in);
/*     */   }
/*     */ 
/*     */   
/*     */   void resetInsertionMode() {
/* 471 */     boolean last = false;
/* 472 */     int bottom = this.stack.size() - 1;
/* 473 */     int upper = (bottom >= 256) ? (bottom - 256) : 0;
/*     */     
/* 475 */     if (this.stack.size() == 0) {
/* 476 */       transition(HtmlTreeBuilderState.InBody);
/*     */     }
/*     */     
/* 479 */     for (int pos = bottom; pos >= upper; pos--) {
/* 480 */       HtmlTreeBuilderState tmplState; Element node = this.stack.get(pos);
/* 481 */       if (pos == upper) {
/* 482 */         last = true;
/* 483 */         if (this.fragmentParsing)
/* 484 */           node = this.contextElement; 
/*     */       } 
/* 486 */       String name = (node != null) ? node.normalName() : "";
/* 487 */       switch (name) {
/*     */         case "select":
/* 489 */           transition(HtmlTreeBuilderState.InSelect);
/*     */           break;
/*     */         
/*     */         case "td":
/*     */         case "th":
/* 494 */           if (!last) {
/* 495 */             transition(HtmlTreeBuilderState.InCell);
/*     */             break;
/*     */           } 
/*     */           break;
/*     */         case "tr":
/* 500 */           transition(HtmlTreeBuilderState.InRow);
/*     */           break;
/*     */         case "tbody":
/*     */         case "thead":
/*     */         case "tfoot":
/* 505 */           transition(HtmlTreeBuilderState.InTableBody);
/*     */           break;
/*     */         case "caption":
/* 508 */           transition(HtmlTreeBuilderState.InCaption);
/*     */           break;
/*     */         case "colgroup":
/* 511 */           transition(HtmlTreeBuilderState.InColumnGroup);
/*     */           break;
/*     */         case "table":
/* 514 */           transition(HtmlTreeBuilderState.InTable);
/*     */           break;
/*     */         case "template":
/* 517 */           tmplState = currentTemplateMode();
/* 518 */           Validate.notNull(tmplState, "Bug: no template insertion mode on stack!");
/* 519 */           transition(tmplState);
/*     */           break;
/*     */         case "head":
/* 522 */           if (!last) {
/* 523 */             transition(HtmlTreeBuilderState.InHead);
/*     */             break;
/*     */           } 
/*     */           break;
/*     */         case "body":
/* 528 */           transition(HtmlTreeBuilderState.InBody);
/*     */           break;
/*     */         case "frameset":
/* 531 */           transition(HtmlTreeBuilderState.InFrameset);
/*     */           break;
/*     */         case "html":
/* 534 */           transition((this.headElement == null) ? HtmlTreeBuilderState.BeforeHead : HtmlTreeBuilderState.AfterHead);
/*     */           break;
/*     */       } 
/* 537 */       if (last) {
/* 538 */         transition(HtmlTreeBuilderState.InBody);
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 545 */   private String[] specificScopeTarget = new String[] { null }; private static final int maxUsedFormattingElements = 12;
/*     */   
/*     */   private boolean inSpecificScope(String targetName, String[] baseTypes, String[] extraTypes) {
/* 548 */     this.specificScopeTarget[0] = targetName;
/* 549 */     return inSpecificScope(this.specificScopeTarget, baseTypes, extraTypes);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean inSpecificScope(String[] targetNames, String[] baseTypes, String[] extraTypes) {
/* 554 */     int bottom = this.stack.size() - 1;
/* 555 */     int top = (bottom > 100) ? (bottom - 100) : 0;
/*     */ 
/*     */     
/* 558 */     for (int pos = bottom; pos >= top; pos--) {
/* 559 */       String elName = ((Element)this.stack.get(pos)).normalName();
/* 560 */       if (StringUtil.inSorted(elName, targetNames))
/* 561 */         return true; 
/* 562 */       if (StringUtil.inSorted(elName, baseTypes))
/* 563 */         return false; 
/* 564 */       if (extraTypes != null && StringUtil.inSorted(elName, extraTypes)) {
/* 565 */         return false;
/*     */       }
/*     */     } 
/* 568 */     return false;
/*     */   }
/*     */   
/*     */   boolean inScope(String[] targetNames) {
/* 572 */     return inSpecificScope(targetNames, TagsSearchInScope, (String[])null);
/*     */   }
/*     */   
/*     */   boolean inScope(String targetName) {
/* 576 */     return inScope(targetName, (String[])null);
/*     */   }
/*     */   
/*     */   boolean inScope(String targetName, String[] extras) {
/* 580 */     return inSpecificScope(targetName, TagsSearchInScope, extras);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean inListItemScope(String targetName) {
/* 586 */     return inScope(targetName, TagSearchList);
/*     */   }
/*     */   
/*     */   boolean inButtonScope(String targetName) {
/* 590 */     return inScope(targetName, TagSearchButton);
/*     */   }
/*     */   
/*     */   boolean inTableScope(String targetName) {
/* 594 */     return inSpecificScope(targetName, TagSearchTableScope, (String[])null);
/*     */   }
/*     */   
/*     */   boolean inSelectScope(String targetName) {
/* 598 */     for (int pos = this.stack.size() - 1; pos >= 0; pos--) {
/* 599 */       Element el = this.stack.get(pos);
/* 600 */       String elName = el.normalName();
/* 601 */       if (elName.equals(targetName))
/* 602 */         return true; 
/* 603 */       if (!StringUtil.inSorted(elName, TagSearchSelectScope))
/* 604 */         return false; 
/*     */     } 
/* 606 */     Validate.fail("Should not be reachable");
/* 607 */     return false;
/*     */   }
/*     */   
/*     */   void setHeadElement(Element headElement) {
/* 611 */     this.headElement = headElement;
/*     */   }
/*     */   
/*     */   Element getHeadElement() {
/* 615 */     return this.headElement;
/*     */   }
/*     */   
/*     */   boolean isFosterInserts() {
/* 619 */     return this.fosterInserts;
/*     */   }
/*     */   
/*     */   void setFosterInserts(boolean fosterInserts) {
/* 623 */     this.fosterInserts = fosterInserts;
/*     */   }
/*     */   @Nullable
/*     */   FormElement getFormElement() {
/* 627 */     return this.formElement;
/*     */   }
/*     */   
/*     */   void setFormElement(FormElement formElement) {
/* 631 */     this.formElement = formElement;
/*     */   }
/*     */   
/*     */   void newPendingTableCharacters() {
/* 635 */     this.pendingTableCharacters = new ArrayList<>();
/*     */   }
/*     */   
/*     */   List<String> getPendingTableCharacters() {
/* 639 */     return this.pendingTableCharacters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void generateImpliedEndTags(String excludeTag) {
/* 654 */     while (StringUtil.inSorted(currentElement().normalName(), TagSearchEndTags) && (
/* 655 */       excludeTag == null || !currentElementIs(excludeTag)))
/*     */     {
/* 657 */       pop();
/*     */     }
/*     */   }
/*     */   
/*     */   void generateImpliedEndTags() {
/* 662 */     generateImpliedEndTags(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void generateImpliedEndTags(boolean thorough) {
/* 670 */     String[] search = thorough ? TagThoroughSearchEndTags : TagSearchEndTags;
/* 671 */     while (StringUtil.inSorted(currentElement().normalName(), search)) {
/* 672 */       pop();
/*     */     }
/*     */   }
/*     */   
/*     */   void closeElement(String name) {
/* 677 */     generateImpliedEndTags(name);
/* 678 */     if (!name.equals(currentElement().normalName())) error(state()); 
/* 679 */     popStackToClose(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSpecial(Element el) {
/* 685 */     String name = el.normalName();
/* 686 */     return StringUtil.inSorted(name, TagSearchSpecial);
/*     */   }
/*     */   
/*     */   Element lastFormattingElement() {
/* 690 */     return (this.formattingElements.size() > 0) ? this.formattingElements.get(this.formattingElements.size() - 1) : null;
/*     */   }
/*     */   
/*     */   int positionOfElement(Element el) {
/* 694 */     for (int i = 0; i < this.formattingElements.size(); i++) {
/* 695 */       if (el == this.formattingElements.get(i))
/* 696 */         return i; 
/*     */     } 
/* 698 */     return -1;
/*     */   }
/*     */   
/*     */   Element removeLastFormattingElement() {
/* 702 */     int size = this.formattingElements.size();
/* 703 */     if (size > 0) {
/* 704 */       return this.formattingElements.remove(size - 1);
/*     */     }
/* 706 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   void pushActiveFormattingElements(Element in) {
/* 711 */     checkActiveFormattingElements(in);
/* 712 */     this.formattingElements.add(in);
/*     */   }
/*     */   
/*     */   void pushWithBookmark(Element in, int bookmark) {
/* 716 */     checkActiveFormattingElements(in);
/*     */     
/*     */     try {
/* 719 */       this.formattingElements.add(bookmark, in);
/* 720 */     } catch (IndexOutOfBoundsException e) {
/* 721 */       this.formattingElements.add(in);
/*     */     } 
/*     */   }
/*     */   
/*     */   void checkActiveFormattingElements(Element in) {
/* 726 */     int numSeen = 0;
/* 727 */     for (int pos = this.formattingElements.size() - 1; pos >= 0; pos--) {
/* 728 */       Element el = this.formattingElements.get(pos);
/* 729 */       if (el == null) {
/*     */         break;
/*     */       }
/* 732 */       if (isSameFormattingElement(in, el)) {
/* 733 */         numSeen++;
/*     */       }
/* 735 */       if (numSeen == 3) {
/* 736 */         this.formattingElements.remove(pos);
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isSameFormattingElement(Element a, Element b) {
/* 744 */     return (a.normalName().equals(b.normalName()) && a
/*     */       
/* 746 */       .attributes().equals(b.attributes()));
/*     */   }
/*     */ 
/*     */   
/*     */   void reconstructFormattingElements() {
/* 751 */     Element last = lastFormattingElement();
/* 752 */     if (last == null || onStack(last)) {
/*     */       return;
/*     */     }
/* 755 */     Element entry = last;
/* 756 */     int size = this.formattingElements.size();
/* 757 */     int ceil = size - 12; if (ceil < 0) ceil = 0; 
/* 758 */     int pos = size - 1;
/* 759 */     boolean skip = false;
/*     */     do {
/* 761 */       if (pos == ceil) {
/* 762 */         skip = true;
/*     */         break;
/*     */       } 
/* 765 */       entry = this.formattingElements.get(--pos);
/* 766 */     } while (entry != null && !onStack(entry));
/*     */ 
/*     */     
/*     */     do {
/* 770 */       if (!skip)
/* 771 */         entry = this.formattingElements.get(++pos); 
/* 772 */       Validate.notNull(entry);
/*     */ 
/*     */       
/* 775 */       skip = false;
/* 776 */       Element newEl = insertStartTag(entry.normalName());
/*     */       
/* 778 */       if (entry.attributesSize() > 0) {
/* 779 */         newEl.attributes().addAll(entry.attributes());
/*     */       }
/*     */       
/* 782 */       this.formattingElements.set(pos, newEl);
/*     */     
/*     */     }
/* 785 */     while (pos != size - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clearFormattingElementsToLastMarker() {
/* 792 */     while (!this.formattingElements.isEmpty()) {
/* 793 */       Element el = removeLastFormattingElement();
/* 794 */       if (el == null)
/*     */         break; 
/*     */     } 
/*     */   }
/*     */   
/*     */   void removeFromActiveFormattingElements(Element el) {
/* 800 */     for (int pos = this.formattingElements.size() - 1; pos >= 0; pos--) {
/* 801 */       Element next = this.formattingElements.get(pos);
/* 802 */       if (next == el) {
/* 803 */         this.formattingElements.remove(pos);
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean isInActiveFormattingElements(Element el) {
/* 810 */     return onStack(this.formattingElements, el);
/*     */   }
/*     */   
/*     */   Element getActiveFormattingElement(String nodeName) {
/* 814 */     for (int pos = this.formattingElements.size() - 1; pos >= 0; pos--) {
/* 815 */       Element next = this.formattingElements.get(pos);
/* 816 */       if (next == null)
/*     */         break; 
/* 818 */       if (next.normalName().equals(nodeName))
/* 819 */         return next; 
/*     */     } 
/* 821 */     return null;
/*     */   }
/*     */   
/*     */   void replaceActiveFormattingElement(Element out, Element in) {
/* 825 */     replaceInQueue(this.formattingElements, out, in);
/*     */   }
/*     */   
/*     */   void insertMarkerToFormattingElements() {
/* 829 */     this.formattingElements.add(null);
/*     */   }
/*     */ 
/*     */   
/*     */   void insertInFosterParent(Node in) {
/* 834 */     Element fosterParent, lastTable = getFromStack("table");
/* 835 */     boolean isLastTableParent = false;
/* 836 */     if (lastTable != null)
/* 837 */     { if (lastTable.parent() != null) {
/* 838 */         fosterParent = lastTable.parent();
/* 839 */         isLastTableParent = true;
/*     */       } else {
/* 841 */         fosterParent = aboveOnStack(lastTable);
/*     */       }  }
/* 843 */     else { fosterParent = this.stack.get(0); }
/*     */ 
/*     */     
/* 846 */     if (isLastTableParent) {
/* 847 */       Validate.notNull(lastTable);
/* 848 */       lastTable.before(in);
/*     */     } else {
/*     */       
/* 851 */       fosterParent.appendChild(in);
/*     */     } 
/*     */   }
/*     */   
/*     */   void pushTemplateMode(HtmlTreeBuilderState state) {
/* 856 */     this.tmplInsertMode.add(state);
/*     */   }
/*     */   @Nullable
/*     */   HtmlTreeBuilderState popTemplateMode() {
/* 860 */     if (this.tmplInsertMode.size() > 0) {
/* 861 */       return this.tmplInsertMode.remove(this.tmplInsertMode.size() - 1);
/*     */     }
/* 863 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   int templateModeSize() {
/* 868 */     return this.tmplInsertMode.size();
/*     */   }
/*     */   @Nullable
/*     */   HtmlTreeBuilderState currentTemplateMode() {
/* 872 */     return (this.tmplInsertMode.size() > 0) ? this.tmplInsertMode.get(this.tmplInsertMode.size() - 1) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 877 */     return "TreeBuilder{currentToken=" + this.currentToken + ", state=" + this.state + ", currentElement=" + 
/*     */ 
/*     */       
/* 880 */       currentElement() + '}';
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isContentForTagData(String normalName) {
/* 885 */     return (normalName.equals("script") || normalName.equals("style"));
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\parser\HtmlTreeBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */