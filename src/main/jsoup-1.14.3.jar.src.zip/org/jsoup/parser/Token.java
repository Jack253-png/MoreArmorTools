/*     */ package org.jsoup.parser;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.nodes.Attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Token
/*     */ {
/*     */   TokenType type;
/*     */   
/*     */   private Token() {}
/*     */   
/*     */   String tokenType() {
/*  20 */     return getClass().getSimpleName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void reset(StringBuilder sb) {
/*  30 */     if (sb != null)
/*  31 */       sb.delete(0, sb.length()); 
/*     */   }
/*     */   
/*     */   static final class Doctype
/*     */     extends Token {
/*  36 */     final StringBuilder name = new StringBuilder();
/*  37 */     String pubSysKey = null;
/*  38 */     final StringBuilder publicIdentifier = new StringBuilder();
/*  39 */     final StringBuilder systemIdentifier = new StringBuilder();
/*     */     boolean forceQuirks = false;
/*     */     
/*     */     Doctype() {
/*  43 */       this.type = Token.TokenType.Doctype;
/*     */     }
/*     */ 
/*     */     
/*     */     Token reset() {
/*  48 */       reset(this.name);
/*  49 */       this.pubSysKey = null;
/*  50 */       reset(this.publicIdentifier);
/*  51 */       reset(this.systemIdentifier);
/*  52 */       this.forceQuirks = false;
/*  53 */       return this;
/*     */     }
/*     */     
/*     */     String getName() {
/*  57 */       return this.name.toString();
/*     */     }
/*     */     
/*     */     String getPubSysKey() {
/*  61 */       return this.pubSysKey;
/*     */     }
/*     */     
/*     */     String getPublicIdentifier() {
/*  65 */       return this.publicIdentifier.toString();
/*     */     }
/*     */     
/*     */     public String getSystemIdentifier() {
/*  69 */       return this.systemIdentifier.toString();
/*     */     }
/*     */     
/*     */     public boolean isForceQuirks() {
/*  73 */       return this.forceQuirks;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  78 */       return "<!doctype " + getName() + ">";
/*     */     } }
/*     */   static abstract class Tag extends Token { @Nullable
/*     */     protected String tagName; @Nullable
/*     */     protected String normalName; private final StringBuilder attrName; @Nullable
/*     */     private String attrNameS; private boolean hasAttrName; private final StringBuilder attrValue;
/*     */     
/*     */     Tag() {
/*  86 */       this.attrName = new StringBuilder();
/*     */       
/*  88 */       this.hasAttrName = false;
/*     */       
/*  90 */       this.attrValue = new StringBuilder();
/*     */       
/*  92 */       this.hasAttrValue = false;
/*  93 */       this.hasEmptyAttrValue = false;
/*     */       
/*  95 */       this.selfClosing = false;
/*     */     } @Nullable
/*     */     private String attrValueS; private boolean hasAttrValue; private boolean hasEmptyAttrValue; boolean selfClosing; @Nullable
/*     */     Attributes attributes; private static final int MaxAttributes = 512;
/*     */     Tag reset() {
/* 100 */       this.tagName = null;
/* 101 */       this.normalName = null;
/* 102 */       reset(this.attrName);
/* 103 */       this.attrNameS = null;
/* 104 */       this.hasAttrName = false;
/* 105 */       reset(this.attrValue);
/* 106 */       this.attrValueS = null;
/* 107 */       this.hasEmptyAttrValue = false;
/* 108 */       this.hasAttrValue = false;
/* 109 */       this.selfClosing = false;
/* 110 */       this.attributes = null;
/* 111 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final void newAttribute() {
/* 120 */       if (this.attributes == null) {
/* 121 */         this.attributes = new Attributes();
/*     */       }
/* 123 */       if (this.hasAttrName && this.attributes.size() < 512) {
/*     */         
/* 125 */         String name = (this.attrName.length() > 0) ? this.attrName.toString() : this.attrNameS;
/* 126 */         name = name.trim();
/* 127 */         if (name.length() > 0) {
/*     */           String value;
/* 129 */           if (this.hasAttrValue) {
/* 130 */             value = (this.attrValue.length() > 0) ? this.attrValue.toString() : this.attrValueS;
/* 131 */           } else if (this.hasEmptyAttrValue) {
/* 132 */             value = "";
/*     */           } else {
/* 134 */             value = null;
/*     */           } 
/* 136 */           this.attributes.add(name, value);
/*     */         } 
/*     */       } 
/* 139 */       reset(this.attrName);
/* 140 */       this.attrNameS = null;
/* 141 */       this.hasAttrName = false;
/*     */       
/* 143 */       reset(this.attrValue);
/* 144 */       this.attrValueS = null;
/* 145 */       this.hasAttrValue = false;
/* 146 */       this.hasEmptyAttrValue = false;
/*     */     }
/*     */     
/*     */     final boolean hasAttributes() {
/* 150 */       return (this.attributes != null);
/*     */     }
/*     */     
/*     */     final boolean hasAttribute(String key) {
/* 154 */       return (this.attributes != null && this.attributes.hasKey(key));
/*     */     }
/*     */ 
/*     */     
/*     */     final void finaliseTag() {
/* 159 */       if (this.hasAttrName) {
/* 160 */         newAttribute();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     final String name() {
/* 166 */       Validate.isFalse((this.tagName == null || this.tagName.length() == 0));
/* 167 */       return this.tagName;
/*     */     }
/*     */ 
/*     */     
/*     */     final String normalName() {
/* 172 */       return this.normalName;
/*     */     }
/*     */     
/*     */     final String toStringName() {
/* 176 */       return (this.tagName != null) ? this.tagName : "[unset]";
/*     */     }
/*     */     
/*     */     final Tag name(String name) {
/* 180 */       this.tagName = name;
/* 181 */       this.normalName = ParseSettings.normalName(this.tagName);
/* 182 */       return this;
/*     */     }
/*     */     
/*     */     final boolean isSelfClosing() {
/* 186 */       return this.selfClosing;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     final void appendTagName(String append) {
/* 192 */       append = append.replace(false, '�');
/* 193 */       this.tagName = (this.tagName == null) ? append : this.tagName.concat(append);
/* 194 */       this.normalName = ParseSettings.normalName(this.tagName);
/*     */     }
/*     */     
/*     */     final void appendTagName(char append) {
/* 198 */       appendTagName(String.valueOf(append));
/*     */     }
/*     */ 
/*     */     
/*     */     final void appendAttributeName(String append) {
/* 203 */       append = append.replace(false, '�');
/*     */       
/* 205 */       ensureAttrName();
/* 206 */       if (this.attrName.length() == 0) {
/* 207 */         this.attrNameS = append;
/*     */       } else {
/* 209 */         this.attrName.append(append);
/*     */       } 
/*     */     }
/*     */     
/*     */     final void appendAttributeName(char append) {
/* 214 */       ensureAttrName();
/* 215 */       this.attrName.append(append);
/*     */     }
/*     */     
/*     */     final void appendAttributeValue(String append) {
/* 219 */       ensureAttrValue();
/* 220 */       if (this.attrValue.length() == 0) {
/* 221 */         this.attrValueS = append;
/*     */       } else {
/* 223 */         this.attrValue.append(append);
/*     */       } 
/*     */     }
/*     */     
/*     */     final void appendAttributeValue(char append) {
/* 228 */       ensureAttrValue();
/* 229 */       this.attrValue.append(append);
/*     */     }
/*     */     
/*     */     final void appendAttributeValue(char[] append) {
/* 233 */       ensureAttrValue();
/* 234 */       this.attrValue.append(append);
/*     */     }
/*     */     
/*     */     final void appendAttributeValue(int[] appendCodepoints) {
/* 238 */       ensureAttrValue();
/* 239 */       for (int codepoint : appendCodepoints) {
/* 240 */         this.attrValue.appendCodePoint(codepoint);
/*     */       }
/*     */     }
/*     */     
/*     */     final void setEmptyAttributeValue() {
/* 245 */       this.hasEmptyAttrValue = true;
/*     */     }
/*     */     
/*     */     private void ensureAttrName() {
/* 249 */       this.hasAttrName = true;
/*     */       
/* 251 */       if (this.attrNameS != null) {
/* 252 */         this.attrName.append(this.attrNameS);
/* 253 */         this.attrNameS = null;
/*     */       } 
/*     */     }
/*     */     
/*     */     private void ensureAttrValue() {
/* 258 */       this.hasAttrValue = true;
/*     */       
/* 260 */       if (this.attrValueS != null) {
/* 261 */         this.attrValue.append(this.attrValueS);
/* 262 */         this.attrValueS = null;
/*     */       } 
/*     */     }
/*     */     
/*     */     public abstract String toString(); }
/*     */ 
/*     */   
/*     */   static final class StartTag
/*     */     extends Tag
/*     */   {
/*     */     StartTag() {
/* 273 */       this.type = Token.TokenType.StartTag;
/*     */     }
/*     */ 
/*     */     
/*     */     Token.Tag reset() {
/* 278 */       super.reset();
/* 279 */       this.attributes = null;
/* 280 */       return this;
/*     */     }
/*     */     
/*     */     StartTag nameAttr(String name, Attributes attributes) {
/* 284 */       this.tagName = name;
/* 285 */       this.attributes = attributes;
/* 286 */       this.normalName = ParseSettings.normalName(this.tagName);
/* 287 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 292 */       if (hasAttributes() && this.attributes.size() > 0) {
/* 293 */         return "<" + toStringName() + " " + this.attributes.toString() + ">";
/*     */       }
/* 295 */       return "<" + toStringName() + ">";
/*     */     }
/*     */   }
/*     */   
/*     */   static final class EndTag
/*     */     extends Tag {
/*     */     EndTag() {
/* 302 */       this.type = Token.TokenType.EndTag;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 307 */       return "</" + toStringName() + ">";
/*     */     }
/*     */   }
/*     */   
/*     */   static final class Comment extends Token {
/* 312 */     private final StringBuilder data = new StringBuilder();
/*     */     
/*     */     private String dataS;
/*     */     boolean bogus = false;
/*     */     
/*     */     Token reset() {
/* 318 */       reset(this.data);
/* 319 */       this.dataS = null;
/* 320 */       this.bogus = false;
/* 321 */       return this;
/*     */     }
/*     */     
/*     */     Comment() {
/* 325 */       this.type = Token.TokenType.Comment;
/*     */     }
/*     */     
/*     */     String getData() {
/* 329 */       return (this.dataS != null) ? this.dataS : this.data.toString();
/*     */     }
/*     */     
/*     */     final Comment append(String append) {
/* 333 */       ensureData();
/* 334 */       if (this.data.length() == 0) {
/* 335 */         this.dataS = append;
/*     */       } else {
/* 337 */         this.data.append(append);
/*     */       } 
/* 339 */       return this;
/*     */     }
/*     */     
/*     */     final Comment append(char append) {
/* 343 */       ensureData();
/* 344 */       this.data.append(append);
/* 345 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     private void ensureData() {
/* 350 */       if (this.dataS != null) {
/* 351 */         this.data.append(this.dataS);
/* 352 */         this.dataS = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 358 */       return "<!--" + getData() + "-->";
/*     */     }
/*     */   }
/*     */   
/*     */   static class Character
/*     */     extends Token {
/*     */     private String data;
/*     */     
/*     */     Character() {
/* 367 */       this.type = Token.TokenType.Character;
/*     */     }
/*     */ 
/*     */     
/*     */     Token reset() {
/* 372 */       this.data = null;
/* 373 */       return this;
/*     */     }
/*     */     
/*     */     Character data(String data) {
/* 377 */       this.data = data;
/* 378 */       return this;
/*     */     }
/*     */     
/*     */     String getData() {
/* 382 */       return this.data;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 387 */       return getData();
/*     */     }
/*     */   }
/*     */   
/*     */   static final class CData
/*     */     extends Character {
/*     */     CData(String data) {
/* 394 */       data(data);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 399 */       return "<![CDATA[" + getData() + "]]>";
/*     */     }
/*     */   }
/*     */   
/*     */   static final class EOF
/*     */     extends Token {
/*     */     EOF() {
/* 406 */       this.type = Token.TokenType.EOF;
/*     */     }
/*     */ 
/*     */     
/*     */     Token reset() {
/* 411 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 416 */       return "";
/*     */     }
/*     */   }
/*     */   
/*     */   final boolean isDoctype() {
/* 421 */     return (this.type == TokenType.Doctype);
/*     */   }
/*     */   
/*     */   final Doctype asDoctype() {
/* 425 */     return (Doctype)this;
/*     */   }
/*     */   
/*     */   final boolean isStartTag() {
/* 429 */     return (this.type == TokenType.StartTag);
/*     */   }
/*     */   
/*     */   final StartTag asStartTag() {
/* 433 */     return (StartTag)this;
/*     */   }
/*     */   
/*     */   final boolean isEndTag() {
/* 437 */     return (this.type == TokenType.EndTag);
/*     */   }
/*     */   
/*     */   final EndTag asEndTag() {
/* 441 */     return (EndTag)this;
/*     */   }
/*     */   
/*     */   final boolean isComment() {
/* 445 */     return (this.type == TokenType.Comment);
/*     */   }
/*     */   
/*     */   final Comment asComment() {
/* 449 */     return (Comment)this;
/*     */   }
/*     */   
/*     */   final boolean isCharacter() {
/* 453 */     return (this.type == TokenType.Character);
/*     */   }
/*     */   
/*     */   final boolean isCData() {
/* 457 */     return this instanceof CData;
/*     */   }
/*     */   
/*     */   final Character asCharacter() {
/* 461 */     return (Character)this;
/*     */   }
/*     */   
/*     */   final boolean isEOF() {
/* 465 */     return (this.type == TokenType.EOF);
/*     */   }
/*     */   abstract Token reset();
/*     */   
/* 469 */   public enum TokenType { Doctype,
/* 470 */     StartTag,
/* 471 */     EndTag,
/* 472 */     Comment,
/* 473 */     Character,
/* 474 */     EOF; }
/*     */ 
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\parser\Token.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */