/*     */ package org.jsoup.parser;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.List;
/*     */ import org.jsoup.nodes.Document;
/*     */ import org.jsoup.nodes.Element;
/*     */ import org.jsoup.nodes.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Parser
/*     */ {
/*     */   private TreeBuilder treeBuilder;
/*     */   private ParseErrorList errors;
/*     */   private ParseSettings settings;
/*     */   
/*     */   public Parser(TreeBuilder treeBuilder) {
/*  25 */     this.treeBuilder = treeBuilder;
/*  26 */     this.settings = treeBuilder.defaultSettings();
/*  27 */     this.errors = ParseErrorList.noTracking();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Parser newInstance() {
/*  35 */     return new Parser(this);
/*     */   }
/*     */   
/*     */   private Parser(Parser copy) {
/*  39 */     this.treeBuilder = copy.treeBuilder.newInstance();
/*  40 */     this.errors = new ParseErrorList(copy.errors);
/*  41 */     this.settings = new ParseSettings(copy.settings);
/*     */   }
/*     */   
/*     */   public Document parseInput(String html, String baseUri) {
/*  45 */     return this.treeBuilder.parse(new StringReader(html), baseUri, this);
/*     */   }
/*     */   
/*     */   public Document parseInput(Reader inputHtml, String baseUri) {
/*  49 */     return this.treeBuilder.parse(inputHtml, baseUri, this);
/*     */   }
/*     */   
/*     */   public List<Node> parseFragmentInput(String fragment, Element context, String baseUri) {
/*  53 */     return this.treeBuilder.parseFragment(fragment, context, baseUri, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TreeBuilder getTreeBuilder() {
/*  61 */     return this.treeBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Parser setTreeBuilder(TreeBuilder treeBuilder) {
/*  70 */     this.treeBuilder = treeBuilder;
/*  71 */     treeBuilder.parser = this;
/*  72 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTrackErrors() {
/*  80 */     return (this.errors.getMaxSize() > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Parser setTrackErrors(int maxErrors) {
/*  89 */     this.errors = (maxErrors > 0) ? ParseErrorList.tracking(maxErrors) : ParseErrorList.noTracking();
/*  90 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseErrorList getErrors() {
/*  99 */     return this.errors;
/*     */   }
/*     */   
/*     */   public Parser settings(ParseSettings settings) {
/* 103 */     this.settings = settings;
/* 104 */     return this;
/*     */   }
/*     */   
/*     */   public ParseSettings settings() {
/* 108 */     return this.settings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isContentForTagData(String normalName) {
/* 116 */     return getTreeBuilder().isContentForTagData(normalName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parse(String html, String baseUri) {
/* 129 */     TreeBuilder treeBuilder = new HtmlTreeBuilder();
/* 130 */     return treeBuilder.parse(new StringReader(html), baseUri, new Parser(treeBuilder));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Node> parseFragment(String fragmentHtml, Element context, String baseUri) {
/* 144 */     HtmlTreeBuilder treeBuilder = new HtmlTreeBuilder();
/* 145 */     return treeBuilder.parseFragment(fragmentHtml, context, baseUri, new Parser(treeBuilder));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Node> parseFragment(String fragmentHtml, Element context, String baseUri, ParseErrorList errorList) {
/* 160 */     HtmlTreeBuilder treeBuilder = new HtmlTreeBuilder();
/* 161 */     Parser parser = new Parser(treeBuilder);
/* 162 */     parser.errors = errorList;
/* 163 */     return treeBuilder.parseFragment(fragmentHtml, context, baseUri, parser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Node> parseXmlFragment(String fragmentXml, String baseUri) {
/* 174 */     XmlTreeBuilder treeBuilder = new XmlTreeBuilder();
/* 175 */     return treeBuilder.parseFragment(fragmentXml, baseUri, new Parser(treeBuilder));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parseBodyFragment(String bodyHtml, String baseUri) {
/* 187 */     Document doc = Document.createShell(baseUri);
/* 188 */     Element body = doc.body();
/* 189 */     List<Node> nodeList = parseFragment(bodyHtml, body, baseUri);
/* 190 */     Node[] nodes = nodeList.<Node>toArray(new Node[0]);
/* 191 */     for (int i = nodes.length - 1; i > 0; i--) {
/* 192 */       nodes[i].remove();
/*     */     }
/* 194 */     for (Node node : nodes) {
/* 195 */       body.appendChild(node);
/*     */     }
/* 197 */     return doc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String unescapeEntities(String string, boolean inAttribute) {
/* 207 */     Tokeniser tokeniser = new Tokeniser(new CharacterReader(string), ParseErrorList.noTracking());
/* 208 */     return tokeniser.unescapeEntities(inAttribute);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Parser htmlParser() {
/* 219 */     return new Parser(new HtmlTreeBuilder());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Parser xmlParser() {
/* 228 */     return new Parser(new XmlTreeBuilder());
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\parser\Parser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */