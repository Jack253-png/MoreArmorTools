/*      */ package org.jsoup.parser;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import org.jsoup.internal.StringUtil;
/*      */ import org.jsoup.nodes.Attribute;
/*      */ import org.jsoup.nodes.Attributes;
/*      */ import org.jsoup.nodes.Document;
/*      */ import org.jsoup.nodes.DocumentType;
/*      */ import org.jsoup.nodes.Element;
/*      */ import org.jsoup.nodes.FormElement;
/*      */ import org.jsoup.nodes.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ enum HtmlTreeBuilderState
/*      */ {
/*   20 */   Initial {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/*   22 */       if (isWhitespace(t))
/*   23 */         return true; 
/*   24 */       if (t.isComment()) {
/*   25 */         tb.insert(t.asComment());
/*   26 */       } else if (t.isDoctype()) {
/*      */ 
/*      */         
/*   29 */         Token.Doctype d = t.asDoctype();
/*      */         
/*   31 */         DocumentType doctype = new DocumentType(tb.settings.normalizeTag(d.getName()), d.getPublicIdentifier(), d.getSystemIdentifier());
/*   32 */         doctype.setPubSysKey(d.getPubSysKey());
/*   33 */         tb.getDocument().appendChild((Node)doctype);
/*   34 */         if (d.isForceQuirks())
/*   35 */           tb.getDocument().quirksMode(Document.QuirksMode.quirks); 
/*   36 */         tb.transition(BeforeHtml);
/*      */       } else {
/*      */         
/*   39 */         tb.transition(BeforeHtml);
/*   40 */         return tb.process(t);
/*      */       } 
/*   42 */       return true;
/*      */     }
/*      */   },
/*   45 */   BeforeHtml {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/*   47 */       if (t.isDoctype()) {
/*   48 */         tb.error(this);
/*   49 */         return false;
/*   50 */       }  if (t.isComment())
/*   51 */       { tb.insert(t.asComment()); }
/*   52 */       else if (isWhitespace(t))
/*   53 */       { tb.insert(t.asCharacter()); }
/*   54 */       else if (t.isStartTag() && t.asStartTag().normalName().equals("html"))
/*   55 */       { tb.insert(t.asStartTag());
/*   56 */         tb.transition(BeforeHead); }
/*   57 */       else { if (t.isEndTag() && StringUtil.inSorted(t.asEndTag().normalName(), Constants.BeforeHtmlToHead))
/*   58 */           return anythingElse(t, tb); 
/*   59 */         if (t.isEndTag()) {
/*   60 */           tb.error(this);
/*   61 */           return false;
/*      */         } 
/*   63 */         return anythingElse(t, tb); }
/*      */       
/*   65 */       return true;
/*      */     }
/*      */     
/*      */     private boolean anythingElse(Token t, HtmlTreeBuilder tb) {
/*   69 */       tb.insertStartTag("html");
/*   70 */       tb.transition(BeforeHead);
/*   71 */       return tb.process(t);
/*      */     }
/*      */   },
/*   74 */   BeforeHead {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/*   76 */       if (isWhitespace(t))
/*   77 */       { tb.insert(t.asCharacter()); }
/*   78 */       else if (t.isComment())
/*   79 */       { tb.insert(t.asComment()); }
/*   80 */       else { if (t.isDoctype()) {
/*   81 */           tb.error(this);
/*   82 */           return false;
/*   83 */         }  if (t.isStartTag() && t.asStartTag().normalName().equals("html"))
/*   84 */           return InBody.process(t, tb); 
/*   85 */         if (t.isStartTag() && t.asStartTag().normalName().equals("head"))
/*   86 */         { Element head = tb.insert(t.asStartTag());
/*   87 */           tb.setHeadElement(head);
/*   88 */           tb.transition(InHead); }
/*   89 */         else { if (t.isEndTag() && StringUtil.inSorted(t.asEndTag().normalName(), Constants.BeforeHtmlToHead)) {
/*   90 */             tb.processStartTag("head");
/*   91 */             return tb.process(t);
/*   92 */           }  if (t.isEndTag()) {
/*   93 */             tb.error(this);
/*   94 */             return false;
/*      */           } 
/*   96 */           tb.processStartTag("head");
/*   97 */           return tb.process(t); }
/*      */          }
/*   99 */        return true;
/*      */     }
/*      */   },
/*  102 */   InHead
/*      */   {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/*      */       // Byte code:
/*      */       //   0: aload_1
/*      */       //   1: invokestatic access$100 : (Lorg/jsoup/parser/Token;)Z
/*      */       //   4: ifeq -> 17
/*      */       //   7: aload_2
/*      */       //   8: aload_1
/*      */       //   9: invokevirtual asCharacter : ()Lorg/jsoup/parser/Token$Character;
/*      */       //   12: invokevirtual insert : (Lorg/jsoup/parser/Token$Character;)V
/*      */       //   15: iconst_1
/*      */       //   16: ireturn
/*      */       //   17: getstatic org/jsoup/parser/HtmlTreeBuilderState$25.$SwitchMap$org$jsoup$parser$Token$TokenType : [I
/*      */       //   20: aload_1
/*      */       //   21: getfield type : Lorg/jsoup/parser/Token$TokenType;
/*      */       //   24: invokevirtual ordinal : ()I
/*      */       //   27: iaload
/*      */       //   28: tableswitch default -> 481, 1 -> 60, 2 -> 71, 3 -> 78, 4 -> 343
/*      */       //   60: aload_2
/*      */       //   61: aload_1
/*      */       //   62: invokevirtual asComment : ()Lorg/jsoup/parser/Token$Comment;
/*      */       //   65: invokevirtual insert : (Lorg/jsoup/parser/Token$Comment;)V
/*      */       //   68: goto -> 488
/*      */       //   71: aload_2
/*      */       //   72: aload_0
/*      */       //   73: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   76: iconst_0
/*      */       //   77: ireturn
/*      */       //   78: aload_1
/*      */       //   79: invokevirtual asStartTag : ()Lorg/jsoup/parser/Token$StartTag;
/*      */       //   82: astore_3
/*      */       //   83: aload_3
/*      */       //   84: invokevirtual normalName : ()Ljava/lang/String;
/*      */       //   87: astore #4
/*      */       //   89: aload #4
/*      */       //   91: ldc 'html'
/*      */       //   93: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   96: ifeq -> 108
/*      */       //   99: getstatic org/jsoup/parser/HtmlTreeBuilderState$4.InBody : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   102: aload_1
/*      */       //   103: aload_2
/*      */       //   104: invokevirtual process : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilder;)Z
/*      */       //   107: ireturn
/*      */       //   108: aload #4
/*      */       //   110: getstatic org/jsoup/parser/HtmlTreeBuilderState$Constants.InHeadEmpty : [Ljava/lang/String;
/*      */       //   113: invokestatic inSorted : (Ljava/lang/String;[Ljava/lang/String;)Z
/*      */       //   116: ifeq -> 155
/*      */       //   119: aload_2
/*      */       //   120: aload_3
/*      */       //   121: invokevirtual insertEmpty : (Lorg/jsoup/parser/Token$StartTag;)Lorg/jsoup/nodes/Element;
/*      */       //   124: astore #5
/*      */       //   126: aload #4
/*      */       //   128: ldc 'base'
/*      */       //   130: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   133: ifeq -> 152
/*      */       //   136: aload #5
/*      */       //   138: ldc 'href'
/*      */       //   140: invokevirtual hasAttr : (Ljava/lang/String;)Z
/*      */       //   143: ifeq -> 152
/*      */       //   146: aload_2
/*      */       //   147: aload #5
/*      */       //   149: invokevirtual maybeSetBaseUri : (Lorg/jsoup/nodes/Element;)V
/*      */       //   152: goto -> 488
/*      */       //   155: aload #4
/*      */       //   157: ldc 'meta'
/*      */       //   159: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   162: ifeq -> 174
/*      */       //   165: aload_2
/*      */       //   166: aload_3
/*      */       //   167: invokevirtual insertEmpty : (Lorg/jsoup/parser/Token$StartTag;)Lorg/jsoup/nodes/Element;
/*      */       //   170: pop
/*      */       //   171: goto -> 488
/*      */       //   174: aload #4
/*      */       //   176: ldc 'title'
/*      */       //   178: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   181: ifeq -> 192
/*      */       //   184: aload_3
/*      */       //   185: aload_2
/*      */       //   186: invokestatic access$200 : (Lorg/jsoup/parser/Token$StartTag;Lorg/jsoup/parser/HtmlTreeBuilder;)V
/*      */       //   189: goto -> 488
/*      */       //   192: aload #4
/*      */       //   194: getstatic org/jsoup/parser/HtmlTreeBuilderState$Constants.InHeadRaw : [Ljava/lang/String;
/*      */       //   197: invokestatic inSorted : (Ljava/lang/String;[Ljava/lang/String;)Z
/*      */       //   200: ifeq -> 211
/*      */       //   203: aload_3
/*      */       //   204: aload_2
/*      */       //   205: invokestatic access$300 : (Lorg/jsoup/parser/Token$StartTag;Lorg/jsoup/parser/HtmlTreeBuilder;)V
/*      */       //   208: goto -> 488
/*      */       //   211: aload #4
/*      */       //   213: ldc 'noscript'
/*      */       //   215: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   218: ifeq -> 237
/*      */       //   221: aload_2
/*      */       //   222: aload_3
/*      */       //   223: invokevirtual insert : (Lorg/jsoup/parser/Token$StartTag;)Lorg/jsoup/nodes/Element;
/*      */       //   226: pop
/*      */       //   227: aload_2
/*      */       //   228: getstatic org/jsoup/parser/HtmlTreeBuilderState$4.InHeadNoscript : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   231: invokevirtual transition : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   234: goto -> 488
/*      */       //   237: aload #4
/*      */       //   239: ldc 'script'
/*      */       //   241: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   244: ifeq -> 277
/*      */       //   247: aload_2
/*      */       //   248: getfield tokeniser : Lorg/jsoup/parser/Tokeniser;
/*      */       //   251: getstatic org/jsoup/parser/TokeniserState.ScriptData : Lorg/jsoup/parser/TokeniserState;
/*      */       //   254: invokevirtual transition : (Lorg/jsoup/parser/TokeniserState;)V
/*      */       //   257: aload_2
/*      */       //   258: invokevirtual markInsertionMode : ()V
/*      */       //   261: aload_2
/*      */       //   262: getstatic org/jsoup/parser/HtmlTreeBuilderState$4.Text : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   265: invokevirtual transition : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   268: aload_2
/*      */       //   269: aload_3
/*      */       //   270: invokevirtual insert : (Lorg/jsoup/parser/Token$StartTag;)Lorg/jsoup/nodes/Element;
/*      */       //   273: pop
/*      */       //   274: goto -> 488
/*      */       //   277: aload #4
/*      */       //   279: ldc 'head'
/*      */       //   281: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   284: ifeq -> 294
/*      */       //   287: aload_2
/*      */       //   288: aload_0
/*      */       //   289: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   292: iconst_0
/*      */       //   293: ireturn
/*      */       //   294: aload #4
/*      */       //   296: ldc 'template'
/*      */       //   298: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   301: ifeq -> 336
/*      */       //   304: aload_2
/*      */       //   305: aload_3
/*      */       //   306: invokevirtual insert : (Lorg/jsoup/parser/Token$StartTag;)Lorg/jsoup/nodes/Element;
/*      */       //   309: pop
/*      */       //   310: aload_2
/*      */       //   311: invokevirtual insertMarkerToFormattingElements : ()V
/*      */       //   314: aload_2
/*      */       //   315: iconst_0
/*      */       //   316: invokevirtual framesetOk : (Z)V
/*      */       //   319: aload_2
/*      */       //   320: getstatic org/jsoup/parser/HtmlTreeBuilderState$4.InTemplate : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   323: invokevirtual transition : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   326: aload_2
/*      */       //   327: getstatic org/jsoup/parser/HtmlTreeBuilderState$4.InTemplate : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   330: invokevirtual pushTemplateMode : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   333: goto -> 488
/*      */       //   336: aload_0
/*      */       //   337: aload_1
/*      */       //   338: aload_2
/*      */       //   339: invokespecial anythingElse : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/TreeBuilder;)Z
/*      */       //   342: ireturn
/*      */       //   343: aload_1
/*      */       //   344: invokevirtual asEndTag : ()Lorg/jsoup/parser/Token$EndTag;
/*      */       //   347: astore #5
/*      */       //   349: aload #5
/*      */       //   351: invokevirtual normalName : ()Ljava/lang/String;
/*      */       //   354: astore #4
/*      */       //   356: aload #4
/*      */       //   358: ldc 'head'
/*      */       //   360: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   363: ifeq -> 381
/*      */       //   366: aload_2
/*      */       //   367: invokevirtual pop : ()Lorg/jsoup/nodes/Element;
/*      */       //   370: pop
/*      */       //   371: aload_2
/*      */       //   372: getstatic org/jsoup/parser/HtmlTreeBuilderState$4.AfterHead : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   375: invokevirtual transition : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   378: goto -> 488
/*      */       //   381: aload #4
/*      */       //   383: getstatic org/jsoup/parser/HtmlTreeBuilderState$Constants.InHeadEnd : [Ljava/lang/String;
/*      */       //   386: invokestatic inSorted : (Ljava/lang/String;[Ljava/lang/String;)Z
/*      */       //   389: ifeq -> 399
/*      */       //   392: aload_0
/*      */       //   393: aload_1
/*      */       //   394: aload_2
/*      */       //   395: invokespecial anythingElse : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/TreeBuilder;)Z
/*      */       //   398: ireturn
/*      */       //   399: aload #4
/*      */       //   401: ldc 'template'
/*      */       //   403: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   406: ifeq -> 474
/*      */       //   409: aload_2
/*      */       //   410: aload #4
/*      */       //   412: invokevirtual onStack : (Ljava/lang/String;)Z
/*      */       //   415: ifne -> 426
/*      */       //   418: aload_2
/*      */       //   419: aload_0
/*      */       //   420: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   423: goto -> 488
/*      */       //   426: aload_2
/*      */       //   427: iconst_1
/*      */       //   428: invokevirtual generateImpliedEndTags : (Z)V
/*      */       //   431: aload #4
/*      */       //   433: aload_2
/*      */       //   434: invokevirtual currentElement : ()Lorg/jsoup/nodes/Element;
/*      */       //   437: invokevirtual normalName : ()Ljava/lang/String;
/*      */       //   440: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   443: ifne -> 451
/*      */       //   446: aload_2
/*      */       //   447: aload_0
/*      */       //   448: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   451: aload_2
/*      */       //   452: aload #4
/*      */       //   454: invokevirtual popStackToClose : (Ljava/lang/String;)Lorg/jsoup/nodes/Element;
/*      */       //   457: pop
/*      */       //   458: aload_2
/*      */       //   459: invokevirtual clearFormattingElementsToLastMarker : ()V
/*      */       //   462: aload_2
/*      */       //   463: invokevirtual popTemplateMode : ()Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   466: pop
/*      */       //   467: aload_2
/*      */       //   468: invokevirtual resetInsertionMode : ()V
/*      */       //   471: goto -> 488
/*      */       //   474: aload_2
/*      */       //   475: aload_0
/*      */       //   476: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   479: iconst_0
/*      */       //   480: ireturn
/*      */       //   481: aload_0
/*      */       //   482: aload_1
/*      */       //   483: aload_2
/*      */       //   484: invokespecial anythingElse : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/TreeBuilder;)Z
/*      */       //   487: ireturn
/*      */       //   488: iconst_1
/*      */       //   489: ireturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #104	-> 0
/*      */       //   #105	-> 7
/*      */       //   #106	-> 15
/*      */       //   #108	-> 17
/*      */       //   #110	-> 60
/*      */       //   #111	-> 68
/*      */       //   #113	-> 71
/*      */       //   #114	-> 76
/*      */       //   #116	-> 78
/*      */       //   #117	-> 83
/*      */       //   #118	-> 89
/*      */       //   #119	-> 99
/*      */       //   #120	-> 108
/*      */       //   #121	-> 119
/*      */       //   #123	-> 126
/*      */       //   #124	-> 146
/*      */       //   #125	-> 152
/*      */       //   #126	-> 165
/*      */       //   #128	-> 174
/*      */       //   #129	-> 184
/*      */       //   #130	-> 192
/*      */       //   #131	-> 203
/*      */       //   #132	-> 211
/*      */       //   #134	-> 221
/*      */       //   #135	-> 227
/*      */       //   #136	-> 237
/*      */       //   #138	-> 247
/*      */       //   #139	-> 257
/*      */       //   #140	-> 261
/*      */       //   #141	-> 268
/*      */       //   #142	-> 277
/*      */       //   #143	-> 287
/*      */       //   #144	-> 292
/*      */       //   #145	-> 294
/*      */       //   #146	-> 304
/*      */       //   #147	-> 310
/*      */       //   #148	-> 314
/*      */       //   #149	-> 319
/*      */       //   #150	-> 326
/*      */       //   #152	-> 336
/*      */       //   #156	-> 343
/*      */       //   #157	-> 349
/*      */       //   #158	-> 356
/*      */       //   #159	-> 366
/*      */       //   #160	-> 371
/*      */       //   #161	-> 381
/*      */       //   #162	-> 392
/*      */       //   #163	-> 399
/*      */       //   #164	-> 409
/*      */       //   #165	-> 418
/*      */       //   #167	-> 426
/*      */       //   #168	-> 431
/*      */       //   #169	-> 451
/*      */       //   #170	-> 458
/*      */       //   #171	-> 462
/*      */       //   #172	-> 467
/*      */       //   #176	-> 474
/*      */       //   #177	-> 479
/*      */       //   #181	-> 481
/*      */       //   #183	-> 488
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   126	26	5	el	Lorg/jsoup/nodes/Element;
/*      */       //   83	260	3	start	Lorg/jsoup/parser/Token$StartTag;
/*      */       //   89	254	4	name	Ljava/lang/String;
/*      */       //   356	125	4	name	Ljava/lang/String;
/*      */       //   349	132	5	end	Lorg/jsoup/parser/Token$EndTag;
/*      */       //   0	490	0	this	Lorg/jsoup/parser/HtmlTreeBuilderState$4;
/*      */       //   0	490	1	t	Lorg/jsoup/parser/Token;
/*      */       //   0	490	2	tb	Lorg/jsoup/parser/HtmlTreeBuilder;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean anythingElse(Token t, TreeBuilder tb) {
/*  187 */       tb.processEndTag("head");
/*  188 */       return tb.process(t);
/*      */     }
/*      */   },
/*  191 */   InHeadNoscript {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/*  193 */       if (t.isDoctype())
/*  194 */       { tb.error(this); }
/*  195 */       else { if (t.isStartTag() && t.asStartTag().normalName().equals("html"))
/*  196 */           return tb.process(t, InBody); 
/*  197 */         if (t.isEndTag() && t.asEndTag().normalName().equals("noscript"))
/*  198 */         { tb.pop();
/*  199 */           tb.transition(InHead); }
/*  200 */         else { if (isWhitespace(t) || t.isComment() || (t.isStartTag() && StringUtil.inSorted(t.asStartTag().normalName(), Constants.InHeadNoScriptHead)))
/*      */           {
/*  202 */             return tb.process(t, InHead); } 
/*  203 */           if (t.isEndTag() && t.asEndTag().normalName().equals("br"))
/*  204 */             return anythingElse(t, tb); 
/*  205 */           if ((t.isStartTag() && StringUtil.inSorted(t.asStartTag().normalName(), Constants.InHeadNoscriptIgnore)) || t.isEndTag()) {
/*  206 */             tb.error(this);
/*  207 */             return false;
/*      */           } 
/*  209 */           return anythingElse(t, tb); }
/*      */          }
/*  211 */        return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean anythingElse(Token t, HtmlTreeBuilder tb) {
/*  218 */       tb.error(this);
/*  219 */       tb.insert((new Token.Character()).data(t.toString()));
/*  220 */       return true;
/*      */     }
/*      */   },
/*  223 */   AfterHead {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/*  225 */       if (isWhitespace(t)) {
/*  226 */         tb.insert(t.asCharacter());
/*  227 */       } else if (t.isComment()) {
/*  228 */         tb.insert(t.asComment());
/*  229 */       } else if (t.isDoctype()) {
/*  230 */         tb.error(this);
/*  231 */       } else if (t.isStartTag()) {
/*  232 */         Token.StartTag startTag = t.asStartTag();
/*  233 */         String name = startTag.normalName();
/*  234 */         if (name.equals("html"))
/*  235 */           return tb.process(t, InBody); 
/*  236 */         if (name.equals("body"))
/*  237 */         { tb.insert(startTag);
/*  238 */           tb.framesetOk(false);
/*  239 */           tb.transition(InBody); }
/*  240 */         else if (name.equals("frameset"))
/*  241 */         { tb.insert(startTag);
/*  242 */           tb.transition(InFrameset); }
/*  243 */         else if (StringUtil.inSorted(name, Constants.InBodyStartToHead))
/*  244 */         { tb.error(this);
/*  245 */           Element head = tb.getHeadElement();
/*  246 */           tb.push(head);
/*  247 */           tb.process(t, InHead);
/*  248 */           tb.removeFromStack(head); }
/*  249 */         else { if (name.equals("head")) {
/*  250 */             tb.error(this);
/*  251 */             return false;
/*      */           } 
/*  253 */           anythingElse(t, tb); }
/*      */       
/*  255 */       } else if (t.isEndTag()) {
/*  256 */         String name = t.asEndTag().normalName();
/*  257 */         if (StringUtil.inSorted(name, Constants.AfterHeadBody)) {
/*  258 */           anythingElse(t, tb);
/*  259 */         } else if (name.equals("template")) {
/*  260 */           tb.process(t, InHead);
/*      */         } else {
/*      */           
/*  263 */           tb.error(this);
/*  264 */           return false;
/*      */         } 
/*      */       } else {
/*  267 */         anythingElse(t, tb);
/*      */       } 
/*  269 */       return true;
/*      */     }
/*      */     
/*      */     private boolean anythingElse(Token t, HtmlTreeBuilder tb) {
/*  273 */       tb.processStartTag("body");
/*  274 */       tb.framesetOk(true);
/*  275 */       return tb.process(t);
/*      */     }
/*      */   },
/*  278 */   InBody
/*      */   {
/*      */     private static final int MaxStackScan = 24;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/*      */       // Byte code:
/*      */       //   0: getstatic org/jsoup/parser/HtmlTreeBuilderState$25.$SwitchMap$org$jsoup$parser$Token$TokenType : [I
/*      */       //   3: aload_1
/*      */       //   4: getfield type : Lorg/jsoup/parser/Token$TokenType;
/*      */       //   7: invokevirtual ordinal : ()I
/*      */       //   10: iaload
/*      */       //   11: tableswitch default -> 164, 1 -> 116, 2 -> 127, 3 -> 134, 4 -> 141, 5 -> 48, 6 -> 148
/*      */       //   48: aload_1
/*      */       //   49: invokevirtual asCharacter : ()Lorg/jsoup/parser/Token$Character;
/*      */       //   52: astore_3
/*      */       //   53: aload_3
/*      */       //   54: invokevirtual getData : ()Ljava/lang/String;
/*      */       //   57: invokestatic access$400 : ()Ljava/lang/String;
/*      */       //   60: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   63: ifeq -> 73
/*      */       //   66: aload_2
/*      */       //   67: aload_0
/*      */       //   68: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   71: iconst_0
/*      */       //   72: ireturn
/*      */       //   73: aload_2
/*      */       //   74: invokevirtual framesetOk : ()Z
/*      */       //   77: ifeq -> 99
/*      */       //   80: aload_3
/*      */       //   81: invokestatic access$100 : (Lorg/jsoup/parser/Token;)Z
/*      */       //   84: ifeq -> 99
/*      */       //   87: aload_2
/*      */       //   88: invokevirtual reconstructFormattingElements : ()V
/*      */       //   91: aload_2
/*      */       //   92: aload_3
/*      */       //   93: invokevirtual insert : (Lorg/jsoup/parser/Token$Character;)V
/*      */       //   96: goto -> 164
/*      */       //   99: aload_2
/*      */       //   100: invokevirtual reconstructFormattingElements : ()V
/*      */       //   103: aload_2
/*      */       //   104: aload_3
/*      */       //   105: invokevirtual insert : (Lorg/jsoup/parser/Token$Character;)V
/*      */       //   108: aload_2
/*      */       //   109: iconst_0
/*      */       //   110: invokevirtual framesetOk : (Z)V
/*      */       //   113: goto -> 164
/*      */       //   116: aload_2
/*      */       //   117: aload_1
/*      */       //   118: invokevirtual asComment : ()Lorg/jsoup/parser/Token$Comment;
/*      */       //   121: invokevirtual insert : (Lorg/jsoup/parser/Token$Comment;)V
/*      */       //   124: goto -> 164
/*      */       //   127: aload_2
/*      */       //   128: aload_0
/*      */       //   129: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   132: iconst_0
/*      */       //   133: ireturn
/*      */       //   134: aload_0
/*      */       //   135: aload_1
/*      */       //   136: aload_2
/*      */       //   137: invokespecial inBodyStartTag : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilder;)Z
/*      */       //   140: ireturn
/*      */       //   141: aload_0
/*      */       //   142: aload_1
/*      */       //   143: aload_2
/*      */       //   144: invokespecial inBodyEndTag : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilder;)Z
/*      */       //   147: ireturn
/*      */       //   148: aload_2
/*      */       //   149: invokevirtual templateModeSize : ()I
/*      */       //   152: ifle -> 164
/*      */       //   155: aload_2
/*      */       //   156: aload_1
/*      */       //   157: getstatic org/jsoup/parser/HtmlTreeBuilderState$7.InTemplate : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   160: invokevirtual process : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilderState;)Z
/*      */       //   163: ireturn
/*      */       //   164: iconst_1
/*      */       //   165: ireturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #280	-> 0
/*      */       //   #282	-> 48
/*      */       //   #283	-> 53
/*      */       //   #285	-> 66
/*      */       //   #286	-> 71
/*      */       //   #287	-> 73
/*      */       //   #288	-> 87
/*      */       //   #289	-> 91
/*      */       //   #291	-> 99
/*      */       //   #292	-> 103
/*      */       //   #293	-> 108
/*      */       //   #295	-> 113
/*      */       //   #298	-> 116
/*      */       //   #299	-> 124
/*      */       //   #302	-> 127
/*      */       //   #303	-> 132
/*      */       //   #306	-> 134
/*      */       //   #308	-> 141
/*      */       //   #310	-> 148
/*      */       //   #311	-> 155
/*      */       //   #316	-> 164
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   53	63	3	c	Lorg/jsoup/parser/Token$Character;
/*      */       //   0	166	0	this	Lorg/jsoup/parser/HtmlTreeBuilderState$7;
/*      */       //   0	166	1	t	Lorg/jsoup/parser/Token;
/*      */       //   0	166	2	tb	Lorg/jsoup/parser/HtmlTreeBuilder;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean inBodyStartTag(Token t, HtmlTreeBuilder tb) {
/*      */       ArrayList<Element> stack;
/*      */       Element el;
/*      */       int i;
/*      */       Element body, second;
/*      */       String prompt;
/*      */       Attributes inputAttribs;
/*      */       int bottom, upper, j;
/*  320 */       Token.StartTag startTag = t.asStartTag();
/*  321 */       String name = startTag.normalName();
/*      */ 
/*      */ 
/*      */       
/*  325 */       switch (name)
/*      */       { case "a":
/*  327 */           if (tb.getActiveFormattingElement("a") != null) {
/*  328 */             tb.error(this);
/*  329 */             tb.processEndTag("a");
/*      */ 
/*      */             
/*  332 */             Element remainingA = tb.getFromStack("a");
/*  333 */             if (remainingA != null) {
/*  334 */               tb.removeFromActiveFormattingElements(remainingA);
/*  335 */               tb.removeFromStack(remainingA);
/*      */             } 
/*      */           } 
/*  338 */           tb.reconstructFormattingElements();
/*  339 */           el = tb.insert(startTag);
/*  340 */           tb.pushActiveFormattingElements(el);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  667 */           return true;case "span": tb.reconstructFormattingElements(); tb.insert(startTag); return true;case "li": tb.framesetOk(false); stack = tb.getStack(); for (i = stack.size() - 1; i > 0; i--) { el = stack.get(i); if (el.normalName().equals("li")) { tb.processEndTag("li"); break; }  if (tb.isSpecial(el) && !StringUtil.inSorted(el.normalName(), Constants.InBodyStartLiBreakers)) break;  }  if (tb.inButtonScope("p")) tb.processEndTag("p");  tb.insert(startTag); return true;case "html": tb.error(this); if (tb.onStack("template")) return false;  stack = tb.getStack(); if (stack.size() > 0) { Element html = tb.getStack().get(0); if (startTag.hasAttributes()) for (Attribute attribute : startTag.attributes) { if (!html.hasAttr(attribute.getKey())) html.attributes().put(attribute);  }   }  return true;case "body": tb.error(this); stack = tb.getStack(); if (stack.size() == 1 || (stack.size() > 2 && !((Element)stack.get(1)).normalName().equals("body")) || tb.onStack("template")) return false;  tb.framesetOk(false); body = stack.get(1); if (startTag.hasAttributes()) for (Attribute attribute : startTag.attributes) { if (!body.hasAttr(attribute.getKey())) body.attributes().put(attribute);  }   return true;case "frameset": tb.error(this); stack = tb.getStack(); if (stack.size() == 1 || (stack.size() > 2 && !((Element)stack.get(1)).normalName().equals("body"))) return false;  if (!tb.framesetOk()) return false;  second = stack.get(1); if (second.parent() != null) second.remove();  while (stack.size() > 1) stack.remove(stack.size() - 1);  tb.insert(startTag); tb.transition(InFrameset); return true;case "form": if (tb.getFormElement() != null && !tb.onStack("template")) { tb.error(this); return false; }  if (tb.inButtonScope("p")) tb.closeElement("p");  tb.insertForm(startTag, true, true); return true;case "plaintext": if (tb.inButtonScope("p")) tb.processEndTag("p");  tb.insert(startTag); tb.tokeniser.transition(TokeniserState.PLAINTEXT); return true;case "button": if (tb.inButtonScope("button")) { tb.error(this); tb.processEndTag("button"); tb.process(startTag); } else { tb.reconstructFormattingElements(); tb.insert(startTag); tb.framesetOk(false); }  return true;case "nobr": tb.reconstructFormattingElements(); if (tb.inScope("nobr")) { tb.error(this); tb.processEndTag("nobr"); tb.reconstructFormattingElements(); }  el = tb.insert(startTag); tb.pushActiveFormattingElements(el); return true;case "table": if (tb.getDocument().quirksMode() != Document.QuirksMode.quirks && tb.inButtonScope("p")) tb.processEndTag("p");  tb.insert(startTag); tb.framesetOk(false); tb.transition(InTable); return true;case "input": tb.reconstructFormattingElements(); el = tb.insertEmpty(startTag); if (!el.attr("type").equalsIgnoreCase("hidden")) tb.framesetOk(false);  return true;case "hr": if (tb.inButtonScope("p")) tb.processEndTag("p");  tb.insertEmpty(startTag); tb.framesetOk(false); return true;case "image": if (tb.getFromStack("svg") == null) return tb.process(startTag.name("img"));  tb.insert(startTag); return true;case "isindex": tb.error(this); if (tb.getFormElement() != null) return false;  tb.processStartTag("form"); if (startTag.hasAttribute("action")) { FormElement formElement = tb.getFormElement(); if (formElement != null && startTag.hasAttribute("action")) { String action = startTag.attributes.get("action"); formElement.attributes().put("action", action); }  }  tb.processStartTag("hr"); tb.processStartTag("label"); prompt = startTag.hasAttribute("prompt") ? startTag.attributes.get("prompt") : "This is a searchable index. Enter search keywords: "; tb.process((new Token.Character()).data(prompt)); inputAttribs = new Attributes(); if (startTag.hasAttributes()) for (Attribute attr : startTag.attributes) { if (!StringUtil.inSorted(attr.getKey(), Constants.InBodyStartInputAttribs)) inputAttribs.put(attr);  }   inputAttribs.put("name", "isindex"); tb.processStartTag("input", inputAttribs); tb.processEndTag("label"); tb.processStartTag("hr"); tb.processEndTag("form"); return true;case "textarea": tb.insert(startTag); if (!startTag.isSelfClosing()) { tb.tokeniser.transition(TokeniserState.Rcdata); tb.markInsertionMode(); tb.framesetOk(false); tb.transition(Text); }  return true;case "xmp": if (tb.inButtonScope("p")) tb.processEndTag("p");  tb.reconstructFormattingElements(); tb.framesetOk(false); handleRawtext(startTag, tb); return true;case "iframe": tb.framesetOk(false); handleRawtext(startTag, tb); return true;case "noembed": handleRawtext(startTag, tb); return true;case "select": tb.reconstructFormattingElements(); tb.insert(startTag); tb.framesetOk(false); if (!startTag.selfClosing) { HtmlTreeBuilderState state = tb.state(); if (state.equals(InTable) || state.equals(InCaption) || state.equals(InTableBody) || state.equals(InRow) || state.equals(InCell)) { tb.transition(InSelectInTable); } else { tb.transition(InSelect); }  }  return true;case "math": tb.reconstructFormattingElements(); tb.insert(startTag); return true;case "svg": tb.reconstructFormattingElements(); tb.insert(startTag); return true;case "h1": case "h2": case "h3": case "h4": case "h5": case "h6": if (tb.inButtonScope("p")) tb.processEndTag("p");  if (StringUtil.inSorted(tb.currentElement().normalName(), Constants.Headings)) { tb.error(this); tb.pop(); }  tb.insert(startTag); return true;case "pre": case "listing": if (tb.inButtonScope("p")) tb.processEndTag("p");  tb.insert(startTag); tb.reader.matchConsume("\n"); tb.framesetOk(false); return true;case "dd": case "dt": tb.framesetOk(false); stack = tb.getStack(); bottom = stack.size() - 1; upper = (bottom >= 24) ? (bottom - 24) : 0; for (j = bottom; j >= upper; j--) { el = stack.get(j); if (StringUtil.inSorted(el.normalName(), Constants.DdDt)) { tb.processEndTag(el.normalName()); break; }  if (tb.isSpecial(el) && !StringUtil.inSorted(el.normalName(), Constants.InBodyStartLiBreakers)) break;  }  if (tb.inButtonScope("p")) tb.processEndTag("p");  tb.insert(startTag); return true;case "optgroup": case "option": if (tb.currentElementIs("option")) tb.processEndTag("option");  tb.reconstructFormattingElements(); tb.insert(startTag); return true;case "rp": case "rt": if (tb.inScope("ruby")) { tb.generateImpliedEndTags(); if (!tb.currentElementIs("ruby")) { tb.error(this); tb.popStackToBefore("ruby"); }  tb.insert(startTag); }  return true; }  if (!Tag.isKnownTag(name)) { tb.insert(startTag); } else if (StringUtil.inSorted(name, Constants.InBodyStartEmptyFormatters)) { tb.reconstructFormattingElements(); tb.insertEmpty(startTag); tb.framesetOk(false); } else if (StringUtil.inSorted(name, Constants.InBodyStartPClosers)) { if (tb.inButtonScope("p")) tb.processEndTag("p");  tb.insert(startTag); } else { if (StringUtil.inSorted(name, Constants.InBodyStartToHead)) return tb.process(t, InHead);  if (StringUtil.inSorted(name, Constants.Formatters)) { tb.reconstructFormattingElements(); el = tb.insert(startTag); tb.pushActiveFormattingElements(el); } else if (StringUtil.inSorted(name, Constants.InBodyStartApplets)) { tb.reconstructFormattingElements(); tb.insert(startTag); tb.insertMarkerToFormattingElements(); tb.framesetOk(false); } else if (StringUtil.inSorted(name, Constants.InBodyStartMedia)) { tb.insertEmpty(startTag); } else { if (StringUtil.inSorted(name, Constants.InBodyStartDrop)) { tb.error(this); return false; }  tb.reconstructFormattingElements(); tb.insert(startTag); }  }  return true;
/*      */     }
/*      */     
/*      */     private boolean inBodyEndTag(Token t, HtmlTreeBuilder tb) {
/*      */       boolean notIgnored;
/*  672 */       Token.EndTag endTag = t.asEndTag();
/*  673 */       String name = endTag.normalName();
/*      */       
/*  675 */       switch (name)
/*      */       { case "template":
/*  677 */           tb.process(t, InHead);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  806 */           return true;case "sarcasm": case "span": return anyOtherEndTag(t, tb);case "li": if (!tb.inListItemScope(name)) { tb.error(this); return false; }  tb.generateImpliedEndTags(name); if (!tb.currentElementIs(name)) tb.error(this);  tb.popStackToClose(name); return true;case "body": if (!tb.inScope("body")) { tb.error(this); return false; }  tb.transition(AfterBody); return true;case "html": notIgnored = tb.processEndTag("body"); if (notIgnored) return tb.process(endTag);  return true;case "form": if (!tb.onStack("template")) { FormElement formElement = tb.getFormElement(); tb.setFormElement((FormElement)null); if (formElement == null || !tb.inScope(name)) { tb.error(this); return false; }  tb.generateImpliedEndTags(); if (!tb.currentElementIs(name)) tb.error(this);  tb.removeFromStack((Element)formElement); } else { if (!tb.inScope(name)) { tb.error(this); return false; }  tb.generateImpliedEndTags(); if (!tb.currentElementIs(name)) tb.error(this);  tb.popStackToClose(name); }  return true;case "p": if (!tb.inButtonScope(name)) { tb.error(this); tb.processStartTag(name); return tb.process(endTag); }  tb.generateImpliedEndTags(name); if (!tb.currentElementIs(name)) tb.error(this);  tb.popStackToClose(name); return true;case "dd": case "dt": if (!tb.inScope(name)) { tb.error(this); return false; }  tb.generateImpliedEndTags(name); if (!tb.currentElementIs(name)) tb.error(this);  tb.popStackToClose(name); return true;case "h1": case "h2": case "h3": case "h4": case "h5": case "h6": if (!tb.inScope(Constants.Headings)) { tb.error(this); return false; }  tb.generateImpliedEndTags(name); if (!tb.currentElementIs(name)) tb.error(this);  tb.popStackToClose(Constants.Headings); return true;case "br": tb.error(this); tb.processStartTag("br"); return false; }  if (StringUtil.inSorted(name, Constants.InBodyEndAdoptionFormatters)) return inBodyEndTagAdoption(t, tb);  if (StringUtil.inSorted(name, Constants.InBodyEndClosers)) { if (!tb.inScope(name)) { tb.error(this); return false; }  tb.generateImpliedEndTags(); if (!tb.currentElementIs(name)) tb.error(this);  tb.popStackToClose(name); } else if (StringUtil.inSorted(name, Constants.InBodyStartApplets)) { if (!tb.inScope("name")) { if (!tb.inScope(name)) { tb.error(this); return false; }  tb.generateImpliedEndTags(); if (!tb.currentElementIs(name)) tb.error(this);  tb.popStackToClose(name); tb.clearFormattingElementsToLastMarker(); }  } else { return anyOtherEndTag(t, tb); }  return true;
/*      */     }
/*      */     
/*      */     boolean anyOtherEndTag(Token t, HtmlTreeBuilder tb) {
/*  810 */       String name = (t.asEndTag()).normalName;
/*  811 */       ArrayList<Element> stack = tb.getStack();
/*      */ 
/*      */       
/*  814 */       Element elFromStack = tb.getFromStack(name);
/*  815 */       if (elFromStack == null) {
/*  816 */         tb.error(this);
/*  817 */         return false;
/*      */       } 
/*      */       
/*  820 */       for (int pos = stack.size() - 1; pos >= 0; pos--) {
/*  821 */         Element node = stack.get(pos);
/*  822 */         if (node.normalName().equals(name)) {
/*  823 */           tb.generateImpliedEndTags(name);
/*  824 */           if (!tb.currentElementIs(name))
/*  825 */             tb.error(this); 
/*  826 */           tb.popStackToClose(name);
/*      */           break;
/*      */         } 
/*  829 */         if (tb.isSpecial(node)) {
/*  830 */           tb.error(this);
/*  831 */           return false;
/*      */         } 
/*      */       } 
/*      */       
/*  835 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean inBodyEndTagAdoption(Token t, HtmlTreeBuilder tb) {
/*  840 */       Token.EndTag endTag = t.asEndTag();
/*  841 */       String name = endTag.normalName();
/*      */       
/*  843 */       ArrayList<Element> stack = tb.getStack();
/*      */       
/*  845 */       for (int i = 0; i < 8; i++) {
/*  846 */         Element formatEl = tb.getActiveFormattingElement(name);
/*  847 */         if (formatEl == null)
/*  848 */           return anyOtherEndTag(t, tb); 
/*  849 */         if (!tb.onStack(formatEl)) {
/*  850 */           tb.error(this);
/*  851 */           tb.removeFromActiveFormattingElements(formatEl);
/*  852 */           return true;
/*  853 */         }  if (!tb.inScope(formatEl.normalName())) {
/*  854 */           tb.error(this);
/*  855 */           return false;
/*  856 */         }  if (tb.currentElement() != formatEl) {
/*  857 */           tb.error(this);
/*      */         }
/*  859 */         Element furthestBlock = null;
/*  860 */         Element commonAncestor = null;
/*  861 */         boolean seenFormattingElement = false;
/*      */         
/*  863 */         int stackSize = stack.size();
/*  864 */         int bookmark = -1;
/*  865 */         for (int si = 1; si < stackSize && si < 64; si++) {
/*      */           
/*  867 */           Element el = stack.get(si);
/*  868 */           if (el == formatEl) {
/*  869 */             commonAncestor = stack.get(si - 1);
/*  870 */             seenFormattingElement = true;
/*      */             
/*  872 */             bookmark = tb.positionOfElement(el);
/*  873 */           } else if (seenFormattingElement && tb.isSpecial(el)) {
/*  874 */             furthestBlock = el;
/*      */             break;
/*      */           } 
/*      */         } 
/*  878 */         if (furthestBlock == null) {
/*  879 */           tb.popStackToClose(formatEl.normalName());
/*  880 */           tb.removeFromActiveFormattingElements(formatEl);
/*  881 */           return true;
/*      */         } 
/*      */         
/*  884 */         Element node = furthestBlock;
/*  885 */         Element lastNode = furthestBlock;
/*  886 */         for (int j = 0; j < 3; j++) {
/*  887 */           if (tb.onStack(node))
/*  888 */             node = tb.aboveOnStack(node); 
/*  889 */           if (!tb.isInActiveFormattingElements(node)) {
/*  890 */             tb.removeFromStack(node);
/*      */           } else {
/*  892 */             if (node == formatEl) {
/*      */               break;
/*      */             }
/*  895 */             Element replacement = new Element(tb.tagFor(node.nodeName(), ParseSettings.preserveCase), tb.getBaseUri());
/*      */             
/*  897 */             tb.replaceActiveFormattingElement(node, replacement);
/*  898 */             tb.replaceOnStack(node, replacement);
/*  899 */             node = replacement;
/*      */             
/*  901 */             if (lastNode == furthestBlock)
/*      */             {
/*      */               
/*  904 */               bookmark = tb.positionOfElement(node) + 1;
/*      */             }
/*  906 */             if (lastNode.parent() != null)
/*  907 */               lastNode.remove(); 
/*  908 */             node.appendChild((Node)lastNode);
/*      */             
/*  910 */             lastNode = node;
/*      */           } 
/*      */         } 
/*  913 */         if (commonAncestor != null) {
/*  914 */           if (StringUtil.inSorted(commonAncestor.normalName(), Constants.InBodyEndTableFosters)) {
/*  915 */             if (lastNode.parent() != null)
/*  916 */               lastNode.remove(); 
/*  917 */             tb.insertInFosterParent((Node)lastNode);
/*      */           } else {
/*  919 */             if (lastNode.parent() != null)
/*  920 */               lastNode.remove(); 
/*  921 */             commonAncestor.appendChild((Node)lastNode);
/*      */           } 
/*      */         }
/*      */         
/*  925 */         Element adopter = new Element(formatEl.tag(), tb.getBaseUri());
/*  926 */         adopter.attributes().addAll(formatEl.attributes());
/*  927 */         adopter.appendChildren(furthestBlock.childNodes());
/*  928 */         furthestBlock.appendChild((Node)adopter);
/*  929 */         tb.removeFromActiveFormattingElements(formatEl);
/*      */         
/*  931 */         tb.pushWithBookmark(adopter, bookmark);
/*  932 */         tb.removeFromStack(formatEl);
/*  933 */         tb.insertOnStackAfter(furthestBlock, adopter);
/*      */       } 
/*  935 */       return true;
/*      */     }
/*      */   },
/*  938 */   Text
/*      */   {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/*  941 */       if (t.isCharacter())
/*  942 */       { tb.insert(t.asCharacter()); }
/*  943 */       else { if (t.isEOF()) {
/*  944 */           tb.error(this);
/*      */           
/*  946 */           tb.pop();
/*  947 */           tb.transition(tb.originalState());
/*  948 */           return tb.process(t);
/*  949 */         }  if (t.isEndTag()) {
/*      */           
/*  951 */           tb.pop();
/*  952 */           tb.transition(tb.originalState());
/*      */         }  }
/*  954 */        return true;
/*      */     }
/*      */   },
/*  957 */   InTable {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/*  959 */       if (t.isCharacter() && StringUtil.inSorted(tb.currentElement().normalName(), Constants.InTableFoster)) {
/*  960 */         tb.newPendingTableCharacters();
/*  961 */         tb.markInsertionMode();
/*  962 */         tb.transition(InTableText);
/*  963 */         return tb.process(t);
/*  964 */       }  if (t.isComment()) {
/*  965 */         tb.insert(t.asComment());
/*  966 */         return true;
/*  967 */       }  if (t.isDoctype()) {
/*  968 */         tb.error(this);
/*  969 */         return false;
/*  970 */       }  if (t.isStartTag()) {
/*  971 */         Token.StartTag startTag = t.asStartTag();
/*  972 */         String name = startTag.normalName();
/*  973 */         if (name.equals("caption"))
/*  974 */         { tb.clearStackToTableContext();
/*  975 */           tb.insertMarkerToFormattingElements();
/*  976 */           tb.insert(startTag);
/*  977 */           tb.transition(InCaption); }
/*  978 */         else if (name.equals("colgroup"))
/*  979 */         { tb.clearStackToTableContext();
/*  980 */           tb.insert(startTag);
/*  981 */           tb.transition(InColumnGroup); }
/*  982 */         else { if (name.equals("col")) {
/*  983 */             tb.clearStackToTableContext();
/*  984 */             tb.processStartTag("colgroup");
/*  985 */             return tb.process(t);
/*  986 */           }  if (StringUtil.inSorted(name, Constants.InTableToBody))
/*  987 */           { tb.clearStackToTableContext();
/*  988 */             tb.insert(startTag);
/*  989 */             tb.transition(InTableBody); }
/*  990 */           else { if (StringUtil.inSorted(name, Constants.InTableAddBody)) {
/*  991 */               tb.clearStackToTableContext();
/*  992 */               tb.processStartTag("tbody");
/*  993 */               return tb.process(t);
/*  994 */             }  if (name.equals("table")) {
/*  995 */               tb.error(this);
/*  996 */               if (!tb.inTableScope(name)) {
/*  997 */                 return false;
/*      */               }
/*  999 */               tb.popStackToClose(name);
/* 1000 */               tb.resetInsertionMode();
/* 1001 */               if (tb.state() == InTable) {
/*      */                 
/* 1003 */                 tb.insert(startTag);
/* 1004 */                 return true;
/*      */               } 
/* 1006 */               return tb.process(t);
/*      */             } 
/* 1008 */             if (StringUtil.inSorted(name, Constants.InTableToHead))
/* 1009 */               return tb.process(t, InHead); 
/* 1010 */             if (name.equals("input"))
/* 1011 */             { if (!startTag.hasAttributes() || !startTag.attributes.get("type").equalsIgnoreCase("hidden")) {
/* 1012 */                 return anythingElse(t, tb);
/*      */               }
/* 1014 */               tb.insertEmpty(startTag); }
/*      */             
/* 1016 */             else if (name.equals("form"))
/* 1017 */             { tb.error(this);
/* 1018 */               if (tb.getFormElement() != null || tb.onStack("template")) {
/* 1019 */                 return false;
/*      */               }
/* 1021 */               tb.insertForm(startTag, false, false); }
/*      */             else
/*      */             
/* 1024 */             { return anythingElse(t, tb); }  }
/*      */            }
/* 1026 */          return true;
/* 1027 */       }  if (t.isEndTag()) {
/* 1028 */         Token.EndTag endTag = t.asEndTag();
/* 1029 */         String name = endTag.normalName();
/*      */         
/* 1031 */         if (name.equals("table")) {
/* 1032 */           if (!tb.inTableScope(name)) {
/* 1033 */             tb.error(this);
/* 1034 */             return false;
/*      */           } 
/* 1036 */           tb.popStackToClose("table");
/* 1037 */           tb.resetInsertionMode();
/*      */         } else {
/* 1039 */           if (StringUtil.inSorted(name, Constants.InTableEndErr)) {
/* 1040 */             tb.error(this);
/* 1041 */             return false;
/* 1042 */           }  if (name.equals("template")) {
/* 1043 */             tb.process(t, InHead);
/*      */           } else {
/* 1045 */             return anythingElse(t, tb);
/*      */           } 
/* 1047 */         }  return true;
/* 1048 */       }  if (t.isEOF()) {
/* 1049 */         if (tb.currentElementIs("html"))
/* 1050 */           tb.error(this); 
/* 1051 */         return true;
/*      */       } 
/* 1053 */       return anythingElse(t, tb);
/*      */     }
/*      */     
/*      */     boolean anythingElse(Token t, HtmlTreeBuilder tb) {
/* 1057 */       tb.error(this);
/* 1058 */       tb.setFosterInserts(true);
/* 1059 */       tb.process(t, InBody);
/* 1060 */       tb.setFosterInserts(false);
/* 1061 */       return true;
/*      */     }
/*      */   },
/* 1064 */   InTableText {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/* 1066 */       if (t.type == Token.TokenType.Character) {
/* 1067 */         Token.Character c = t.asCharacter();
/* 1068 */         if (c.getData().equals(HtmlTreeBuilderState.nullString)) {
/* 1069 */           tb.error(this);
/* 1070 */           return false;
/*      */         } 
/* 1072 */         tb.getPendingTableCharacters().add(c.getData());
/*      */       } else {
/*      */         
/* 1075 */         if (tb.getPendingTableCharacters().size() > 0) {
/* 1076 */           for (String character : tb.getPendingTableCharacters()) {
/* 1077 */             if (!isWhitespace(character)) {
/*      */               
/* 1079 */               tb.error(this);
/* 1080 */               if (StringUtil.inSorted(tb.currentElement().normalName(), Constants.InTableFoster)) {
/* 1081 */                 tb.setFosterInserts(true);
/* 1082 */                 tb.process((new Token.Character()).data(character), InBody);
/* 1083 */                 tb.setFosterInserts(false); continue;
/*      */               } 
/* 1085 */               tb.process((new Token.Character()).data(character), InBody);
/*      */               continue;
/*      */             } 
/* 1088 */             tb.insert((new Token.Character()).data(character));
/*      */           } 
/* 1090 */           tb.newPendingTableCharacters();
/*      */         } 
/* 1092 */         tb.transition(tb.originalState());
/* 1093 */         return tb.process(t);
/*      */       } 
/* 1095 */       return true;
/*      */     }
/*      */   },
/* 1098 */   InCaption {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/* 1100 */       if (t.isEndTag() && t.asEndTag().normalName().equals("caption"))
/* 1101 */       { Token.EndTag endTag = t.asEndTag();
/* 1102 */         String name = endTag.normalName();
/* 1103 */         if (!tb.inTableScope(name)) {
/* 1104 */           tb.error(this);
/* 1105 */           return false;
/*      */         } 
/* 1107 */         tb.generateImpliedEndTags();
/* 1108 */         if (!tb.currentElementIs("caption"))
/* 1109 */           tb.error(this); 
/* 1110 */         tb.popStackToClose("caption");
/* 1111 */         tb.clearFormattingElementsToLastMarker();
/* 1112 */         tb.transition(InTable); }
/*      */       
/* 1114 */       else if ((t
/* 1115 */         .isStartTag() && StringUtil.inSorted(t.asStartTag().normalName(), Constants.InCellCol)) || (t
/* 1116 */         .isEndTag() && t.asEndTag().normalName().equals("table")))
/*      */       
/* 1118 */       { tb.error(this);
/* 1119 */         boolean processed = tb.processEndTag("caption");
/* 1120 */         if (processed)
/* 1121 */           return tb.process(t);  }
/* 1122 */       else { if (t.isEndTag() && StringUtil.inSorted(t.asEndTag().normalName(), Constants.InCaptionIgnore)) {
/* 1123 */           tb.error(this);
/* 1124 */           return false;
/*      */         } 
/* 1126 */         return tb.process(t, InBody); }
/*      */       
/* 1128 */       return true;
/*      */     }
/*      */   },
/* 1131 */   InColumnGroup
/*      */   {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/*      */       // Byte code:
/*      */       //   0: aload_1
/*      */       //   1: invokestatic access$100 : (Lorg/jsoup/parser/Token;)Z
/*      */       //   4: ifeq -> 17
/*      */       //   7: aload_2
/*      */       //   8: aload_1
/*      */       //   9: invokevirtual asCharacter : ()Lorg/jsoup/parser/Token$Character;
/*      */       //   12: invokevirtual insert : (Lorg/jsoup/parser/Token$Character;)V
/*      */       //   15: iconst_1
/*      */       //   16: ireturn
/*      */       //   17: getstatic org/jsoup/parser/HtmlTreeBuilderState$25.$SwitchMap$org$jsoup$parser$Token$TokenType : [I
/*      */       //   20: aload_1
/*      */       //   21: getfield type : Lorg/jsoup/parser/Token$TokenType;
/*      */       //   24: invokevirtual ordinal : ()I
/*      */       //   27: iaload
/*      */       //   28: tableswitch default -> 431, 1 -> 68, 2 -> 79, 3 -> 87, 4 -> 252, 5 -> 431, 6 -> 413
/*      */       //   68: aload_2
/*      */       //   69: aload_1
/*      */       //   70: invokevirtual asComment : ()Lorg/jsoup/parser/Token$Comment;
/*      */       //   73: invokevirtual insert : (Lorg/jsoup/parser/Token$Comment;)V
/*      */       //   76: goto -> 438
/*      */       //   79: aload_2
/*      */       //   80: aload_0
/*      */       //   81: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   84: goto -> 438
/*      */       //   87: aload_1
/*      */       //   88: invokevirtual asStartTag : ()Lorg/jsoup/parser/Token$StartTag;
/*      */       //   91: astore_3
/*      */       //   92: aload_3
/*      */       //   93: invokevirtual normalName : ()Ljava/lang/String;
/*      */       //   96: astore #4
/*      */       //   98: iconst_m1
/*      */       //   99: istore #5
/*      */       //   101: aload #4
/*      */       //   103: invokevirtual hashCode : ()I
/*      */       //   106: lookupswitch default -> 185, -1321546630 -> 172, 98688 -> 156, 3213227 -> 140
/*      */       //   140: aload #4
/*      */       //   142: ldc 'html'
/*      */       //   144: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   147: ifeq -> 185
/*      */       //   150: iconst_0
/*      */       //   151: istore #5
/*      */       //   153: goto -> 185
/*      */       //   156: aload #4
/*      */       //   158: ldc 'col'
/*      */       //   160: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   163: ifeq -> 185
/*      */       //   166: iconst_1
/*      */       //   167: istore #5
/*      */       //   169: goto -> 185
/*      */       //   172: aload #4
/*      */       //   174: ldc 'template'
/*      */       //   176: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   179: ifeq -> 185
/*      */       //   182: iconst_2
/*      */       //   183: istore #5
/*      */       //   185: iload #5
/*      */       //   187: tableswitch default -> 242, 0 -> 212, 1 -> 221, 2 -> 230
/*      */       //   212: aload_2
/*      */       //   213: aload_1
/*      */       //   214: getstatic org/jsoup/parser/HtmlTreeBuilderState$12.InBody : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   217: invokevirtual process : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilderState;)Z
/*      */       //   220: ireturn
/*      */       //   221: aload_2
/*      */       //   222: aload_3
/*      */       //   223: invokevirtual insertEmpty : (Lorg/jsoup/parser/Token$StartTag;)Lorg/jsoup/nodes/Element;
/*      */       //   226: pop
/*      */       //   227: goto -> 249
/*      */       //   230: aload_2
/*      */       //   231: aload_1
/*      */       //   232: getstatic org/jsoup/parser/HtmlTreeBuilderState$12.InHead : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   235: invokevirtual process : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilderState;)Z
/*      */       //   238: pop
/*      */       //   239: goto -> 249
/*      */       //   242: aload_0
/*      */       //   243: aload_1
/*      */       //   244: aload_2
/*      */       //   245: invokespecial anythingElse : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilder;)Z
/*      */       //   248: ireturn
/*      */       //   249: goto -> 438
/*      */       //   252: aload_1
/*      */       //   253: invokevirtual asEndTag : ()Lorg/jsoup/parser/Token$EndTag;
/*      */       //   256: astore #4
/*      */       //   258: aload #4
/*      */       //   260: invokevirtual normalName : ()Ljava/lang/String;
/*      */       //   263: astore #5
/*      */       //   265: aload #5
/*      */       //   267: astore #6
/*      */       //   269: iconst_m1
/*      */       //   270: istore #7
/*      */       //   272: aload #6
/*      */       //   274: invokevirtual hashCode : ()I
/*      */       //   277: lookupswitch default -> 333, -1321546630 -> 320, -636197633 -> 304
/*      */       //   304: aload #6
/*      */       //   306: ldc 'colgroup'
/*      */       //   308: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   311: ifeq -> 333
/*      */       //   314: iconst_0
/*      */       //   315: istore #7
/*      */       //   317: goto -> 333
/*      */       //   320: aload #6
/*      */       //   322: ldc 'template'
/*      */       //   324: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   327: ifeq -> 333
/*      */       //   330: iconst_1
/*      */       //   331: istore #7
/*      */       //   333: iload #7
/*      */       //   335: lookupswitch default -> 403, 0 -> 360, 1 -> 391
/*      */       //   360: aload_2
/*      */       //   361: aload #5
/*      */       //   363: invokevirtual currentElementIs : (Ljava/lang/String;)Z
/*      */       //   366: ifne -> 376
/*      */       //   369: aload_2
/*      */       //   370: aload_0
/*      */       //   371: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   374: iconst_0
/*      */       //   375: ireturn
/*      */       //   376: aload_2
/*      */       //   377: invokevirtual pop : ()Lorg/jsoup/nodes/Element;
/*      */       //   380: pop
/*      */       //   381: aload_2
/*      */       //   382: getstatic org/jsoup/parser/HtmlTreeBuilderState$12.InTable : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   385: invokevirtual transition : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   388: goto -> 410
/*      */       //   391: aload_2
/*      */       //   392: aload_1
/*      */       //   393: getstatic org/jsoup/parser/HtmlTreeBuilderState$12.InHead : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   396: invokevirtual process : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilderState;)Z
/*      */       //   399: pop
/*      */       //   400: goto -> 410
/*      */       //   403: aload_0
/*      */       //   404: aload_1
/*      */       //   405: aload_2
/*      */       //   406: invokespecial anythingElse : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilder;)Z
/*      */       //   409: ireturn
/*      */       //   410: goto -> 438
/*      */       //   413: aload_2
/*      */       //   414: ldc 'html'
/*      */       //   416: invokevirtual currentElementIs : (Ljava/lang/String;)Z
/*      */       //   419: ifeq -> 424
/*      */       //   422: iconst_1
/*      */       //   423: ireturn
/*      */       //   424: aload_0
/*      */       //   425: aload_1
/*      */       //   426: aload_2
/*      */       //   427: invokespecial anythingElse : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilder;)Z
/*      */       //   430: ireturn
/*      */       //   431: aload_0
/*      */       //   432: aload_1
/*      */       //   433: aload_2
/*      */       //   434: invokespecial anythingElse : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilder;)Z
/*      */       //   437: ireturn
/*      */       //   438: iconst_1
/*      */       //   439: ireturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #1133	-> 0
/*      */       //   #1134	-> 7
/*      */       //   #1135	-> 15
/*      */       //   #1137	-> 17
/*      */       //   #1139	-> 68
/*      */       //   #1140	-> 76
/*      */       //   #1142	-> 79
/*      */       //   #1143	-> 84
/*      */       //   #1145	-> 87
/*      */       //   #1146	-> 92
/*      */       //   #1148	-> 212
/*      */       //   #1150	-> 221
/*      */       //   #1151	-> 227
/*      */       //   #1153	-> 230
/*      */       //   #1154	-> 239
/*      */       //   #1156	-> 242
/*      */       //   #1158	-> 249
/*      */       //   #1160	-> 252
/*      */       //   #1161	-> 258
/*      */       //   #1162	-> 265
/*      */       //   #1164	-> 360
/*      */       //   #1165	-> 369
/*      */       //   #1166	-> 374
/*      */       //   #1168	-> 376
/*      */       //   #1169	-> 381
/*      */       //   #1171	-> 388
/*      */       //   #1173	-> 391
/*      */       //   #1174	-> 400
/*      */       //   #1176	-> 403
/*      */       //   #1178	-> 410
/*      */       //   #1180	-> 413
/*      */       //   #1181	-> 422
/*      */       //   #1183	-> 424
/*      */       //   #1185	-> 431
/*      */       //   #1187	-> 438
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   92	160	3	startTag	Lorg/jsoup/parser/Token$StartTag;
/*      */       //   258	155	4	endTag	Lorg/jsoup/parser/Token$EndTag;
/*      */       //   265	148	5	name	Ljava/lang/String;
/*      */       //   0	440	0	this	Lorg/jsoup/parser/HtmlTreeBuilderState$12;
/*      */       //   0	440	1	t	Lorg/jsoup/parser/Token;
/*      */       //   0	440	2	tb	Lorg/jsoup/parser/HtmlTreeBuilder;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean anythingElse(Token t, HtmlTreeBuilder tb) {
/* 1191 */       if (!tb.currentElementIs("colgroup")) {
/* 1192 */         tb.error(this);
/* 1193 */         return false;
/*      */       } 
/* 1195 */       tb.pop();
/* 1196 */       tb.transition(InTable);
/* 1197 */       tb.process(t);
/* 1198 */       return true;
/*      */     }
/*      */   },
/* 1201 */   InTableBody
/*      */   {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/*      */       // Byte code:
/*      */       //   0: getstatic org/jsoup/parser/HtmlTreeBuilderState$25.$SwitchMap$org$jsoup$parser$Token$TokenType : [I
/*      */       //   3: aload_1
/*      */       //   4: getfield type : Lorg/jsoup/parser/Token$TokenType;
/*      */       //   7: invokevirtual ordinal : ()I
/*      */       //   10: iaload
/*      */       //   11: lookupswitch default -> 232, 3 -> 36, 4 -> 131
/*      */       //   36: aload_1
/*      */       //   37: invokevirtual asStartTag : ()Lorg/jsoup/parser/Token$StartTag;
/*      */       //   40: astore_3
/*      */       //   41: aload_3
/*      */       //   42: invokevirtual normalName : ()Ljava/lang/String;
/*      */       //   45: astore #4
/*      */       //   47: aload #4
/*      */       //   49: ldc 'tr'
/*      */       //   51: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   54: ifeq -> 77
/*      */       //   57: aload_2
/*      */       //   58: invokevirtual clearStackToTableBodyContext : ()V
/*      */       //   61: aload_2
/*      */       //   62: aload_3
/*      */       //   63: invokevirtual insert : (Lorg/jsoup/parser/Token$StartTag;)Lorg/jsoup/nodes/Element;
/*      */       //   66: pop
/*      */       //   67: aload_2
/*      */       //   68: getstatic org/jsoup/parser/HtmlTreeBuilderState$13.InRow : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   71: invokevirtual transition : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   74: goto -> 239
/*      */       //   77: aload #4
/*      */       //   79: getstatic org/jsoup/parser/HtmlTreeBuilderState$Constants.InCellNames : [Ljava/lang/String;
/*      */       //   82: invokestatic inSorted : (Ljava/lang/String;[Ljava/lang/String;)Z
/*      */       //   85: ifeq -> 106
/*      */       //   88: aload_2
/*      */       //   89: aload_0
/*      */       //   90: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   93: aload_2
/*      */       //   94: ldc 'tr'
/*      */       //   96: invokevirtual processStartTag : (Ljava/lang/String;)Z
/*      */       //   99: pop
/*      */       //   100: aload_2
/*      */       //   101: aload_3
/*      */       //   102: invokevirtual process : (Lorg/jsoup/parser/Token;)Z
/*      */       //   105: ireturn
/*      */       //   106: aload #4
/*      */       //   108: getstatic org/jsoup/parser/HtmlTreeBuilderState$Constants.InTableBodyExit : [Ljava/lang/String;
/*      */       //   111: invokestatic inSorted : (Ljava/lang/String;[Ljava/lang/String;)Z
/*      */       //   114: ifeq -> 124
/*      */       //   117: aload_0
/*      */       //   118: aload_1
/*      */       //   119: aload_2
/*      */       //   120: invokespecial exitTableBody : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilder;)Z
/*      */       //   123: ireturn
/*      */       //   124: aload_0
/*      */       //   125: aload_1
/*      */       //   126: aload_2
/*      */       //   127: invokespecial anythingElse : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilder;)Z
/*      */       //   130: ireturn
/*      */       //   131: aload_1
/*      */       //   132: invokevirtual asEndTag : ()Lorg/jsoup/parser/Token$EndTag;
/*      */       //   135: astore #5
/*      */       //   137: aload #5
/*      */       //   139: invokevirtual normalName : ()Ljava/lang/String;
/*      */       //   142: astore #4
/*      */       //   144: aload #4
/*      */       //   146: getstatic org/jsoup/parser/HtmlTreeBuilderState$Constants.InTableEndIgnore : [Ljava/lang/String;
/*      */       //   149: invokestatic inSorted : (Ljava/lang/String;[Ljava/lang/String;)Z
/*      */       //   152: ifeq -> 190
/*      */       //   155: aload_2
/*      */       //   156: aload #4
/*      */       //   158: invokevirtual inTableScope : (Ljava/lang/String;)Z
/*      */       //   161: ifne -> 171
/*      */       //   164: aload_2
/*      */       //   165: aload_0
/*      */       //   166: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   169: iconst_0
/*      */       //   170: ireturn
/*      */       //   171: aload_2
/*      */       //   172: invokevirtual clearStackToTableBodyContext : ()V
/*      */       //   175: aload_2
/*      */       //   176: invokevirtual pop : ()Lorg/jsoup/nodes/Element;
/*      */       //   179: pop
/*      */       //   180: aload_2
/*      */       //   181: getstatic org/jsoup/parser/HtmlTreeBuilderState$13.InTable : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   184: invokevirtual transition : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   187: goto -> 239
/*      */       //   190: aload #4
/*      */       //   192: ldc 'table'
/*      */       //   194: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   197: ifeq -> 207
/*      */       //   200: aload_0
/*      */       //   201: aload_1
/*      */       //   202: aload_2
/*      */       //   203: invokespecial exitTableBody : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilder;)Z
/*      */       //   206: ireturn
/*      */       //   207: aload #4
/*      */       //   209: getstatic org/jsoup/parser/HtmlTreeBuilderState$Constants.InTableBodyEndIgnore : [Ljava/lang/String;
/*      */       //   212: invokestatic inSorted : (Ljava/lang/String;[Ljava/lang/String;)Z
/*      */       //   215: ifeq -> 225
/*      */       //   218: aload_2
/*      */       //   219: aload_0
/*      */       //   220: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   223: iconst_0
/*      */       //   224: ireturn
/*      */       //   225: aload_0
/*      */       //   226: aload_1
/*      */       //   227: aload_2
/*      */       //   228: invokespecial anythingElse : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilder;)Z
/*      */       //   231: ireturn
/*      */       //   232: aload_0
/*      */       //   233: aload_1
/*      */       //   234: aload_2
/*      */       //   235: invokespecial anythingElse : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilder;)Z
/*      */       //   238: ireturn
/*      */       //   239: iconst_1
/*      */       //   240: ireturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #1203	-> 0
/*      */       //   #1205	-> 36
/*      */       //   #1206	-> 41
/*      */       //   #1207	-> 47
/*      */       //   #1208	-> 57
/*      */       //   #1209	-> 61
/*      */       //   #1210	-> 67
/*      */       //   #1211	-> 77
/*      */       //   #1212	-> 88
/*      */       //   #1213	-> 93
/*      */       //   #1214	-> 100
/*      */       //   #1215	-> 106
/*      */       //   #1216	-> 117
/*      */       //   #1218	-> 124
/*      */       //   #1221	-> 131
/*      */       //   #1222	-> 137
/*      */       //   #1223	-> 144
/*      */       //   #1224	-> 155
/*      */       //   #1225	-> 164
/*      */       //   #1226	-> 169
/*      */       //   #1228	-> 171
/*      */       //   #1229	-> 175
/*      */       //   #1230	-> 180
/*      */       //   #1232	-> 190
/*      */       //   #1233	-> 200
/*      */       //   #1234	-> 207
/*      */       //   #1235	-> 218
/*      */       //   #1236	-> 223
/*      */       //   #1238	-> 225
/*      */       //   #1241	-> 232
/*      */       //   #1243	-> 239
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   41	90	3	startTag	Lorg/jsoup/parser/Token$StartTag;
/*      */       //   47	84	4	name	Ljava/lang/String;
/*      */       //   144	88	4	name	Ljava/lang/String;
/*      */       //   137	95	5	endTag	Lorg/jsoup/parser/Token$EndTag;
/*      */       //   0	241	0	this	Lorg/jsoup/parser/HtmlTreeBuilderState$13;
/*      */       //   0	241	1	t	Lorg/jsoup/parser/Token;
/*      */       //   0	241	2	tb	Lorg/jsoup/parser/HtmlTreeBuilder;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean exitTableBody(Token t, HtmlTreeBuilder tb) {
/* 1247 */       if (!tb.inTableScope("tbody") && !tb.inTableScope("thead") && !tb.inScope("tfoot")) {
/*      */         
/* 1249 */         tb.error(this);
/* 1250 */         return false;
/*      */       } 
/* 1252 */       tb.clearStackToTableBodyContext();
/* 1253 */       tb.processEndTag(tb.currentElement().normalName());
/* 1254 */       return tb.process(t);
/*      */     }
/*      */     
/*      */     private boolean anythingElse(Token t, HtmlTreeBuilder tb) {
/* 1258 */       return tb.process(t, InTable);
/*      */     }
/*      */   },
/* 1261 */   InRow {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/* 1263 */       if (t.isStartTag())
/* 1264 */       { Token.StartTag startTag = t.asStartTag();
/* 1265 */         String name = startTag.normalName();
/*      */         
/* 1267 */         if (StringUtil.inSorted(name, Constants.InCellNames))
/* 1268 */         { tb.clearStackToTableRowContext();
/* 1269 */           tb.insert(startTag);
/* 1270 */           tb.transition(InCell);
/* 1271 */           tb.insertMarkerToFormattingElements(); }
/* 1272 */         else { if (StringUtil.inSorted(name, Constants.InRowMissing)) {
/* 1273 */             return handleMissingTr(t, tb);
/*      */           }
/* 1275 */           return anythingElse(t, tb); }
/*      */          }
/* 1277 */       else if (t.isEndTag())
/* 1278 */       { Token.EndTag endTag = t.asEndTag();
/* 1279 */         String name = endTag.normalName();
/*      */         
/* 1281 */         if (name.equals("tr"))
/* 1282 */         { if (!tb.inTableScope(name)) {
/* 1283 */             tb.error(this);
/* 1284 */             return false;
/*      */           } 
/* 1286 */           tb.clearStackToTableRowContext();
/* 1287 */           tb.pop();
/* 1288 */           tb.transition(InTableBody); }
/* 1289 */         else { if (name.equals("table"))
/* 1290 */             return handleMissingTr(t, tb); 
/* 1291 */           if (StringUtil.inSorted(name, Constants.InTableToBody))
/* 1292 */           { if (!tb.inTableScope(name) || !tb.inTableScope("tr")) {
/* 1293 */               tb.error(this);
/* 1294 */               return false;
/*      */             } 
/* 1296 */             tb.clearStackToTableRowContext();
/* 1297 */             tb.pop();
/* 1298 */             tb.transition(InTableBody); }
/* 1299 */           else { if (StringUtil.inSorted(name, Constants.InRowIgnore)) {
/* 1300 */               tb.error(this);
/* 1301 */               return false;
/*      */             } 
/* 1303 */             return anythingElse(t, tb); }
/*      */            }
/*      */          }
/* 1306 */       else { return anythingElse(t, tb); }
/*      */       
/* 1308 */       return true;
/*      */     }
/*      */     
/*      */     private boolean anythingElse(Token t, HtmlTreeBuilder tb) {
/* 1312 */       return tb.process(t, InTable);
/*      */     }
/*      */     
/*      */     private boolean handleMissingTr(Token t, TreeBuilder tb) {
/* 1316 */       boolean processed = tb.processEndTag("tr");
/* 1317 */       if (processed) {
/* 1318 */         return tb.process(t);
/*      */       }
/* 1320 */       return false;
/*      */     }
/*      */   },
/* 1323 */   InCell {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/* 1325 */       if (t.isEndTag())
/* 1326 */       { Token.EndTag endTag = t.asEndTag();
/* 1327 */         String name = endTag.normalName();
/*      */         
/* 1329 */         if (StringUtil.inSorted(name, Constants.InCellNames))
/* 1330 */         { if (!tb.inTableScope(name)) {
/* 1331 */             tb.error(this);
/* 1332 */             tb.transition(InRow);
/* 1333 */             return false;
/*      */           } 
/* 1335 */           tb.generateImpliedEndTags();
/* 1336 */           if (!tb.currentElementIs(name))
/* 1337 */             tb.error(this); 
/* 1338 */           tb.popStackToClose(name);
/* 1339 */           tb.clearFormattingElementsToLastMarker();
/* 1340 */           tb.transition(InRow); }
/* 1341 */         else { if (StringUtil.inSorted(name, Constants.InCellBody)) {
/* 1342 */             tb.error(this);
/* 1343 */             return false;
/* 1344 */           }  if (StringUtil.inSorted(name, Constants.InCellTable)) {
/* 1345 */             if (!tb.inTableScope(name)) {
/* 1346 */               tb.error(this);
/* 1347 */               return false;
/*      */             } 
/* 1349 */             closeCell(tb);
/* 1350 */             return tb.process(t);
/*      */           } 
/* 1352 */           return anythingElse(t, tb); }
/*      */          }
/* 1354 */       else { if (t.isStartTag() && 
/* 1355 */           StringUtil.inSorted(t.asStartTag().normalName(), Constants.InCellCol)) {
/* 1356 */           if (!tb.inTableScope("td") && !tb.inTableScope("th")) {
/* 1357 */             tb.error(this);
/* 1358 */             return false;
/*      */           } 
/* 1360 */           closeCell(tb);
/* 1361 */           return tb.process(t);
/*      */         } 
/* 1363 */         return anythingElse(t, tb); }
/*      */       
/* 1365 */       return true;
/*      */     }
/*      */     
/*      */     private boolean anythingElse(Token t, HtmlTreeBuilder tb) {
/* 1369 */       return tb.process(t, InBody);
/*      */     }
/*      */     
/*      */     private void closeCell(HtmlTreeBuilder tb) {
/* 1373 */       if (tb.inTableScope("td")) {
/* 1374 */         tb.processEndTag("td");
/*      */       } else {
/* 1376 */         tb.processEndTag("th");
/*      */       } 
/*      */     } },
/* 1379 */   InSelect
/*      */   {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/*      */       // Byte code:
/*      */       //   0: getstatic org/jsoup/parser/HtmlTreeBuilderState$25.$SwitchMap$org$jsoup$parser$Token$TokenType : [I
/*      */       //   3: aload_1
/*      */       //   4: getfield type : Lorg/jsoup/parser/Token$TokenType;
/*      */       //   7: invokevirtual ordinal : ()I
/*      */       //   10: iaload
/*      */       //   11: tableswitch default -> 642, 1 -> 81, 2 -> 92, 3 -> 99, 4 -> 319, 5 -> 48, 6 -> 625
/*      */       //   48: aload_1
/*      */       //   49: invokevirtual asCharacter : ()Lorg/jsoup/parser/Token$Character;
/*      */       //   52: astore_3
/*      */       //   53: aload_3
/*      */       //   54: invokevirtual getData : ()Ljava/lang/String;
/*      */       //   57: invokestatic access$400 : ()Ljava/lang/String;
/*      */       //   60: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   63: ifeq -> 73
/*      */       //   66: aload_2
/*      */       //   67: aload_0
/*      */       //   68: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   71: iconst_0
/*      */       //   72: ireturn
/*      */       //   73: aload_2
/*      */       //   74: aload_3
/*      */       //   75: invokevirtual insert : (Lorg/jsoup/parser/Token$Character;)V
/*      */       //   78: goto -> 649
/*      */       //   81: aload_2
/*      */       //   82: aload_1
/*      */       //   83: invokevirtual asComment : ()Lorg/jsoup/parser/Token$Comment;
/*      */       //   86: invokevirtual insert : (Lorg/jsoup/parser/Token$Comment;)V
/*      */       //   89: goto -> 649
/*      */       //   92: aload_2
/*      */       //   93: aload_0
/*      */       //   94: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   97: iconst_0
/*      */       //   98: ireturn
/*      */       //   99: aload_1
/*      */       //   100: invokevirtual asStartTag : ()Lorg/jsoup/parser/Token$StartTag;
/*      */       //   103: astore #4
/*      */       //   105: aload #4
/*      */       //   107: invokevirtual normalName : ()Ljava/lang/String;
/*      */       //   110: astore #5
/*      */       //   112: aload #5
/*      */       //   114: ldc 'html'
/*      */       //   116: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   119: ifeq -> 132
/*      */       //   122: aload_2
/*      */       //   123: aload #4
/*      */       //   125: getstatic org/jsoup/parser/HtmlTreeBuilderState$16.InBody : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   128: invokevirtual process : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilderState;)Z
/*      */       //   131: ireturn
/*      */       //   132: aload #5
/*      */       //   134: ldc 'option'
/*      */       //   136: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   139: ifeq -> 168
/*      */       //   142: aload_2
/*      */       //   143: ldc 'option'
/*      */       //   145: invokevirtual currentElementIs : (Ljava/lang/String;)Z
/*      */       //   148: ifeq -> 158
/*      */       //   151: aload_2
/*      */       //   152: ldc 'option'
/*      */       //   154: invokevirtual processEndTag : (Ljava/lang/String;)Z
/*      */       //   157: pop
/*      */       //   158: aload_2
/*      */       //   159: aload #4
/*      */       //   161: invokevirtual insert : (Lorg/jsoup/parser/Token$StartTag;)Lorg/jsoup/nodes/Element;
/*      */       //   164: pop
/*      */       //   165: goto -> 649
/*      */       //   168: aload #5
/*      */       //   170: ldc 'optgroup'
/*      */       //   172: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   175: ifeq -> 220
/*      */       //   178: aload_2
/*      */       //   179: ldc 'option'
/*      */       //   181: invokevirtual currentElementIs : (Ljava/lang/String;)Z
/*      */       //   184: ifeq -> 194
/*      */       //   187: aload_2
/*      */       //   188: ldc 'option'
/*      */       //   190: invokevirtual processEndTag : (Ljava/lang/String;)Z
/*      */       //   193: pop
/*      */       //   194: aload_2
/*      */       //   195: ldc 'optgroup'
/*      */       //   197: invokevirtual currentElementIs : (Ljava/lang/String;)Z
/*      */       //   200: ifeq -> 210
/*      */       //   203: aload_2
/*      */       //   204: ldc 'optgroup'
/*      */       //   206: invokevirtual processEndTag : (Ljava/lang/String;)Z
/*      */       //   209: pop
/*      */       //   210: aload_2
/*      */       //   211: aload #4
/*      */       //   213: invokevirtual insert : (Lorg/jsoup/parser/Token$StartTag;)Lorg/jsoup/nodes/Element;
/*      */       //   216: pop
/*      */       //   217: goto -> 649
/*      */       //   220: aload #5
/*      */       //   222: ldc 'select'
/*      */       //   224: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   227: ifeq -> 242
/*      */       //   230: aload_2
/*      */       //   231: aload_0
/*      */       //   232: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   235: aload_2
/*      */       //   236: ldc 'select'
/*      */       //   238: invokevirtual processEndTag : (Ljava/lang/String;)Z
/*      */       //   241: ireturn
/*      */       //   242: aload #5
/*      */       //   244: getstatic org/jsoup/parser/HtmlTreeBuilderState$Constants.InSelectEnd : [Ljava/lang/String;
/*      */       //   247: invokestatic inSorted : (Ljava/lang/String;[Ljava/lang/String;)Z
/*      */       //   250: ifeq -> 283
/*      */       //   253: aload_2
/*      */       //   254: aload_0
/*      */       //   255: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   258: aload_2
/*      */       //   259: ldc 'select'
/*      */       //   261: invokevirtual inSelectScope : (Ljava/lang/String;)Z
/*      */       //   264: ifne -> 269
/*      */       //   267: iconst_0
/*      */       //   268: ireturn
/*      */       //   269: aload_2
/*      */       //   270: ldc 'select'
/*      */       //   272: invokevirtual processEndTag : (Ljava/lang/String;)Z
/*      */       //   275: pop
/*      */       //   276: aload_2
/*      */       //   277: aload #4
/*      */       //   279: invokevirtual process : (Lorg/jsoup/parser/Token;)Z
/*      */       //   282: ireturn
/*      */       //   283: aload #5
/*      */       //   285: ldc 'script'
/*      */       //   287: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   290: ifne -> 303
/*      */       //   293: aload #5
/*      */       //   295: ldc 'template'
/*      */       //   297: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   300: ifeq -> 312
/*      */       //   303: aload_2
/*      */       //   304: aload_1
/*      */       //   305: getstatic org/jsoup/parser/HtmlTreeBuilderState$16.InHead : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   308: invokevirtual process : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilderState;)Z
/*      */       //   311: ireturn
/*      */       //   312: aload_0
/*      */       //   313: aload_1
/*      */       //   314: aload_2
/*      */       //   315: invokespecial anythingElse : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilder;)Z
/*      */       //   318: ireturn
/*      */       //   319: aload_1
/*      */       //   320: invokevirtual asEndTag : ()Lorg/jsoup/parser/Token$EndTag;
/*      */       //   323: astore #6
/*      */       //   325: aload #6
/*      */       //   327: invokevirtual normalName : ()Ljava/lang/String;
/*      */       //   330: astore #5
/*      */       //   332: aload #5
/*      */       //   334: astore #7
/*      */       //   336: iconst_m1
/*      */       //   337: istore #8
/*      */       //   339: aload #7
/*      */       //   341: invokevirtual hashCode : ()I
/*      */       //   344: lookupswitch default -> 449, -1321546630 -> 436, -1010136971 -> 404, -906021636 -> 420, -80773204 -> 388
/*      */       //   388: aload #7
/*      */       //   390: ldc 'optgroup'
/*      */       //   392: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   395: ifeq -> 449
/*      */       //   398: iconst_0
/*      */       //   399: istore #8
/*      */       //   401: goto -> 449
/*      */       //   404: aload #7
/*      */       //   406: ldc 'option'
/*      */       //   408: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   411: ifeq -> 449
/*      */       //   414: iconst_1
/*      */       //   415: istore #8
/*      */       //   417: goto -> 449
/*      */       //   420: aload #7
/*      */       //   422: ldc 'select'
/*      */       //   424: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   427: ifeq -> 449
/*      */       //   430: iconst_2
/*      */       //   431: istore #8
/*      */       //   433: goto -> 449
/*      */       //   436: aload #7
/*      */       //   438: ldc 'template'
/*      */       //   440: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   443: ifeq -> 449
/*      */       //   446: iconst_3
/*      */       //   447: istore #8
/*      */       //   449: iload #8
/*      */       //   451: tableswitch default -> 615, 0 -> 480, 1 -> 551, 2 -> 576, 3 -> 606
/*      */       //   480: aload_2
/*      */       //   481: ldc 'option'
/*      */       //   483: invokevirtual currentElementIs : (Ljava/lang/String;)Z
/*      */       //   486: ifeq -> 526
/*      */       //   489: aload_2
/*      */       //   490: aload_2
/*      */       //   491: invokevirtual currentElement : ()Lorg/jsoup/nodes/Element;
/*      */       //   494: invokevirtual aboveOnStack : (Lorg/jsoup/nodes/Element;)Lorg/jsoup/nodes/Element;
/*      */       //   497: ifnull -> 526
/*      */       //   500: aload_2
/*      */       //   501: aload_2
/*      */       //   502: invokevirtual currentElement : ()Lorg/jsoup/nodes/Element;
/*      */       //   505: invokevirtual aboveOnStack : (Lorg/jsoup/nodes/Element;)Lorg/jsoup/nodes/Element;
/*      */       //   508: invokevirtual normalName : ()Ljava/lang/String;
/*      */       //   511: ldc 'optgroup'
/*      */       //   513: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   516: ifeq -> 526
/*      */       //   519: aload_2
/*      */       //   520: ldc 'option'
/*      */       //   522: invokevirtual processEndTag : (Ljava/lang/String;)Z
/*      */       //   525: pop
/*      */       //   526: aload_2
/*      */       //   527: ldc 'optgroup'
/*      */       //   529: invokevirtual currentElementIs : (Ljava/lang/String;)Z
/*      */       //   532: ifeq -> 543
/*      */       //   535: aload_2
/*      */       //   536: invokevirtual pop : ()Lorg/jsoup/nodes/Element;
/*      */       //   539: pop
/*      */       //   540: goto -> 622
/*      */       //   543: aload_2
/*      */       //   544: aload_0
/*      */       //   545: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   548: goto -> 622
/*      */       //   551: aload_2
/*      */       //   552: ldc 'option'
/*      */       //   554: invokevirtual currentElementIs : (Ljava/lang/String;)Z
/*      */       //   557: ifeq -> 568
/*      */       //   560: aload_2
/*      */       //   561: invokevirtual pop : ()Lorg/jsoup/nodes/Element;
/*      */       //   564: pop
/*      */       //   565: goto -> 622
/*      */       //   568: aload_2
/*      */       //   569: aload_0
/*      */       //   570: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   573: goto -> 622
/*      */       //   576: aload_2
/*      */       //   577: aload #5
/*      */       //   579: invokevirtual inSelectScope : (Ljava/lang/String;)Z
/*      */       //   582: ifne -> 592
/*      */       //   585: aload_2
/*      */       //   586: aload_0
/*      */       //   587: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   590: iconst_0
/*      */       //   591: ireturn
/*      */       //   592: aload_2
/*      */       //   593: aload #5
/*      */       //   595: invokevirtual popStackToClose : (Ljava/lang/String;)Lorg/jsoup/nodes/Element;
/*      */       //   598: pop
/*      */       //   599: aload_2
/*      */       //   600: invokevirtual resetInsertionMode : ()V
/*      */       //   603: goto -> 622
/*      */       //   606: aload_2
/*      */       //   607: aload_1
/*      */       //   608: getstatic org/jsoup/parser/HtmlTreeBuilderState$16.InHead : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   611: invokevirtual process : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilderState;)Z
/*      */       //   614: ireturn
/*      */       //   615: aload_0
/*      */       //   616: aload_1
/*      */       //   617: aload_2
/*      */       //   618: invokespecial anythingElse : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilder;)Z
/*      */       //   621: ireturn
/*      */       //   622: goto -> 649
/*      */       //   625: aload_2
/*      */       //   626: ldc 'html'
/*      */       //   628: invokevirtual currentElementIs : (Ljava/lang/String;)Z
/*      */       //   631: ifne -> 649
/*      */       //   634: aload_2
/*      */       //   635: aload_0
/*      */       //   636: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   639: goto -> 649
/*      */       //   642: aload_0
/*      */       //   643: aload_1
/*      */       //   644: aload_2
/*      */       //   645: invokespecial anythingElse : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilder;)Z
/*      */       //   648: ireturn
/*      */       //   649: iconst_1
/*      */       //   650: ireturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #1381	-> 0
/*      */       //   #1383	-> 48
/*      */       //   #1384	-> 53
/*      */       //   #1385	-> 66
/*      */       //   #1386	-> 71
/*      */       //   #1388	-> 73
/*      */       //   #1390	-> 78
/*      */       //   #1392	-> 81
/*      */       //   #1393	-> 89
/*      */       //   #1395	-> 92
/*      */       //   #1396	-> 97
/*      */       //   #1398	-> 99
/*      */       //   #1399	-> 105
/*      */       //   #1400	-> 112
/*      */       //   #1401	-> 122
/*      */       //   #1402	-> 132
/*      */       //   #1403	-> 142
/*      */       //   #1404	-> 151
/*      */       //   #1405	-> 158
/*      */       //   #1406	-> 168
/*      */       //   #1407	-> 178
/*      */       //   #1408	-> 187
/*      */       //   #1409	-> 194
/*      */       //   #1410	-> 203
/*      */       //   #1411	-> 210
/*      */       //   #1412	-> 220
/*      */       //   #1413	-> 230
/*      */       //   #1414	-> 235
/*      */       //   #1415	-> 242
/*      */       //   #1416	-> 253
/*      */       //   #1417	-> 258
/*      */       //   #1418	-> 267
/*      */       //   #1419	-> 269
/*      */       //   #1420	-> 276
/*      */       //   #1421	-> 283
/*      */       //   #1422	-> 303
/*      */       //   #1424	-> 312
/*      */       //   #1428	-> 319
/*      */       //   #1429	-> 325
/*      */       //   #1430	-> 332
/*      */       //   #1432	-> 480
/*      */       //   #1433	-> 519
/*      */       //   #1434	-> 526
/*      */       //   #1435	-> 535
/*      */       //   #1437	-> 543
/*      */       //   #1438	-> 548
/*      */       //   #1440	-> 551
/*      */       //   #1441	-> 560
/*      */       //   #1443	-> 568
/*      */       //   #1444	-> 573
/*      */       //   #1446	-> 576
/*      */       //   #1447	-> 585
/*      */       //   #1448	-> 590
/*      */       //   #1450	-> 592
/*      */       //   #1451	-> 599
/*      */       //   #1453	-> 603
/*      */       //   #1455	-> 606
/*      */       //   #1457	-> 615
/*      */       //   #1459	-> 622
/*      */       //   #1461	-> 625
/*      */       //   #1462	-> 634
/*      */       //   #1465	-> 642
/*      */       //   #1467	-> 649
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   53	28	3	c	Lorg/jsoup/parser/Token$Character;
/*      */       //   105	214	4	start	Lorg/jsoup/parser/Token$StartTag;
/*      */       //   112	207	5	name	Ljava/lang/String;
/*      */       //   332	293	5	name	Ljava/lang/String;
/*      */       //   325	300	6	end	Lorg/jsoup/parser/Token$EndTag;
/*      */       //   0	651	0	this	Lorg/jsoup/parser/HtmlTreeBuilderState$16;
/*      */       //   0	651	1	t	Lorg/jsoup/parser/Token;
/*      */       //   0	651	2	tb	Lorg/jsoup/parser/HtmlTreeBuilder;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean anythingElse(Token t, HtmlTreeBuilder tb) {
/* 1471 */       tb.error(this);
/* 1472 */       return false;
/*      */     }
/*      */   },
/* 1475 */   InSelectInTable {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/* 1477 */       if (t.isStartTag() && StringUtil.inSorted(t.asStartTag().normalName(), Constants.InSelectTableEnd)) {
/* 1478 */         tb.error(this);
/* 1479 */         tb.popStackToClose("select");
/* 1480 */         tb.resetInsertionMode();
/* 1481 */         return tb.process(t);
/* 1482 */       }  if (t.isEndTag() && StringUtil.inSorted(t.asEndTag().normalName(), Constants.InSelectTableEnd)) {
/* 1483 */         tb.error(this);
/* 1484 */         if (tb.inTableScope(t.asEndTag().normalName())) {
/* 1485 */           tb.popStackToClose("select");
/* 1486 */           tb.resetInsertionMode();
/* 1487 */           return tb.process(t);
/*      */         } 
/* 1489 */         return false;
/*      */       } 
/* 1491 */       return tb.process(t, InSelect);
/*      */     }
/*      */   },
/*      */   
/* 1495 */   InTemplate
/*      */   {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean process(Token t, HtmlTreeBuilder tb)
/*      */     {
/*      */       // Byte code:
/*      */       //   0: getstatic org/jsoup/parser/HtmlTreeBuilderState$25.$SwitchMap$org$jsoup$parser$Token$TokenType : [I
/*      */       //   3: aload_1
/*      */       //   4: getfield type : Lorg/jsoup/parser/Token$TokenType;
/*      */       //   7: invokevirtual ordinal : ()I
/*      */       //   10: iaload
/*      */       //   11: tableswitch default -> 360, 1 -> 48, 2 -> 48, 3 -> 60, 4 -> 261, 5 -> 48, 6 -> 297
/*      */       //   48: aload_2
/*      */       //   49: aload_1
/*      */       //   50: getstatic org/jsoup/parser/HtmlTreeBuilderState$18.InBody : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   53: invokevirtual process : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilderState;)Z
/*      */       //   56: pop
/*      */       //   57: goto -> 360
/*      */       //   60: aload_1
/*      */       //   61: invokevirtual asStartTag : ()Lorg/jsoup/parser/Token$StartTag;
/*      */       //   64: invokevirtual normalName : ()Ljava/lang/String;
/*      */       //   67: astore_3
/*      */       //   68: aload_3
/*      */       //   69: getstatic org/jsoup/parser/HtmlTreeBuilderState$Constants.InTemplateToHead : [Ljava/lang/String;
/*      */       //   72: invokestatic inSorted : (Ljava/lang/String;[Ljava/lang/String;)Z
/*      */       //   75: ifeq -> 90
/*      */       //   78: aload_2
/*      */       //   79: aload_1
/*      */       //   80: getstatic org/jsoup/parser/HtmlTreeBuilderState$18.InHead : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   83: invokevirtual process : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilderState;)Z
/*      */       //   86: pop
/*      */       //   87: goto -> 360
/*      */       //   90: aload_3
/*      */       //   91: getstatic org/jsoup/parser/HtmlTreeBuilderState$Constants.InTemplateToTable : [Ljava/lang/String;
/*      */       //   94: invokestatic inSorted : (Ljava/lang/String;[Ljava/lang/String;)Z
/*      */       //   97: ifeq -> 125
/*      */       //   100: aload_2
/*      */       //   101: invokevirtual popTemplateMode : ()Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   104: pop
/*      */       //   105: aload_2
/*      */       //   106: getstatic org/jsoup/parser/HtmlTreeBuilderState$18.InTable : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   109: invokevirtual pushTemplateMode : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   112: aload_2
/*      */       //   113: getstatic org/jsoup/parser/HtmlTreeBuilderState$18.InTable : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   116: invokevirtual transition : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   119: aload_2
/*      */       //   120: aload_1
/*      */       //   121: invokevirtual process : (Lorg/jsoup/parser/Token;)Z
/*      */       //   124: ireturn
/*      */       //   125: aload_3
/*      */       //   126: ldc 'col'
/*      */       //   128: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   131: ifeq -> 159
/*      */       //   134: aload_2
/*      */       //   135: invokevirtual popTemplateMode : ()Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   138: pop
/*      */       //   139: aload_2
/*      */       //   140: getstatic org/jsoup/parser/HtmlTreeBuilderState$18.InColumnGroup : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   143: invokevirtual pushTemplateMode : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   146: aload_2
/*      */       //   147: getstatic org/jsoup/parser/HtmlTreeBuilderState$18.InColumnGroup : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   150: invokevirtual transition : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   153: aload_2
/*      */       //   154: aload_1
/*      */       //   155: invokevirtual process : (Lorg/jsoup/parser/Token;)Z
/*      */       //   158: ireturn
/*      */       //   159: aload_3
/*      */       //   160: ldc 'tr'
/*      */       //   162: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   165: ifeq -> 193
/*      */       //   168: aload_2
/*      */       //   169: invokevirtual popTemplateMode : ()Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   172: pop
/*      */       //   173: aload_2
/*      */       //   174: getstatic org/jsoup/parser/HtmlTreeBuilderState$18.InTableBody : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   177: invokevirtual pushTemplateMode : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   180: aload_2
/*      */       //   181: getstatic org/jsoup/parser/HtmlTreeBuilderState$18.InTableBody : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   184: invokevirtual transition : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   187: aload_2
/*      */       //   188: aload_1
/*      */       //   189: invokevirtual process : (Lorg/jsoup/parser/Token;)Z
/*      */       //   192: ireturn
/*      */       //   193: aload_3
/*      */       //   194: ldc 'td'
/*      */       //   196: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   199: ifne -> 211
/*      */       //   202: aload_3
/*      */       //   203: ldc 'th'
/*      */       //   205: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   208: ifeq -> 236
/*      */       //   211: aload_2
/*      */       //   212: invokevirtual popTemplateMode : ()Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   215: pop
/*      */       //   216: aload_2
/*      */       //   217: getstatic org/jsoup/parser/HtmlTreeBuilderState$18.InRow : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   220: invokevirtual pushTemplateMode : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   223: aload_2
/*      */       //   224: getstatic org/jsoup/parser/HtmlTreeBuilderState$18.InRow : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   227: invokevirtual transition : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   230: aload_2
/*      */       //   231: aload_1
/*      */       //   232: invokevirtual process : (Lorg/jsoup/parser/Token;)Z
/*      */       //   235: ireturn
/*      */       //   236: aload_2
/*      */       //   237: invokevirtual popTemplateMode : ()Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   240: pop
/*      */       //   241: aload_2
/*      */       //   242: getstatic org/jsoup/parser/HtmlTreeBuilderState$18.InBody : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   245: invokevirtual pushTemplateMode : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   248: aload_2
/*      */       //   249: getstatic org/jsoup/parser/HtmlTreeBuilderState$18.InBody : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   252: invokevirtual transition : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   255: aload_2
/*      */       //   256: aload_1
/*      */       //   257: invokevirtual process : (Lorg/jsoup/parser/Token;)Z
/*      */       //   260: ireturn
/*      */       //   261: aload_1
/*      */       //   262: invokevirtual asEndTag : ()Lorg/jsoup/parser/Token$EndTag;
/*      */       //   265: invokevirtual normalName : ()Ljava/lang/String;
/*      */       //   268: astore_3
/*      */       //   269: aload_3
/*      */       //   270: ldc 'template'
/*      */       //   272: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   275: ifeq -> 290
/*      */       //   278: aload_2
/*      */       //   279: aload_1
/*      */       //   280: getstatic org/jsoup/parser/HtmlTreeBuilderState$18.InHead : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   283: invokevirtual process : (Lorg/jsoup/parser/Token;Lorg/jsoup/parser/HtmlTreeBuilderState;)Z
/*      */       //   286: pop
/*      */       //   287: goto -> 360
/*      */       //   290: aload_2
/*      */       //   291: aload_0
/*      */       //   292: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   295: iconst_0
/*      */       //   296: ireturn
/*      */       //   297: aload_2
/*      */       //   298: ldc 'template'
/*      */       //   300: invokevirtual onStack : (Ljava/lang/String;)Z
/*      */       //   303: ifne -> 308
/*      */       //   306: iconst_1
/*      */       //   307: ireturn
/*      */       //   308: aload_2
/*      */       //   309: aload_0
/*      */       //   310: invokevirtual error : (Lorg/jsoup/parser/HtmlTreeBuilderState;)V
/*      */       //   313: aload_2
/*      */       //   314: ldc 'template'
/*      */       //   316: invokevirtual popStackToClose : (Ljava/lang/String;)Lorg/jsoup/nodes/Element;
/*      */       //   319: pop
/*      */       //   320: aload_2
/*      */       //   321: invokevirtual clearFormattingElementsToLastMarker : ()V
/*      */       //   324: aload_2
/*      */       //   325: invokevirtual popTemplateMode : ()Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   328: pop
/*      */       //   329: aload_2
/*      */       //   330: invokevirtual resetInsertionMode : ()V
/*      */       //   333: aload_2
/*      */       //   334: invokevirtual state : ()Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   337: getstatic org/jsoup/parser/HtmlTreeBuilderState$18.InTemplate : Lorg/jsoup/parser/HtmlTreeBuilderState;
/*      */       //   340: if_acmpeq -> 358
/*      */       //   343: aload_2
/*      */       //   344: invokevirtual templateModeSize : ()I
/*      */       //   347: bipush #12
/*      */       //   349: if_icmpge -> 358
/*      */       //   352: aload_2
/*      */       //   353: aload_1
/*      */       //   354: invokevirtual process : (Lorg/jsoup/parser/Token;)Z
/*      */       //   357: ireturn
/*      */       //   358: iconst_1
/*      */       //   359: ireturn
/*      */       //   360: iconst_1
/*      */       //   361: ireturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #1498	-> 0
/*      */       //   #1502	-> 48
/*      */       //   #1503	-> 57
/*      */       //   #1505	-> 60
/*      */       //   #1506	-> 68
/*      */       //   #1507	-> 78
/*      */       //   #1508	-> 90
/*      */       //   #1509	-> 100
/*      */       //   #1510	-> 105
/*      */       //   #1511	-> 112
/*      */       //   #1512	-> 119
/*      */       //   #1514	-> 125
/*      */       //   #1515	-> 134
/*      */       //   #1516	-> 139
/*      */       //   #1517	-> 146
/*      */       //   #1518	-> 153
/*      */       //   #1519	-> 159
/*      */       //   #1520	-> 168
/*      */       //   #1521	-> 173
/*      */       //   #1522	-> 180
/*      */       //   #1523	-> 187
/*      */       //   #1524	-> 193
/*      */       //   #1525	-> 211
/*      */       //   #1526	-> 216
/*      */       //   #1527	-> 223
/*      */       //   #1528	-> 230
/*      */       //   #1530	-> 236
/*      */       //   #1531	-> 241
/*      */       //   #1532	-> 248
/*      */       //   #1533	-> 255
/*      */       //   #1538	-> 261
/*      */       //   #1539	-> 269
/*      */       //   #1540	-> 278
/*      */       //   #1542	-> 290
/*      */       //   #1543	-> 295
/*      */       //   #1547	-> 297
/*      */       //   #1548	-> 306
/*      */       //   #1550	-> 308
/*      */       //   #1551	-> 313
/*      */       //   #1552	-> 320
/*      */       //   #1553	-> 324
/*      */       //   #1554	-> 329
/*      */       //   #1557	-> 333
/*      */       //   #1558	-> 352
/*      */       //   #1559	-> 358
/*      */       //   #1561	-> 360
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   68	193	3	name	Ljava/lang/String;
/*      */       //   269	28	3	name	Ljava/lang/String;
/*      */       //   0	362	0	this	Lorg/jsoup/parser/HtmlTreeBuilderState$18;
/*      */       //   0	362	1	t	Lorg/jsoup/parser/Token;
/*      */       //   0	362	2	tb	Lorg/jsoup/parser/HtmlTreeBuilder;
/*      */     }
/*      */   },
/* 1564 */   AfterBody {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/* 1566 */       if (isWhitespace(t))
/* 1567 */       { tb.insert(t.asCharacter()); }
/* 1568 */       else if (t.isComment())
/* 1569 */       { tb.insert(t.asComment()); }
/* 1570 */       else { if (t.isDoctype()) {
/* 1571 */           tb.error(this);
/* 1572 */           return false;
/* 1573 */         }  if (t.isStartTag() && t.asStartTag().normalName().equals("html"))
/* 1574 */           return tb.process(t, InBody); 
/* 1575 */         if (t.isEndTag() && t.asEndTag().normalName().equals("html")) {
/* 1576 */           if (tb.isFragmentParsing()) {
/* 1577 */             tb.error(this);
/* 1578 */             return false;
/*      */           } 
/* 1580 */           tb.transition(AfterAfterBody);
/*      */         }
/* 1582 */         else if (!t.isEOF()) {
/*      */ 
/*      */           
/* 1585 */           tb.error(this);
/* 1586 */           tb.transition(InBody);
/* 1587 */           return tb.process(t);
/*      */         }  }
/* 1589 */        return true;
/*      */     }
/*      */   },
/* 1592 */   InFrameset {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/* 1594 */       if (isWhitespace(t))
/* 1595 */       { tb.insert(t.asCharacter()); }
/* 1596 */       else if (t.isComment())
/* 1597 */       { tb.insert(t.asComment()); }
/* 1598 */       else { if (t.isDoctype()) {
/* 1599 */           tb.error(this);
/* 1600 */           return false;
/* 1601 */         }  if (t.isStartTag())
/* 1602 */         { Token.StartTag start = t.asStartTag();
/* 1603 */           switch (start.normalName())
/*      */           { case "html":
/* 1605 */               return tb.process(start, InBody);
/*      */             case "frameset":
/* 1607 */               tb.insert(start);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1637 */               return true;case "frame": tb.insertEmpty(start); return true;case "noframes": return tb.process(start, InHead); }  tb.error(this); return false; }  if (t.isEndTag() && t.asEndTag().normalName().equals("frameset")) { if (tb.currentElementIs("html")) { tb.error(this); return false; }  tb.pop(); if (!tb.isFragmentParsing() && !tb.currentElementIs("frameset")) tb.transition(AfterFrameset);  } else if (t.isEOF()) { if (!tb.currentElementIs("html")) { tb.error(this); return true; }  } else { tb.error(this); return false; }  }  return true;
/*      */     }
/*      */   },
/* 1640 */   AfterFrameset {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/* 1642 */       if (isWhitespace(t))
/* 1643 */       { tb.insert(t.asCharacter()); }
/* 1644 */       else if (t.isComment())
/* 1645 */       { tb.insert(t.asComment()); }
/* 1646 */       else { if (t.isDoctype()) {
/* 1647 */           tb.error(this);
/* 1648 */           return false;
/* 1649 */         }  if (t.isStartTag() && t.asStartTag().normalName().equals("html"))
/* 1650 */           return tb.process(t, InBody); 
/* 1651 */         if (t.isEndTag() && t.asEndTag().normalName().equals("html"))
/* 1652 */         { tb.transition(AfterAfterFrameset); }
/* 1653 */         else { if (t.isStartTag() && t.asStartTag().normalName().equals("noframes"))
/* 1654 */             return tb.process(t, InHead); 
/* 1655 */           if (!t.isEOF())
/*      */           
/*      */           { 
/* 1658 */             tb.error(this);
/* 1659 */             return false; }  }
/*      */          }
/* 1661 */        return true;
/*      */     }
/*      */   },
/* 1664 */   AfterAfterBody {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/* 1666 */       if (t.isComment())
/* 1667 */       { tb.insert(t.asComment()); }
/* 1668 */       else { if (t.isDoctype() || (t.isStartTag() && t.asStartTag().normalName().equals("html")))
/* 1669 */           return tb.process(t, InBody); 
/* 1670 */         if (isWhitespace(t)) {
/*      */ 
/*      */ 
/*      */           
/* 1674 */           Element html = tb.popStackToClose("html");
/* 1675 */           tb.insert(t.asCharacter());
/* 1676 */           if (html != null) {
/* 1677 */             tb.stack.add(html);
/* 1678 */             Element body = html.selectFirst("body");
/* 1679 */             if (body != null) tb.stack.add(body); 
/*      */           } 
/* 1681 */         } else if (!t.isEOF()) {
/*      */ 
/*      */           
/* 1684 */           tb.error(this);
/* 1685 */           tb.transition(InBody);
/* 1686 */           return tb.process(t);
/*      */         }  }
/* 1688 */        return true;
/*      */     }
/*      */   },
/* 1691 */   AfterAfterFrameset {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/* 1693 */       if (t.isComment())
/* 1694 */       { tb.insert(t.asComment()); }
/* 1695 */       else { if (t.isDoctype() || isWhitespace(t) || (t.isStartTag() && t.asStartTag().normalName().equals("html")))
/* 1696 */           return tb.process(t, InBody); 
/* 1697 */         if (!t.isEOF()) {
/*      */           
/* 1699 */           if (t.isStartTag() && t.asStartTag().normalName().equals("noframes")) {
/* 1700 */             return tb.process(t, InHead);
/*      */           }
/* 1702 */           tb.error(this);
/* 1703 */           return false;
/*      */         }  }
/* 1705 */        return true;
/*      */     }
/*      */   },
/* 1708 */   ForeignContent {
/*      */     boolean process(Token t, HtmlTreeBuilder tb) {
/* 1710 */       return true;
/*      */     } };
/*      */   private static final String nullString;
/*      */   
/*      */   static {
/* 1715 */     nullString = String.valueOf(false);
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isWhitespace(Token t) {
/* 1720 */     if (t.isCharacter()) {
/* 1721 */       String data = t.asCharacter().getData();
/* 1722 */       return StringUtil.isBlank(data);
/*      */     } 
/* 1724 */     return false;
/*      */   }
/*      */   
/*      */   private static boolean isWhitespace(String data) {
/* 1728 */     return StringUtil.isBlank(data);
/*      */   }
/*      */   
/*      */   private static void handleRcData(Token.StartTag startTag, HtmlTreeBuilder tb) {
/* 1732 */     tb.tokeniser.transition(TokeniserState.Rcdata);
/* 1733 */     tb.markInsertionMode();
/* 1734 */     tb.transition(Text);
/* 1735 */     tb.insert(startTag);
/*      */   }
/*      */   
/*      */   private static void handleRawtext(Token.StartTag startTag, HtmlTreeBuilder tb) {
/* 1739 */     tb.tokeniser.transition(TokeniserState.Rawtext);
/* 1740 */     tb.markInsertionMode();
/* 1741 */     tb.transition(Text);
/* 1742 */     tb.insert(startTag);
/*      */   }
/*      */   
/*      */   abstract boolean process(Token paramToken, HtmlTreeBuilder paramHtmlTreeBuilder);
/*      */   
/* 1747 */   static final class Constants { static final String[] InHeadEmpty = new String[] { "base", "basefont", "bgsound", "command", "link" };
/* 1748 */     static final String[] InHeadRaw = new String[] { "noframes", "style" };
/* 1749 */     static final String[] InHeadEnd = new String[] { "body", "br", "html" };
/* 1750 */     static final String[] AfterHeadBody = new String[] { "body", "br", "html" };
/* 1751 */     static final String[] BeforeHtmlToHead = new String[] { "body", "br", "head", "html" };
/* 1752 */     static final String[] InHeadNoScriptHead = new String[] { "basefont", "bgsound", "link", "meta", "noframes", "style" };
/* 1753 */     static final String[] InBodyStartToHead = new String[] { "base", "basefont", "bgsound", "command", "link", "meta", "noframes", "script", "style", "template", "title" };
/* 1754 */     static final String[] InBodyStartPClosers = new String[] { "address", "article", "aside", "blockquote", "center", "details", "dir", "div", "dl", "fieldset", "figcaption", "figure", "footer", "header", "hgroup", "menu", "nav", "ol", "p", "section", "summary", "ul" };
/*      */ 
/*      */     
/* 1757 */     static final String[] Headings = new String[] { "h1", "h2", "h3", "h4", "h5", "h6" };
/* 1758 */     static final String[] InBodyStartLiBreakers = new String[] { "address", "div", "p" };
/* 1759 */     static final String[] DdDt = new String[] { "dd", "dt" };
/* 1760 */     static final String[] Formatters = new String[] { "b", "big", "code", "em", "font", "i", "s", "small", "strike", "strong", "tt", "u" };
/* 1761 */     static final String[] InBodyStartApplets = new String[] { "applet", "marquee", "object" };
/* 1762 */     static final String[] InBodyStartEmptyFormatters = new String[] { "area", "br", "embed", "img", "keygen", "wbr" };
/* 1763 */     static final String[] InBodyStartMedia = new String[] { "param", "source", "track" };
/* 1764 */     static final String[] InBodyStartInputAttribs = new String[] { "action", "name", "prompt" };
/* 1765 */     static final String[] InBodyStartDrop = new String[] { "caption", "col", "colgroup", "frame", "head", "tbody", "td", "tfoot", "th", "thead", "tr" };
/* 1766 */     static final String[] InBodyEndClosers = new String[] { "address", "article", "aside", "blockquote", "button", "center", "details", "dir", "div", "dl", "fieldset", "figcaption", "figure", "footer", "header", "hgroup", "listing", "menu", "nav", "ol", "pre", "section", "summary", "ul" };
/*      */ 
/*      */     
/* 1769 */     static final String[] InBodyEndAdoptionFormatters = new String[] { "a", "b", "big", "code", "em", "font", "i", "nobr", "s", "small", "strike", "strong", "tt", "u" };
/* 1770 */     static final String[] InBodyEndTableFosters = new String[] { "table", "tbody", "tfoot", "thead", "tr" };
/* 1771 */     static final String[] InTableToBody = new String[] { "tbody", "tfoot", "thead" };
/* 1772 */     static final String[] InTableAddBody = new String[] { "td", "th", "tr" };
/* 1773 */     static final String[] InTableToHead = new String[] { "script", "style", "template" };
/* 1774 */     static final String[] InCellNames = new String[] { "td", "th" };
/* 1775 */     static final String[] InCellBody = new String[] { "body", "caption", "col", "colgroup", "html" };
/* 1776 */     static final String[] InCellTable = new String[] { "table", "tbody", "tfoot", "thead", "tr" };
/* 1777 */     static final String[] InCellCol = new String[] { "caption", "col", "colgroup", "tbody", "td", "tfoot", "th", "thead", "tr" };
/* 1778 */     static final String[] InTableEndErr = new String[] { "body", "caption", "col", "colgroup", "html", "tbody", "td", "tfoot", "th", "thead", "tr" };
/* 1779 */     static final String[] InTableFoster = new String[] { "table", "tbody", "tfoot", "thead", "tr" };
/* 1780 */     static final String[] InTableBodyExit = new String[] { "caption", "col", "colgroup", "tbody", "tfoot", "thead" };
/* 1781 */     static final String[] InTableBodyEndIgnore = new String[] { "body", "caption", "col", "colgroup", "html", "td", "th", "tr" };
/* 1782 */     static final String[] InRowMissing = new String[] { "caption", "col", "colgroup", "tbody", "tfoot", "thead", "tr" };
/* 1783 */     static final String[] InRowIgnore = new String[] { "body", "caption", "col", "colgroup", "html", "td", "th" };
/* 1784 */     static final String[] InSelectEnd = new String[] { "input", "keygen", "textarea" };
/* 1785 */     static final String[] InSelectTableEnd = new String[] { "caption", "table", "tbody", "td", "tfoot", "th", "thead", "tr" };
/* 1786 */     static final String[] InTableEndIgnore = new String[] { "tbody", "tfoot", "thead" };
/* 1787 */     static final String[] InHeadNoscriptIgnore = new String[] { "head", "noscript" };
/* 1788 */     static final String[] InCaptionIgnore = new String[] { "body", "col", "colgroup", "html", "tbody", "td", "tfoot", "th", "thead", "tr" };
/* 1789 */     static final String[] InTemplateToHead = new String[] { "base", "basefont", "bgsound", "link", "meta", "noframes", "script", "style", "template", "title" };
/* 1790 */     static final String[] InTemplateToTable = new String[] { "caption", "colgroup", "tbody", "tfoot", "thead" }; }
/*      */ 
/*      */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\parser\HtmlTreeBuilderState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */