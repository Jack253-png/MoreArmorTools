/*      */ package org.jsoup.parser;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ enum TokeniserState
/*      */ {
/*    9 */   Data
/*      */   {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*   12 */       switch (r.current()) {
/*      */         case '&':
/*   14 */           t.advanceTransition(CharacterReferenceInData);
/*      */           return;
/*      */         case '<':
/*   17 */           t.advanceTransition(TagOpen);
/*      */           return;
/*      */         case '\000':
/*   20 */           t.error(this);
/*   21 */           t.emit(r.consume());
/*      */           return;
/*      */         case '￿':
/*   24 */           t.emit(new Token.EOF());
/*      */           return;
/*      */       } 
/*   27 */       String data = r.consumeData();
/*   28 */       t.emit(data);
/*      */     }
/*      */   },
/*      */ 
/*      */   
/*   33 */   CharacterReferenceInData
/*      */   {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*   36 */       readCharRef(t, Data);
/*      */     }
/*      */   },
/*   39 */   Rcdata
/*      */   {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*   42 */       switch (r.current()) {
/*      */         case '&':
/*   44 */           t.advanceTransition(CharacterReferenceInRcdata);
/*      */           return;
/*      */         case '<':
/*   47 */           t.advanceTransition(RcdataLessthanSign);
/*      */           return;
/*      */         case '\000':
/*   50 */           t.error(this);
/*   51 */           r.advance();
/*   52 */           t.emit('�');
/*      */           return;
/*      */         case '￿':
/*   55 */           t.emit(new Token.EOF());
/*      */           return;
/*      */       } 
/*   58 */       String data = r.consumeData();
/*   59 */       t.emit(data);
/*      */     }
/*      */   },
/*      */ 
/*      */   
/*   64 */   CharacterReferenceInRcdata {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*   66 */       readCharRef(t, Rcdata);
/*      */     }
/*      */   },
/*   69 */   Rawtext {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*   71 */       readRawData(t, r, this, RawtextLessthanSign);
/*      */     }
/*      */   },
/*   74 */   ScriptData {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*   76 */       readRawData(t, r, this, ScriptDataLessthanSign);
/*      */     }
/*      */   },
/*   79 */   PLAINTEXT {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*   81 */       switch (r.current()) {
/*      */         case '\000':
/*   83 */           t.error(this);
/*   84 */           r.advance();
/*   85 */           t.emit('�');
/*      */           return;
/*      */         case '￿':
/*   88 */           t.emit(new Token.EOF());
/*      */           return;
/*      */       } 
/*   91 */       String data = r.consumeTo(false);
/*   92 */       t.emit(data);
/*      */     }
/*      */   },
/*      */ 
/*      */   
/*   97 */   TagOpen
/*      */   {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  100 */       switch (r.current()) {
/*      */         case '!':
/*  102 */           t.advanceTransition(MarkupDeclarationOpen);
/*      */           return;
/*      */         case '/':
/*  105 */           t.advanceTransition(EndTagOpen);
/*      */           return;
/*      */         case '?':
/*  108 */           t.createBogusCommentPending();
/*  109 */           t.transition(BogusComment);
/*      */           return;
/*      */       } 
/*  112 */       if (r.matchesAsciiAlpha()) {
/*  113 */         t.createTagPending(true);
/*  114 */         t.transition(TagName);
/*      */       } else {
/*  116 */         t.error(this);
/*  117 */         t.emit('<');
/*  118 */         t.transition(Data);
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */   },
/*  124 */   EndTagOpen {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  126 */       if (r.isEmpty()) {
/*  127 */         t.eofError(this);
/*  128 */         t.emit("</");
/*  129 */         t.transition(Data);
/*  130 */       } else if (r.matchesAsciiAlpha()) {
/*  131 */         t.createTagPending(false);
/*  132 */         t.transition(TagName);
/*  133 */       } else if (r.matches('>')) {
/*  134 */         t.error(this);
/*  135 */         t.advanceTransition(Data);
/*      */       } else {
/*  137 */         t.error(this);
/*  138 */         t.createBogusCommentPending();
/*  139 */         t.commentPending.append('/');
/*  140 */         t.transition(BogusComment);
/*      */       } 
/*      */     }
/*      */   },
/*  144 */   TagName
/*      */   {
/*      */     void read(Tokeniser t, CharacterReader r)
/*      */     {
/*  148 */       String tagName = r.consumeTagName();
/*  149 */       t.tagPending.appendTagName(tagName);
/*      */       
/*  151 */       char c = r.consume();
/*  152 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/*  158 */           t.transition(BeforeAttributeName);
/*      */           return;
/*      */         case '/':
/*  161 */           t.transition(SelfClosingStartTag);
/*      */           return;
/*      */         case '<':
/*  164 */           r.unconsume();
/*  165 */           t.error(this);
/*      */         
/*      */         case '>':
/*  168 */           t.emitTagPending();
/*  169 */           t.transition(Data);
/*      */           return;
/*      */         case '\000':
/*  172 */           t.tagPending.appendTagName(TokeniserState.replacementStr);
/*      */           return;
/*      */         case '￿':
/*  175 */           t.eofError(this);
/*  176 */           t.transition(Data);
/*      */           return;
/*      */       } 
/*  179 */       t.tagPending.appendTagName(c);
/*      */     }
/*      */   },
/*      */   
/*  183 */   RcdataLessthanSign
/*      */   {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  186 */       if (r.matches('/')) {
/*  187 */         t.createTempBuffer();
/*  188 */         t.advanceTransition(RCDATAEndTagOpen);
/*  189 */       } else if (r.matchesAsciiAlpha() && t.appropriateEndTagName() != null && !r.containsIgnoreCase(t.appropriateEndTagSeq())) {
/*      */ 
/*      */         
/*  192 */         t.tagPending = t.createTagPending(false).name(t.appropriateEndTagName());
/*  193 */         t.emitTagPending();
/*  194 */         t.transition(TagOpen);
/*      */       } else {
/*  196 */         t.emit("<");
/*  197 */         t.transition(Rcdata);
/*      */       } 
/*      */     }
/*      */   },
/*  201 */   RCDATAEndTagOpen {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  203 */       if (r.matchesAsciiAlpha()) {
/*  204 */         t.createTagPending(false);
/*  205 */         t.tagPending.appendTagName(r.current());
/*  206 */         t.dataBuffer.append(r.current());
/*  207 */         t.advanceTransition(RCDATAEndTagName);
/*      */       } else {
/*  209 */         t.emit("</");
/*  210 */         t.transition(Rcdata);
/*      */       } 
/*      */     }
/*      */   },
/*  214 */   RCDATAEndTagName {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  216 */       if (r.matchesAsciiAlpha()) {
/*  217 */         String name = r.consumeLetterSequence();
/*  218 */         t.tagPending.appendTagName(name);
/*  219 */         t.dataBuffer.append(name);
/*      */         
/*      */         return;
/*      */       } 
/*  223 */       char c = r.consume();
/*  224 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/*  230 */           if (t.isAppropriateEndTagToken()) {
/*  231 */             t.transition(BeforeAttributeName);
/*      */           } else {
/*  233 */             anythingElse(t, r);
/*      */           }  return;
/*      */         case '/':
/*  236 */           if (t.isAppropriateEndTagToken()) {
/*  237 */             t.transition(SelfClosingStartTag);
/*      */           } else {
/*  239 */             anythingElse(t, r);
/*      */           }  return;
/*      */         case '>':
/*  242 */           if (t.isAppropriateEndTagToken()) {
/*  243 */             t.emitTagPending();
/*  244 */             t.transition(Data);
/*      */           } else {
/*      */             
/*  247 */             anythingElse(t, r);
/*      */           }  return;
/*      */       } 
/*  250 */       anythingElse(t, r);
/*      */     }
/*      */ 
/*      */     
/*      */     private void anythingElse(Tokeniser t, CharacterReader r) {
/*  255 */       t.emit("</");
/*  256 */       t.emit(t.dataBuffer);
/*  257 */       r.unconsume();
/*  258 */       t.transition(Rcdata);
/*      */     }
/*      */   },
/*  261 */   RawtextLessthanSign {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  263 */       if (r.matches('/')) {
/*  264 */         t.createTempBuffer();
/*  265 */         t.advanceTransition(RawtextEndTagOpen);
/*      */       } else {
/*  267 */         t.emit('<');
/*  268 */         t.transition(Rawtext);
/*      */       } 
/*      */     }
/*      */   },
/*  272 */   RawtextEndTagOpen {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  274 */       readEndTag(t, r, RawtextEndTagName, Rawtext);
/*      */     }
/*      */   },
/*  277 */   RawtextEndTagName {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  279 */       handleDataEndTag(t, r, Rawtext);
/*      */     }
/*      */   },
/*  282 */   ScriptDataLessthanSign {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  284 */       switch (r.consume()) {
/*      */         case '/':
/*  286 */           t.createTempBuffer();
/*  287 */           t.transition(ScriptDataEndTagOpen);
/*      */           return;
/*      */         case '!':
/*  290 */           t.emit("<!");
/*  291 */           t.transition(ScriptDataEscapeStart);
/*      */           return;
/*      */         case '￿':
/*  294 */           t.emit("<");
/*  295 */           t.eofError(this);
/*  296 */           t.transition(Data);
/*      */           return;
/*      */       } 
/*  299 */       t.emit("<");
/*  300 */       r.unconsume();
/*  301 */       t.transition(ScriptData);
/*      */     }
/*      */   },
/*      */   
/*  305 */   ScriptDataEndTagOpen {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  307 */       readEndTag(t, r, ScriptDataEndTagName, ScriptData);
/*      */     }
/*      */   },
/*  310 */   ScriptDataEndTagName {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  312 */       handleDataEndTag(t, r, ScriptData);
/*      */     }
/*      */   },
/*  315 */   ScriptDataEscapeStart {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  317 */       if (r.matches('-')) {
/*  318 */         t.emit('-');
/*  319 */         t.advanceTransition(ScriptDataEscapeStartDash);
/*      */       } else {
/*  321 */         t.transition(ScriptData);
/*      */       } 
/*      */     }
/*      */   },
/*  325 */   ScriptDataEscapeStartDash {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  327 */       if (r.matches('-')) {
/*  328 */         t.emit('-');
/*  329 */         t.advanceTransition(ScriptDataEscapedDashDash);
/*      */       } else {
/*  331 */         t.transition(ScriptData);
/*      */       } 
/*      */     }
/*      */   },
/*  335 */   ScriptDataEscaped {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  337 */       if (r.isEmpty()) {
/*  338 */         t.eofError(this);
/*  339 */         t.transition(Data);
/*      */         
/*      */         return;
/*      */       } 
/*  343 */       switch (r.current()) {
/*      */         case '-':
/*  345 */           t.emit('-');
/*  346 */           t.advanceTransition(ScriptDataEscapedDash);
/*      */           return;
/*      */         case '<':
/*  349 */           t.advanceTransition(ScriptDataEscapedLessthanSign);
/*      */           return;
/*      */         case '\000':
/*  352 */           t.error(this);
/*  353 */           r.advance();
/*  354 */           t.emit('�');
/*      */           return;
/*      */       } 
/*  357 */       String data = r.consumeToAny(new char[] { '-', '<', Character.MIN_VALUE });
/*  358 */       t.emit(data);
/*      */     }
/*      */   },
/*      */   
/*  362 */   ScriptDataEscapedDash {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  364 */       if (r.isEmpty()) {
/*  365 */         t.eofError(this);
/*  366 */         t.transition(Data);
/*      */         
/*      */         return;
/*      */       } 
/*  370 */       char c = r.consume();
/*  371 */       switch (c) {
/*      */         case '-':
/*  373 */           t.emit(c);
/*  374 */           t.transition(ScriptDataEscapedDashDash);
/*      */           return;
/*      */         case '<':
/*  377 */           t.transition(ScriptDataEscapedLessthanSign);
/*      */           return;
/*      */         case '\000':
/*  380 */           t.error(this);
/*  381 */           t.emit('�');
/*  382 */           t.transition(ScriptDataEscaped);
/*      */           return;
/*      */       } 
/*  385 */       t.emit(c);
/*  386 */       t.transition(ScriptDataEscaped);
/*      */     }
/*      */   },
/*      */   
/*  390 */   ScriptDataEscapedDashDash {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  392 */       if (r.isEmpty()) {
/*  393 */         t.eofError(this);
/*  394 */         t.transition(Data);
/*      */         
/*      */         return;
/*      */       } 
/*  398 */       char c = r.consume();
/*  399 */       switch (c) {
/*      */         case '-':
/*  401 */           t.emit(c);
/*      */           return;
/*      */         case '<':
/*  404 */           t.transition(ScriptDataEscapedLessthanSign);
/*      */           return;
/*      */         case '>':
/*  407 */           t.emit(c);
/*  408 */           t.transition(ScriptData);
/*      */           return;
/*      */         case '\000':
/*  411 */           t.error(this);
/*  412 */           t.emit('�');
/*  413 */           t.transition(ScriptDataEscaped);
/*      */           return;
/*      */       } 
/*  416 */       t.emit(c);
/*  417 */       t.transition(ScriptDataEscaped);
/*      */     }
/*      */   },
/*      */   
/*  421 */   ScriptDataEscapedLessthanSign {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  423 */       if (r.matchesAsciiAlpha()) {
/*  424 */         t.createTempBuffer();
/*  425 */         t.dataBuffer.append(r.current());
/*  426 */         t.emit("<");
/*  427 */         t.emit(r.current());
/*  428 */         t.advanceTransition(ScriptDataDoubleEscapeStart);
/*  429 */       } else if (r.matches('/')) {
/*  430 */         t.createTempBuffer();
/*  431 */         t.advanceTransition(ScriptDataEscapedEndTagOpen);
/*      */       } else {
/*  433 */         t.emit('<');
/*  434 */         t.transition(ScriptDataEscaped);
/*      */       } 
/*      */     }
/*      */   },
/*  438 */   ScriptDataEscapedEndTagOpen {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  440 */       if (r.matchesAsciiAlpha()) {
/*  441 */         t.createTagPending(false);
/*  442 */         t.tagPending.appendTagName(r.current());
/*  443 */         t.dataBuffer.append(r.current());
/*  444 */         t.advanceTransition(ScriptDataEscapedEndTagName);
/*      */       } else {
/*  446 */         t.emit("</");
/*  447 */         t.transition(ScriptDataEscaped);
/*      */       } 
/*      */     }
/*      */   },
/*  451 */   ScriptDataEscapedEndTagName {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  453 */       handleDataEndTag(t, r, ScriptDataEscaped);
/*      */     }
/*      */   },
/*  456 */   ScriptDataDoubleEscapeStart {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  458 */       handleDataDoubleEscapeTag(t, r, ScriptDataDoubleEscaped, ScriptDataEscaped);
/*      */     }
/*      */   },
/*  461 */   ScriptDataDoubleEscaped {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  463 */       char c = r.current();
/*  464 */       switch (c) {
/*      */         case '-':
/*  466 */           t.emit(c);
/*  467 */           t.advanceTransition(ScriptDataDoubleEscapedDash);
/*      */           return;
/*      */         case '<':
/*  470 */           t.emit(c);
/*  471 */           t.advanceTransition(ScriptDataDoubleEscapedLessthanSign);
/*      */           return;
/*      */         case '\000':
/*  474 */           t.error(this);
/*  475 */           r.advance();
/*  476 */           t.emit('�');
/*      */           return;
/*      */         case '￿':
/*  479 */           t.eofError(this);
/*  480 */           t.transition(Data);
/*      */           return;
/*      */       } 
/*  483 */       String data = r.consumeToAny(new char[] { '-', '<', Character.MIN_VALUE });
/*  484 */       t.emit(data);
/*      */     }
/*      */   },
/*      */   
/*  488 */   ScriptDataDoubleEscapedDash {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  490 */       char c = r.consume();
/*  491 */       switch (c) {
/*      */         case '-':
/*  493 */           t.emit(c);
/*  494 */           t.transition(ScriptDataDoubleEscapedDashDash);
/*      */           return;
/*      */         case '<':
/*  497 */           t.emit(c);
/*  498 */           t.transition(ScriptDataDoubleEscapedLessthanSign);
/*      */           return;
/*      */         case '\000':
/*  501 */           t.error(this);
/*  502 */           t.emit('�');
/*  503 */           t.transition(ScriptDataDoubleEscaped);
/*      */           return;
/*      */         case '￿':
/*  506 */           t.eofError(this);
/*  507 */           t.transition(Data);
/*      */           return;
/*      */       } 
/*  510 */       t.emit(c);
/*  511 */       t.transition(ScriptDataDoubleEscaped);
/*      */     }
/*      */   },
/*      */   
/*  515 */   ScriptDataDoubleEscapedDashDash {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  517 */       char c = r.consume();
/*  518 */       switch (c) {
/*      */         case '-':
/*  520 */           t.emit(c);
/*      */           return;
/*      */         case '<':
/*  523 */           t.emit(c);
/*  524 */           t.transition(ScriptDataDoubleEscapedLessthanSign);
/*      */           return;
/*      */         case '>':
/*  527 */           t.emit(c);
/*  528 */           t.transition(ScriptData);
/*      */           return;
/*      */         case '\000':
/*  531 */           t.error(this);
/*  532 */           t.emit('�');
/*  533 */           t.transition(ScriptDataDoubleEscaped);
/*      */           return;
/*      */         case '￿':
/*  536 */           t.eofError(this);
/*  537 */           t.transition(Data);
/*      */           return;
/*      */       } 
/*  540 */       t.emit(c);
/*  541 */       t.transition(ScriptDataDoubleEscaped);
/*      */     }
/*      */   },
/*      */   
/*  545 */   ScriptDataDoubleEscapedLessthanSign {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  547 */       if (r.matches('/')) {
/*  548 */         t.emit('/');
/*  549 */         t.createTempBuffer();
/*  550 */         t.advanceTransition(ScriptDataDoubleEscapeEnd);
/*      */       } else {
/*  552 */         t.transition(ScriptDataDoubleEscaped);
/*      */       } 
/*      */     }
/*      */   },
/*  556 */   ScriptDataDoubleEscapeEnd {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  558 */       handleDataDoubleEscapeTag(t, r, ScriptDataEscaped, ScriptDataDoubleEscaped);
/*      */     }
/*      */   },
/*  561 */   BeforeAttributeName
/*      */   {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  564 */       char c = r.consume();
/*  565 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/*      */           return;
/*      */         case '/':
/*  573 */           t.transition(SelfClosingStartTag);
/*      */         
/*      */         case '<':
/*  576 */           r.unconsume();
/*  577 */           t.error(this);
/*      */         
/*      */         case '>':
/*  580 */           t.emitTagPending();
/*  581 */           t.transition(Data);
/*      */         
/*      */         case '\000':
/*  584 */           r.unconsume();
/*  585 */           t.error(this);
/*  586 */           t.tagPending.newAttribute();
/*  587 */           t.transition(AttributeName);
/*      */         
/*      */         case '￿':
/*  590 */           t.eofError(this);
/*  591 */           t.transition(Data);
/*      */         
/*      */         case '"':
/*      */         case '\'':
/*      */         case '=':
/*  596 */           t.error(this);
/*  597 */           t.tagPending.newAttribute();
/*  598 */           t.tagPending.appendAttributeName(c);
/*  599 */           t.transition(AttributeName);
/*      */       } 
/*      */       
/*  602 */       t.tagPending.newAttribute();
/*  603 */       r.unconsume();
/*  604 */       t.transition(AttributeName);
/*      */     }
/*      */   },
/*      */   
/*  608 */   AttributeName
/*      */   {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  611 */       String name = r.consumeToAnySorted(attributeNameCharsSorted);
/*  612 */       t.tagPending.appendAttributeName(name);
/*      */       
/*  614 */       char c = r.consume();
/*  615 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/*  621 */           t.transition(AfterAttributeName);
/*      */           return;
/*      */         case '/':
/*  624 */           t.transition(SelfClosingStartTag);
/*      */           return;
/*      */         case '=':
/*  627 */           t.transition(BeforeAttributeValue);
/*      */           return;
/*      */         case '>':
/*  630 */           t.emitTagPending();
/*  631 */           t.transition(Data);
/*      */           return;
/*      */         case '￿':
/*  634 */           t.eofError(this);
/*  635 */           t.transition(Data);
/*      */           return;
/*      */         case '"':
/*      */         case '\'':
/*      */         case '<':
/*  640 */           t.error(this);
/*  641 */           t.tagPending.appendAttributeName(c);
/*      */           return;
/*      */       } 
/*  644 */       t.tagPending.appendAttributeName(c);
/*      */     }
/*      */   },
/*      */   
/*  648 */   AfterAttributeName {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  650 */       char c = r.consume();
/*  651 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/*      */           return;
/*      */         
/*      */         case '/':
/*  660 */           t.transition(SelfClosingStartTag);
/*      */         
/*      */         case '=':
/*  663 */           t.transition(BeforeAttributeValue);
/*      */         
/*      */         case '>':
/*  666 */           t.emitTagPending();
/*  667 */           t.transition(Data);
/*      */         
/*      */         case '\000':
/*  670 */           t.error(this);
/*  671 */           t.tagPending.appendAttributeName('�');
/*  672 */           t.transition(AttributeName);
/*      */         
/*      */         case '￿':
/*  675 */           t.eofError(this);
/*  676 */           t.transition(Data);
/*      */         
/*      */         case '"':
/*      */         case '\'':
/*      */         case '<':
/*  681 */           t.error(this);
/*  682 */           t.tagPending.newAttribute();
/*  683 */           t.tagPending.appendAttributeName(c);
/*  684 */           t.transition(AttributeName);
/*      */       } 
/*      */       
/*  687 */       t.tagPending.newAttribute();
/*  688 */       r.unconsume();
/*  689 */       t.transition(AttributeName);
/*      */     }
/*      */   },
/*      */   
/*  693 */   BeforeAttributeValue {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  695 */       char c = r.consume();
/*  696 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/*      */           return;
/*      */         
/*      */         case '"':
/*  705 */           t.transition(AttributeValue_doubleQuoted);
/*      */         
/*      */         case '&':
/*  708 */           r.unconsume();
/*  709 */           t.transition(AttributeValue_unquoted);
/*      */         
/*      */         case '\'':
/*  712 */           t.transition(AttributeValue_singleQuoted);
/*      */         
/*      */         case '\000':
/*  715 */           t.error(this);
/*  716 */           t.tagPending.appendAttributeValue('�');
/*  717 */           t.transition(AttributeValue_unquoted);
/*      */         
/*      */         case '￿':
/*  720 */           t.eofError(this);
/*  721 */           t.emitTagPending();
/*  722 */           t.transition(Data);
/*      */         
/*      */         case '>':
/*  725 */           t.error(this);
/*  726 */           t.emitTagPending();
/*  727 */           t.transition(Data);
/*      */         
/*      */         case '<':
/*      */         case '=':
/*      */         case '`':
/*  732 */           t.error(this);
/*  733 */           t.tagPending.appendAttributeValue(c);
/*  734 */           t.transition(AttributeValue_unquoted);
/*      */       } 
/*      */       
/*  737 */       r.unconsume();
/*  738 */       t.transition(AttributeValue_unquoted);
/*      */     }
/*      */   },
/*      */   
/*  742 */   AttributeValue_doubleQuoted { void read(Tokeniser t, CharacterReader r) {
/*      */       int[] ref;
/*  744 */       String value = r.consumeAttributeQuoted(false);
/*  745 */       if (value.length() > 0) {
/*  746 */         t.tagPending.appendAttributeValue(value);
/*      */       } else {
/*  748 */         t.tagPending.setEmptyAttributeValue();
/*      */       } 
/*  750 */       char c = r.consume();
/*  751 */       switch (c) {
/*      */         case '"':
/*  753 */           t.transition(AfterAttributeValue_quoted);
/*      */           return;
/*      */         case '&':
/*  756 */           ref = t.consumeCharacterReference(Character.valueOf('"'), true);
/*  757 */           if (ref != null) {
/*  758 */             t.tagPending.appendAttributeValue(ref);
/*      */           } else {
/*  760 */             t.tagPending.appendAttributeValue('&');
/*      */           }  return;
/*      */         case '\000':
/*  763 */           t.error(this);
/*  764 */           t.tagPending.appendAttributeValue('�');
/*      */           return;
/*      */         case '￿':
/*  767 */           t.eofError(this);
/*  768 */           t.transition(Data);
/*      */           return;
/*      */       } 
/*  771 */       t.tagPending.appendAttributeValue(c);
/*      */     } }
/*      */   ,
/*      */   
/*  775 */   AttributeValue_singleQuoted { void read(Tokeniser t, CharacterReader r) {
/*      */       int[] ref;
/*  777 */       String value = r.consumeAttributeQuoted(true);
/*  778 */       if (value.length() > 0) {
/*  779 */         t.tagPending.appendAttributeValue(value);
/*      */       } else {
/*  781 */         t.tagPending.setEmptyAttributeValue();
/*      */       } 
/*  783 */       char c = r.consume();
/*  784 */       switch (c) {
/*      */         case '\'':
/*  786 */           t.transition(AfterAttributeValue_quoted);
/*      */           return;
/*      */         case '&':
/*  789 */           ref = t.consumeCharacterReference(Character.valueOf('\''), true);
/*  790 */           if (ref != null) {
/*  791 */             t.tagPending.appendAttributeValue(ref);
/*      */           } else {
/*  793 */             t.tagPending.appendAttributeValue('&');
/*      */           }  return;
/*      */         case '\000':
/*  796 */           t.error(this);
/*  797 */           t.tagPending.appendAttributeValue('�');
/*      */           return;
/*      */         case '￿':
/*  800 */           t.eofError(this);
/*  801 */           t.transition(Data);
/*      */           return;
/*      */       } 
/*  804 */       t.tagPending.appendAttributeValue(c);
/*      */     } }
/*      */   ,
/*      */   
/*  808 */   AttributeValue_unquoted { void read(Tokeniser t, CharacterReader r) {
/*      */       int[] ref;
/*  810 */       String value = r.consumeToAnySorted(attributeValueUnquoted);
/*  811 */       if (value.length() > 0) {
/*  812 */         t.tagPending.appendAttributeValue(value);
/*      */       }
/*  814 */       char c = r.consume();
/*  815 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/*  821 */           t.transition(BeforeAttributeName);
/*      */           return;
/*      */         case '&':
/*  824 */           ref = t.consumeCharacterReference(Character.valueOf('>'), true);
/*  825 */           if (ref != null) {
/*  826 */             t.tagPending.appendAttributeValue(ref);
/*      */           } else {
/*  828 */             t.tagPending.appendAttributeValue('&');
/*      */           }  return;
/*      */         case '>':
/*  831 */           t.emitTagPending();
/*  832 */           t.transition(Data);
/*      */           return;
/*      */         case '\000':
/*  835 */           t.error(this);
/*  836 */           t.tagPending.appendAttributeValue('�');
/*      */           return;
/*      */         case '￿':
/*  839 */           t.eofError(this);
/*  840 */           t.transition(Data);
/*      */           return;
/*      */         case '"':
/*      */         case '\'':
/*      */         case '<':
/*      */         case '=':
/*      */         case '`':
/*  847 */           t.error(this);
/*  848 */           t.tagPending.appendAttributeValue(c);
/*      */           return;
/*      */       } 
/*  851 */       t.tagPending.appendAttributeValue(c);
/*      */     } }
/*      */   ,
/*      */ 
/*      */ 
/*      */   
/*  857 */   AfterAttributeValue_quoted {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  859 */       char c = r.consume();
/*  860 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/*  866 */           t.transition(BeforeAttributeName);
/*      */           return;
/*      */         case '/':
/*  869 */           t.transition(SelfClosingStartTag);
/*      */           return;
/*      */         case '>':
/*  872 */           t.emitTagPending();
/*  873 */           t.transition(Data);
/*      */           return;
/*      */         case '￿':
/*  876 */           t.eofError(this);
/*  877 */           t.transition(Data);
/*      */           return;
/*      */       } 
/*  880 */       r.unconsume();
/*  881 */       t.error(this);
/*  882 */       t.transition(BeforeAttributeName);
/*      */     }
/*      */   },
/*      */ 
/*      */   
/*  887 */   SelfClosingStartTag {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  889 */       char c = r.consume();
/*  890 */       switch (c) {
/*      */         case '>':
/*  892 */           t.tagPending.selfClosing = true;
/*  893 */           t.emitTagPending();
/*  894 */           t.transition(Data);
/*      */           return;
/*      */         case '￿':
/*  897 */           t.eofError(this);
/*  898 */           t.transition(Data);
/*      */           return;
/*      */       } 
/*  901 */       r.unconsume();
/*  902 */       t.error(this);
/*  903 */       t.transition(BeforeAttributeName);
/*      */     }
/*      */   },
/*      */   
/*  907 */   BogusComment
/*      */   {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  910 */       t.commentPending.append(r.consumeTo('>'));
/*      */       
/*  912 */       char next = r.current();
/*  913 */       if (next == '>' || next == Character.MAX_VALUE) {
/*  914 */         r.consume();
/*  915 */         t.emitCommentPending();
/*  916 */         t.transition(Data);
/*      */       } 
/*      */     }
/*      */   },
/*  920 */   MarkupDeclarationOpen {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  922 */       if (r.matchConsume("--")) {
/*  923 */         t.createCommentPending();
/*  924 */         t.transition(CommentStart);
/*  925 */       } else if (r.matchConsumeIgnoreCase("DOCTYPE")) {
/*  926 */         t.transition(Doctype);
/*  927 */       } else if (r.matchConsume("[CDATA[")) {
/*      */ 
/*      */ 
/*      */         
/*  931 */         t.createTempBuffer();
/*  932 */         t.transition(CdataSection);
/*      */       } else {
/*  934 */         t.error(this);
/*  935 */         t.createBogusCommentPending();
/*  936 */         t.transition(BogusComment);
/*      */       } 
/*      */     }
/*      */   },
/*  940 */   CommentStart {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  942 */       char c = r.consume();
/*  943 */       switch (c) {
/*      */         case '-':
/*  945 */           t.transition(CommentStartDash);
/*      */           return;
/*      */         case '\000':
/*  948 */           t.error(this);
/*  949 */           t.commentPending.append('�');
/*  950 */           t.transition(Comment);
/*      */           return;
/*      */         case '>':
/*  953 */           t.error(this);
/*  954 */           t.emitCommentPending();
/*  955 */           t.transition(Data);
/*      */           return;
/*      */         case '￿':
/*  958 */           t.eofError(this);
/*  959 */           t.emitCommentPending();
/*  960 */           t.transition(Data);
/*      */           return;
/*      */       } 
/*  963 */       r.unconsume();
/*  964 */       t.transition(Comment);
/*      */     }
/*      */   },
/*      */   
/*  968 */   CommentStartDash {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  970 */       char c = r.consume();
/*  971 */       switch (c) {
/*      */         case '-':
/*  973 */           t.transition(CommentStartDash);
/*      */           return;
/*      */         case '\000':
/*  976 */           t.error(this);
/*  977 */           t.commentPending.append('�');
/*  978 */           t.transition(Comment);
/*      */           return;
/*      */         case '>':
/*  981 */           t.error(this);
/*  982 */           t.emitCommentPending();
/*  983 */           t.transition(Data);
/*      */           return;
/*      */         case '￿':
/*  986 */           t.eofError(this);
/*  987 */           t.emitCommentPending();
/*  988 */           t.transition(Data);
/*      */           return;
/*      */       } 
/*  991 */       t.commentPending.append(c);
/*  992 */       t.transition(Comment);
/*      */     }
/*      */   },
/*      */   
/*  996 */   Comment {
/*      */     void read(Tokeniser t, CharacterReader r) {
/*  998 */       char c = r.current();
/*  999 */       switch (c) {
/*      */         case '-':
/* 1001 */           t.advanceTransition(CommentEndDash);
/*      */           return;
/*      */         case '\000':
/* 1004 */           t.error(this);
/* 1005 */           r.advance();
/* 1006 */           t.commentPending.append('�');
/*      */           return;
/*      */         case '￿':
/* 1009 */           t.eofError(this);
/* 1010 */           t.emitCommentPending();
/* 1011 */           t.transition(Data);
/*      */           return;
/*      */       } 
/* 1014 */       t.commentPending.append(r.consumeToAny(new char[] { '-', Character.MIN_VALUE
/*      */             }));
/*      */     }
/*      */   },
/* 1018 */   CommentEndDash {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1020 */       char c = r.consume();
/* 1021 */       switch (c) {
/*      */         case '-':
/* 1023 */           t.transition(CommentEnd);
/*      */           return;
/*      */         case '\000':
/* 1026 */           t.error(this);
/* 1027 */           t.commentPending.append('-').append('�');
/* 1028 */           t.transition(Comment);
/*      */           return;
/*      */         case '￿':
/* 1031 */           t.eofError(this);
/* 1032 */           t.emitCommentPending();
/* 1033 */           t.transition(Data);
/*      */           return;
/*      */       } 
/* 1036 */       t.commentPending.append('-').append(c);
/* 1037 */       t.transition(Comment);
/*      */     }
/*      */   },
/*      */   
/* 1041 */   CommentEnd {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1043 */       char c = r.consume();
/* 1044 */       switch (c) {
/*      */         case '>':
/* 1046 */           t.emitCommentPending();
/* 1047 */           t.transition(Data);
/*      */           return;
/*      */         case '\000':
/* 1050 */           t.error(this);
/* 1051 */           t.commentPending.append("--").append('�');
/* 1052 */           t.transition(Comment);
/*      */           return;
/*      */         case '!':
/* 1055 */           t.error(this);
/* 1056 */           t.transition(CommentEndBang);
/*      */           return;
/*      */         case '-':
/* 1059 */           t.error(this);
/* 1060 */           t.commentPending.append('-');
/*      */           return;
/*      */         case '￿':
/* 1063 */           t.eofError(this);
/* 1064 */           t.emitCommentPending();
/* 1065 */           t.transition(Data);
/*      */           return;
/*      */       } 
/* 1068 */       t.error(this);
/* 1069 */       t.commentPending.append("--").append(c);
/* 1070 */       t.transition(Comment);
/*      */     }
/*      */   },
/*      */   
/* 1074 */   CommentEndBang {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1076 */       char c = r.consume();
/* 1077 */       switch (c) {
/*      */         case '-':
/* 1079 */           t.commentPending.append("--!");
/* 1080 */           t.transition(CommentEndDash);
/*      */           return;
/*      */         case '>':
/* 1083 */           t.emitCommentPending();
/* 1084 */           t.transition(Data);
/*      */           return;
/*      */         case '\000':
/* 1087 */           t.error(this);
/* 1088 */           t.commentPending.append("--!").append('�');
/* 1089 */           t.transition(Comment);
/*      */           return;
/*      */         case '￿':
/* 1092 */           t.eofError(this);
/* 1093 */           t.emitCommentPending();
/* 1094 */           t.transition(Data);
/*      */           return;
/*      */       } 
/* 1097 */       t.commentPending.append("--!").append(c);
/* 1098 */       t.transition(Comment);
/*      */     }
/*      */   },
/*      */   
/* 1102 */   Doctype {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1104 */       char c = r.consume();
/* 1105 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/* 1111 */           t.transition(BeforeDoctypeName);
/*      */           return;
/*      */         case '￿':
/* 1114 */           t.eofError(this);
/*      */         
/*      */         case '>':
/* 1117 */           t.error(this);
/* 1118 */           t.createDoctypePending();
/* 1119 */           t.doctypePending.forceQuirks = true;
/* 1120 */           t.emitDoctypePending();
/* 1121 */           t.transition(Data);
/*      */           return;
/*      */       } 
/* 1124 */       t.error(this);
/* 1125 */       t.transition(BeforeDoctypeName);
/*      */     }
/*      */   },
/*      */   
/* 1129 */   BeforeDoctypeName {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1131 */       if (r.matchesAsciiAlpha()) {
/* 1132 */         t.createDoctypePending();
/* 1133 */         t.transition(DoctypeName);
/*      */         return;
/*      */       } 
/* 1136 */       char c = r.consume();
/* 1137 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/*      */           return;
/*      */         case '\000':
/* 1145 */           t.error(this);
/* 1146 */           t.createDoctypePending();
/* 1147 */           t.doctypePending.name.append('�');
/* 1148 */           t.transition(DoctypeName);
/*      */         
/*      */         case '￿':
/* 1151 */           t.eofError(this);
/* 1152 */           t.createDoctypePending();
/* 1153 */           t.doctypePending.forceQuirks = true;
/* 1154 */           t.emitDoctypePending();
/* 1155 */           t.transition(Data);
/*      */       } 
/*      */       
/* 1158 */       t.createDoctypePending();
/* 1159 */       t.doctypePending.name.append(c);
/* 1160 */       t.transition(DoctypeName);
/*      */     }
/*      */   },
/*      */   
/* 1164 */   DoctypeName {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1166 */       if (r.matchesLetter()) {
/* 1167 */         String name = r.consumeLetterSequence();
/* 1168 */         t.doctypePending.name.append(name);
/*      */         return;
/*      */       } 
/* 1171 */       char c = r.consume();
/* 1172 */       switch (c) {
/*      */         case '>':
/* 1174 */           t.emitDoctypePending();
/* 1175 */           t.transition(Data);
/*      */           return;
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/* 1182 */           t.transition(AfterDoctypeName);
/*      */           return;
/*      */         case '\000':
/* 1185 */           t.error(this);
/* 1186 */           t.doctypePending.name.append('�');
/*      */           return;
/*      */         case '￿':
/* 1189 */           t.eofError(this);
/* 1190 */           t.doctypePending.forceQuirks = true;
/* 1191 */           t.emitDoctypePending();
/* 1192 */           t.transition(Data);
/*      */           return;
/*      */       } 
/* 1195 */       t.doctypePending.name.append(c);
/*      */     }
/*      */   },
/*      */   
/* 1199 */   AfterDoctypeName {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1201 */       if (r.isEmpty()) {
/* 1202 */         t.eofError(this);
/* 1203 */         t.doctypePending.forceQuirks = true;
/* 1204 */         t.emitDoctypePending();
/* 1205 */         t.transition(Data);
/*      */         return;
/*      */       } 
/* 1208 */       if (r.matchesAny(new char[] { '\t', '\n', '\r', '\f', ' ' })) {
/* 1209 */         r.advance();
/* 1210 */       } else if (r.matches('>')) {
/* 1211 */         t.emitDoctypePending();
/* 1212 */         t.advanceTransition(Data);
/* 1213 */       } else if (r.matchConsumeIgnoreCase("PUBLIC")) {
/* 1214 */         t.doctypePending.pubSysKey = "PUBLIC";
/* 1215 */         t.transition(AfterDoctypePublicKeyword);
/* 1216 */       } else if (r.matchConsumeIgnoreCase("SYSTEM")) {
/* 1217 */         t.doctypePending.pubSysKey = "SYSTEM";
/* 1218 */         t.transition(AfterDoctypeSystemKeyword);
/*      */       } else {
/* 1220 */         t.error(this);
/* 1221 */         t.doctypePending.forceQuirks = true;
/* 1222 */         t.advanceTransition(BogusDoctype);
/*      */       }
/*      */     
/*      */     }
/*      */   },
/* 1227 */   AfterDoctypePublicKeyword {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1229 */       char c = r.consume();
/* 1230 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/* 1236 */           t.transition(BeforeDoctypePublicIdentifier);
/*      */           return;
/*      */         case '"':
/* 1239 */           t.error(this);
/*      */           
/* 1241 */           t.transition(DoctypePublicIdentifier_doubleQuoted);
/*      */           return;
/*      */         case '\'':
/* 1244 */           t.error(this);
/*      */           
/* 1246 */           t.transition(DoctypePublicIdentifier_singleQuoted);
/*      */           return;
/*      */         case '>':
/* 1249 */           t.error(this);
/* 1250 */           t.doctypePending.forceQuirks = true;
/* 1251 */           t.emitDoctypePending();
/* 1252 */           t.transition(Data);
/*      */           return;
/*      */         case '￿':
/* 1255 */           t.eofError(this);
/* 1256 */           t.doctypePending.forceQuirks = true;
/* 1257 */           t.emitDoctypePending();
/* 1258 */           t.transition(Data);
/*      */           return;
/*      */       } 
/* 1261 */       t.error(this);
/* 1262 */       t.doctypePending.forceQuirks = true;
/* 1263 */       t.transition(BogusDoctype);
/*      */     }
/*      */   },
/*      */   
/* 1267 */   BeforeDoctypePublicIdentifier {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1269 */       char c = r.consume();
/* 1270 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/*      */           return;
/*      */         
/*      */         case '"':
/* 1279 */           t.transition(DoctypePublicIdentifier_doubleQuoted);
/*      */ 
/*      */         
/*      */         case '\'':
/* 1283 */           t.transition(DoctypePublicIdentifier_singleQuoted);
/*      */         
/*      */         case '>':
/* 1286 */           t.error(this);
/* 1287 */           t.doctypePending.forceQuirks = true;
/* 1288 */           t.emitDoctypePending();
/* 1289 */           t.transition(Data);
/*      */         
/*      */         case '￿':
/* 1292 */           t.eofError(this);
/* 1293 */           t.doctypePending.forceQuirks = true;
/* 1294 */           t.emitDoctypePending();
/* 1295 */           t.transition(Data);
/*      */       } 
/*      */       
/* 1298 */       t.error(this);
/* 1299 */       t.doctypePending.forceQuirks = true;
/* 1300 */       t.transition(BogusDoctype);
/*      */     }
/*      */   },
/*      */   
/* 1304 */   DoctypePublicIdentifier_doubleQuoted {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1306 */       char c = r.consume();
/* 1307 */       switch (c) {
/*      */         case '"':
/* 1309 */           t.transition(AfterDoctypePublicIdentifier);
/*      */           return;
/*      */         case '\000':
/* 1312 */           t.error(this);
/* 1313 */           t.doctypePending.publicIdentifier.append('�');
/*      */           return;
/*      */         case '>':
/* 1316 */           t.error(this);
/* 1317 */           t.doctypePending.forceQuirks = true;
/* 1318 */           t.emitDoctypePending();
/* 1319 */           t.transition(Data);
/*      */           return;
/*      */         case '￿':
/* 1322 */           t.eofError(this);
/* 1323 */           t.doctypePending.forceQuirks = true;
/* 1324 */           t.emitDoctypePending();
/* 1325 */           t.transition(Data);
/*      */           return;
/*      */       } 
/* 1328 */       t.doctypePending.publicIdentifier.append(c);
/*      */     }
/*      */   },
/*      */   
/* 1332 */   DoctypePublicIdentifier_singleQuoted {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1334 */       char c = r.consume();
/* 1335 */       switch (c) {
/*      */         case '\'':
/* 1337 */           t.transition(AfterDoctypePublicIdentifier);
/*      */           return;
/*      */         case '\000':
/* 1340 */           t.error(this);
/* 1341 */           t.doctypePending.publicIdentifier.append('�');
/*      */           return;
/*      */         case '>':
/* 1344 */           t.error(this);
/* 1345 */           t.doctypePending.forceQuirks = true;
/* 1346 */           t.emitDoctypePending();
/* 1347 */           t.transition(Data);
/*      */           return;
/*      */         case '￿':
/* 1350 */           t.eofError(this);
/* 1351 */           t.doctypePending.forceQuirks = true;
/* 1352 */           t.emitDoctypePending();
/* 1353 */           t.transition(Data);
/*      */           return;
/*      */       } 
/* 1356 */       t.doctypePending.publicIdentifier.append(c);
/*      */     }
/*      */   },
/*      */   
/* 1360 */   AfterDoctypePublicIdentifier {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1362 */       char c = r.consume();
/* 1363 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/* 1369 */           t.transition(BetweenDoctypePublicAndSystemIdentifiers);
/*      */           return;
/*      */         case '>':
/* 1372 */           t.emitDoctypePending();
/* 1373 */           t.transition(Data);
/*      */           return;
/*      */         case '"':
/* 1376 */           t.error(this);
/*      */           
/* 1378 */           t.transition(DoctypeSystemIdentifier_doubleQuoted);
/*      */           return;
/*      */         case '\'':
/* 1381 */           t.error(this);
/*      */           
/* 1383 */           t.transition(DoctypeSystemIdentifier_singleQuoted);
/*      */           return;
/*      */         case '￿':
/* 1386 */           t.eofError(this);
/* 1387 */           t.doctypePending.forceQuirks = true;
/* 1388 */           t.emitDoctypePending();
/* 1389 */           t.transition(Data);
/*      */           return;
/*      */       } 
/* 1392 */       t.error(this);
/* 1393 */       t.doctypePending.forceQuirks = true;
/* 1394 */       t.transition(BogusDoctype);
/*      */     }
/*      */   },
/*      */   
/* 1398 */   BetweenDoctypePublicAndSystemIdentifiers {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1400 */       char c = r.consume();
/* 1401 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/*      */           return;
/*      */         case '>':
/* 1409 */           t.emitDoctypePending();
/* 1410 */           t.transition(Data);
/*      */         
/*      */         case '"':
/* 1413 */           t.error(this);
/*      */           
/* 1415 */           t.transition(DoctypeSystemIdentifier_doubleQuoted);
/*      */         
/*      */         case '\'':
/* 1418 */           t.error(this);
/*      */           
/* 1420 */           t.transition(DoctypeSystemIdentifier_singleQuoted);
/*      */         
/*      */         case '￿':
/* 1423 */           t.eofError(this);
/* 1424 */           t.doctypePending.forceQuirks = true;
/* 1425 */           t.emitDoctypePending();
/* 1426 */           t.transition(Data);
/*      */       } 
/*      */       
/* 1429 */       t.error(this);
/* 1430 */       t.doctypePending.forceQuirks = true;
/* 1431 */       t.transition(BogusDoctype);
/*      */     }
/*      */   },
/*      */   
/* 1435 */   AfterDoctypeSystemKeyword {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1437 */       char c = r.consume();
/* 1438 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/* 1444 */           t.transition(BeforeDoctypeSystemIdentifier);
/*      */           return;
/*      */         case '>':
/* 1447 */           t.error(this);
/* 1448 */           t.doctypePending.forceQuirks = true;
/* 1449 */           t.emitDoctypePending();
/* 1450 */           t.transition(Data);
/*      */           return;
/*      */         case '"':
/* 1453 */           t.error(this);
/*      */           
/* 1455 */           t.transition(DoctypeSystemIdentifier_doubleQuoted);
/*      */           return;
/*      */         case '\'':
/* 1458 */           t.error(this);
/*      */           
/* 1460 */           t.transition(DoctypeSystemIdentifier_singleQuoted);
/*      */           return;
/*      */         case '￿':
/* 1463 */           t.eofError(this);
/* 1464 */           t.doctypePending.forceQuirks = true;
/* 1465 */           t.emitDoctypePending();
/* 1466 */           t.transition(Data);
/*      */           return;
/*      */       } 
/* 1469 */       t.error(this);
/* 1470 */       t.doctypePending.forceQuirks = true;
/* 1471 */       t.emitDoctypePending();
/*      */     }
/*      */   },
/*      */   
/* 1475 */   BeforeDoctypeSystemIdentifier {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1477 */       char c = r.consume();
/* 1478 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/*      */           return;
/*      */         
/*      */         case '"':
/* 1487 */           t.transition(DoctypeSystemIdentifier_doubleQuoted);
/*      */ 
/*      */         
/*      */         case '\'':
/* 1491 */           t.transition(DoctypeSystemIdentifier_singleQuoted);
/*      */         
/*      */         case '>':
/* 1494 */           t.error(this);
/* 1495 */           t.doctypePending.forceQuirks = true;
/* 1496 */           t.emitDoctypePending();
/* 1497 */           t.transition(Data);
/*      */         
/*      */         case '￿':
/* 1500 */           t.eofError(this);
/* 1501 */           t.doctypePending.forceQuirks = true;
/* 1502 */           t.emitDoctypePending();
/* 1503 */           t.transition(Data);
/*      */       } 
/*      */       
/* 1506 */       t.error(this);
/* 1507 */       t.doctypePending.forceQuirks = true;
/* 1508 */       t.transition(BogusDoctype);
/*      */     }
/*      */   },
/*      */   
/* 1512 */   DoctypeSystemIdentifier_doubleQuoted {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1514 */       char c = r.consume();
/* 1515 */       switch (c) {
/*      */         case '"':
/* 1517 */           t.transition(AfterDoctypeSystemIdentifier);
/*      */           return;
/*      */         case '\000':
/* 1520 */           t.error(this);
/* 1521 */           t.doctypePending.systemIdentifier.append('�');
/*      */           return;
/*      */         case '>':
/* 1524 */           t.error(this);
/* 1525 */           t.doctypePending.forceQuirks = true;
/* 1526 */           t.emitDoctypePending();
/* 1527 */           t.transition(Data);
/*      */           return;
/*      */         case '￿':
/* 1530 */           t.eofError(this);
/* 1531 */           t.doctypePending.forceQuirks = true;
/* 1532 */           t.emitDoctypePending();
/* 1533 */           t.transition(Data);
/*      */           return;
/*      */       } 
/* 1536 */       t.doctypePending.systemIdentifier.append(c);
/*      */     }
/*      */   },
/*      */   
/* 1540 */   DoctypeSystemIdentifier_singleQuoted {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1542 */       char c = r.consume();
/* 1543 */       switch (c) {
/*      */         case '\'':
/* 1545 */           t.transition(AfterDoctypeSystemIdentifier);
/*      */           return;
/*      */         case '\000':
/* 1548 */           t.error(this);
/* 1549 */           t.doctypePending.systemIdentifier.append('�');
/*      */           return;
/*      */         case '>':
/* 1552 */           t.error(this);
/* 1553 */           t.doctypePending.forceQuirks = true;
/* 1554 */           t.emitDoctypePending();
/* 1555 */           t.transition(Data);
/*      */           return;
/*      */         case '￿':
/* 1558 */           t.eofError(this);
/* 1559 */           t.doctypePending.forceQuirks = true;
/* 1560 */           t.emitDoctypePending();
/* 1561 */           t.transition(Data);
/*      */           return;
/*      */       } 
/* 1564 */       t.doctypePending.systemIdentifier.append(c);
/*      */     }
/*      */   },
/*      */   
/* 1568 */   AfterDoctypeSystemIdentifier {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1570 */       char c = r.consume();
/* 1571 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/*      */           return;
/*      */         case '>':
/* 1579 */           t.emitDoctypePending();
/* 1580 */           t.transition(Data);
/*      */         
/*      */         case '￿':
/* 1583 */           t.eofError(this);
/* 1584 */           t.doctypePending.forceQuirks = true;
/* 1585 */           t.emitDoctypePending();
/* 1586 */           t.transition(Data);
/*      */       } 
/*      */       
/* 1589 */       t.error(this);
/* 1590 */       t.transition(BogusDoctype);
/*      */     }
/*      */   },
/*      */ 
/*      */   
/* 1595 */   BogusDoctype {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1597 */       char c = r.consume();
/* 1598 */       switch (c) {
/*      */         case '>':
/* 1600 */           t.emitDoctypePending();
/* 1601 */           t.transition(Data);
/*      */           break;
/*      */         case '￿':
/* 1604 */           t.emitDoctypePending();
/* 1605 */           t.transition(Data);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */   },
/* 1613 */   CdataSection {
/*      */     void read(Tokeniser t, CharacterReader r) {
/* 1615 */       String data = r.consumeTo("]]>");
/* 1616 */       t.dataBuffer.append(data);
/* 1617 */       if (r.matchConsume("]]>") || r.isEmpty()) {
/* 1618 */         t.emit(new Token.CData(t.dataBuffer.toString()));
/* 1619 */         t.transition(Data);
/*      */       } 
/*      */     }
/*      */   };
/*      */   
/*      */   static final char nullChar = '\000';
/*      */   static final char[] attributeNameCharsSorted;
/*      */   static final char[] attributeValueUnquoted;
/*      */   
/*      */   static {
/* 1629 */     attributeNameCharsSorted = new char[] { '\t', '\n', '\f', '\r', ' ', '"', '\'', '/', '<', '=', '>' };
/* 1630 */     attributeValueUnquoted = new char[] { Character.MIN_VALUE, '\t', '\n', '\f', '\r', ' ', '"', '&', '\'', '<', '=', '>', '`' };
/*      */ 
/*      */     
/* 1633 */     replacementStr = String.valueOf('�');
/*      */   }
/*      */   
/*      */   private static final char replacementChar = '�';
/*      */   private static final String replacementStr;
/*      */   private static final char eof = '￿';
/*      */   
/*      */   private static void handleDataEndTag(Tokeniser t, CharacterReader r, TokeniserState elseTransition) {
/* 1641 */     if (r.matchesLetter()) {
/* 1642 */       String name = r.consumeLetterSequence();
/* 1643 */       t.tagPending.appendTagName(name);
/* 1644 */       t.dataBuffer.append(name);
/*      */       
/*      */       return;
/*      */     } 
/* 1648 */     boolean needsExitTransition = false;
/* 1649 */     if (t.isAppropriateEndTagToken() && !r.isEmpty()) {
/* 1650 */       char c = r.consume();
/* 1651 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/* 1657 */           t.transition(BeforeAttributeName);
/*      */           break;
/*      */         case '/':
/* 1660 */           t.transition(SelfClosingStartTag);
/*      */           break;
/*      */         case '>':
/* 1663 */           t.emitTagPending();
/* 1664 */           t.transition(Data);
/*      */           break;
/*      */         default:
/* 1667 */           t.dataBuffer.append(c);
/* 1668 */           needsExitTransition = true; break;
/*      */       } 
/*      */     } else {
/* 1671 */       needsExitTransition = true;
/*      */     } 
/*      */     
/* 1674 */     if (needsExitTransition) {
/* 1675 */       t.emit("</");
/* 1676 */       t.emit(t.dataBuffer);
/* 1677 */       t.transition(elseTransition);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void readRawData(Tokeniser t, CharacterReader r, TokeniserState current, TokeniserState advance) {
/* 1682 */     switch (r.current()) {
/*      */       case '<':
/* 1684 */         t.advanceTransition(advance);
/*      */         return;
/*      */       case '\000':
/* 1687 */         t.error(current);
/* 1688 */         r.advance();
/* 1689 */         t.emit('�');
/*      */         return;
/*      */       case '￿':
/* 1692 */         t.emit(new Token.EOF());
/*      */         return;
/*      */     } 
/* 1695 */     String data = r.consumeRawData();
/* 1696 */     t.emit(data);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void readCharRef(Tokeniser t, TokeniserState advance) {
/* 1702 */     int[] c = t.consumeCharacterReference(null, false);
/* 1703 */     if (c == null) {
/* 1704 */       t.emit('&');
/*      */     } else {
/* 1706 */       t.emit(c);
/* 1707 */     }  t.transition(advance);
/*      */   }
/*      */   
/*      */   private static void readEndTag(Tokeniser t, CharacterReader r, TokeniserState a, TokeniserState b) {
/* 1711 */     if (r.matchesAsciiAlpha()) {
/* 1712 */       t.createTagPending(false);
/* 1713 */       t.transition(a);
/*      */     } else {
/* 1715 */       t.emit("</");
/* 1716 */       t.transition(b);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void handleDataDoubleEscapeTag(Tokeniser t, CharacterReader r, TokeniserState primary, TokeniserState fallback) {
/* 1721 */     if (r.matchesLetter()) {
/* 1722 */       String name = r.consumeLetterSequence();
/* 1723 */       t.dataBuffer.append(name);
/* 1724 */       t.emit(name);
/*      */       
/*      */       return;
/*      */     } 
/* 1728 */     char c = r.consume();
/* 1729 */     switch (c) {
/*      */       case '\t':
/*      */       case '\n':
/*      */       case '\f':
/*      */       case '\r':
/*      */       case ' ':
/*      */       case '/':
/*      */       case '>':
/* 1737 */         if (t.dataBuffer.toString().equals("script")) {
/* 1738 */           t.transition(primary);
/*      */         } else {
/* 1740 */           t.transition(fallback);
/* 1741 */         }  t.emit(c);
/*      */         return;
/*      */     } 
/* 1744 */     r.unconsume();
/* 1745 */     t.transition(fallback);
/*      */   }
/*      */   
/*      */   abstract void read(Tokeniser paramTokeniser, CharacterReader paramCharacterReader);
/*      */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\parser\TokeniserState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */