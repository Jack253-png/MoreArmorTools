/*     */ package org.jsoup.parser;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import javax.annotation.Nullable;
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.internal.StringUtil;
/*     */ import org.jsoup.nodes.Entities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Tokeniser
/*     */ {
/*     */   static final char replacementChar = '�';
/*  15 */   private static final char[] notCharRefCharsSorted = new char[] { '\t', '\n', '\r', '\f', ' ', '<', '&' };
/*     */ 
/*     */   
/*     */   static final int win1252ExtensionsStart = 128;
/*     */   
/*  20 */   static final int[] win1252Extensions = new int[] { 8364, 129, 8218, 402, 8222, 8230, 8224, 8225, 710, 8240, 352, 8249, 338, 141, 381, 143, 144, 8216, 8217, 8220, 8221, 8226, 8211, 8212, 732, 8482, 353, 8250, 339, 157, 382, 376 };
/*     */ 
/*     */   
/*     */   private final CharacterReader reader;
/*     */ 
/*     */   
/*     */   private final ParseErrorList errors;
/*     */ 
/*     */   
/*     */   static {
/*  30 */     Arrays.sort(notCharRefCharsSorted);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  36 */   private TokeniserState state = TokeniserState.Data;
/*     */   private Token emitPending;
/*     */   private boolean isEmitPending = false;
/*  39 */   private String charsString = null;
/*  40 */   private StringBuilder charsBuilder = new StringBuilder(1024);
/*  41 */   StringBuilder dataBuffer = new StringBuilder(1024);
/*     */   
/*     */   Token.Tag tagPending;
/*  44 */   Token.StartTag startPending = new Token.StartTag();
/*  45 */   Token.EndTag endPending = new Token.EndTag();
/*  46 */   Token.Character charPending = new Token.Character();
/*  47 */   Token.Doctype doctypePending = new Token.Doctype();
/*  48 */   Token.Comment commentPending = new Token.Comment();
/*     */   
/*     */   private String lastStartTag;
/*     */   
/*     */   @Nullable
/*     */   private String lastStartCloseSeq;
/*     */   private final int[] codepointHolder;
/*     */   private final int[] multipointHolder;
/*     */   
/*     */   Token read() {
/*  58 */     while (!this.isEmitPending) {
/*  59 */       this.state.read(this, this.reader);
/*     */     }
/*     */ 
/*     */     
/*  63 */     StringBuilder cb = this.charsBuilder;
/*  64 */     if (cb.length() != 0) {
/*  65 */       String str = cb.toString();
/*  66 */       cb.delete(0, cb.length());
/*  67 */       this.charsString = null;
/*  68 */       return this.charPending.data(str);
/*  69 */     }  if (this.charsString != null) {
/*  70 */       Token token = this.charPending.data(this.charsString);
/*  71 */       this.charsString = null;
/*  72 */       return token;
/*     */     } 
/*  74 */     this.isEmitPending = false;
/*  75 */     return this.emitPending;
/*     */   }
/*     */ 
/*     */   
/*     */   void emit(Token token) {
/*  80 */     Validate.isFalse(this.isEmitPending);
/*     */     
/*  82 */     this.emitPending = token;
/*  83 */     this.isEmitPending = true;
/*     */     
/*  85 */     if (token.type == Token.TokenType.StartTag) {
/*  86 */       Token.StartTag startTag = (Token.StartTag)token;
/*  87 */       this.lastStartTag = startTag.tagName;
/*  88 */       this.lastStartCloseSeq = null;
/*  89 */     } else if (token.type == Token.TokenType.EndTag) {
/*  90 */       Token.EndTag endTag = (Token.EndTag)token;
/*  91 */       if (endTag.hasAttributes()) {
/*  92 */         error("Attributes incorrectly present on end tag [/%s]", new Object[] { endTag.normalName() });
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void emit(String str) {
/*  99 */     if (this.charsString == null) {
/* 100 */       this.charsString = str;
/*     */     } else {
/*     */       
/* 103 */       if (this.charsBuilder.length() == 0) {
/* 104 */         this.charsBuilder.append(this.charsString);
/*     */       }
/* 106 */       this.charsBuilder.append(str);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void emit(StringBuilder str) {
/* 112 */     if (this.charsString == null) {
/* 113 */       this.charsString = str.toString();
/*     */     } else {
/*     */       
/* 116 */       if (this.charsBuilder.length() == 0) {
/* 117 */         this.charsBuilder.append(this.charsString);
/*     */       }
/* 119 */       this.charsBuilder.append(str);
/*     */     } 
/*     */   }
/*     */   
/*     */   void emit(char c) {
/* 124 */     if (this.charsString == null) {
/* 125 */       this.charsString = String.valueOf(c);
/*     */     } else {
/*     */       
/* 128 */       if (this.charsBuilder.length() == 0) {
/* 129 */         this.charsBuilder.append(this.charsString);
/*     */       }
/* 131 */       this.charsBuilder.append(c);
/*     */     } 
/*     */   }
/*     */   
/*     */   void emit(char[] chars) {
/* 136 */     emit(String.valueOf(chars));
/*     */   }
/*     */   
/*     */   void emit(int[] codepoints) {
/* 140 */     emit(new String(codepoints, 0, codepoints.length));
/*     */   }
/*     */   
/*     */   TokeniserState getState() {
/* 144 */     return this.state;
/*     */   }
/*     */   
/*     */   void transition(TokeniserState state) {
/* 148 */     this.state = state;
/*     */   }
/*     */   
/*     */   void advanceTransition(TokeniserState state) {
/* 152 */     this.reader.advance();
/* 153 */     this.state = state;
/*     */   }
/*     */   
/* 156 */   Tokeniser(CharacterReader reader, ParseErrorList errors) { this.codepointHolder = new int[1];
/* 157 */     this.multipointHolder = new int[2];
/*     */     this.reader = reader;
/* 159 */     this.errors = errors; } @Nullable int[] consumeCharacterReference(Character additionalAllowedCharacter, boolean inAttribute) { if (this.reader.isEmpty())
/* 160 */       return null; 
/* 161 */     if (additionalAllowedCharacter != null && additionalAllowedCharacter.charValue() == this.reader.current())
/* 162 */       return null; 
/* 163 */     if (this.reader.matchesAnySorted(notCharRefCharsSorted)) {
/* 164 */       return null;
/*     */     }
/* 166 */     int[] codeRef = this.codepointHolder;
/* 167 */     this.reader.mark();
/* 168 */     if (this.reader.matchConsume("#")) {
/* 169 */       boolean isHexMode = this.reader.matchConsumeIgnoreCase("X");
/* 170 */       String numRef = isHexMode ? this.reader.consumeHexSequence() : this.reader.consumeDigitSequence();
/* 171 */       if (numRef.length() == 0) {
/* 172 */         characterReferenceError("numeric reference with no numerals", new Object[0]);
/* 173 */         this.reader.rewindToMark();
/* 174 */         return null;
/*     */       } 
/*     */       
/* 177 */       this.reader.unmark();
/* 178 */       if (!this.reader.matchConsume(";"))
/* 179 */         characterReferenceError("missing semicolon on [&#%s]", new Object[] { numRef }); 
/* 180 */       int charval = -1;
/*     */       try {
/* 182 */         int base = isHexMode ? 16 : 10;
/* 183 */         charval = Integer.valueOf(numRef, base).intValue();
/* 184 */       } catch (NumberFormatException numberFormatException) {}
/*     */       
/* 186 */       if (charval == -1 || (charval >= 55296 && charval <= 57343) || charval > 1114111) {
/* 187 */         characterReferenceError("character [%s] outside of valid range", new Object[] { Integer.valueOf(charval) });
/* 188 */         codeRef[0] = 65533;
/*     */       } else {
/*     */         
/* 191 */         if (charval >= 128 && charval < 128 + win1252Extensions.length) {
/* 192 */           characterReferenceError("character [%s] is not a valid unicode code point", new Object[] { Integer.valueOf(charval) });
/* 193 */           charval = win1252Extensions[charval - 128];
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 198 */         codeRef[0] = charval;
/*     */       } 
/* 200 */       return codeRef;
/*     */     } 
/*     */     
/* 203 */     String nameRef = this.reader.consumeLetterThenDigitSequence();
/* 204 */     boolean looksLegit = this.reader.matches(';');
/*     */     
/* 206 */     boolean found = (Entities.isBaseNamedEntity(nameRef) || (Entities.isNamedEntity(nameRef) && looksLegit));
/*     */     
/* 208 */     if (!found) {
/* 209 */       this.reader.rewindToMark();
/* 210 */       if (looksLegit)
/* 211 */         characterReferenceError("invalid named reference [%s]", new Object[] { nameRef }); 
/* 212 */       return null;
/*     */     } 
/* 214 */     if (inAttribute && (this.reader.matchesLetter() || this.reader.matchesDigit() || this.reader.matchesAny(new char[] { '=', '-', '_' }))) {
/*     */       
/* 216 */       this.reader.rewindToMark();
/* 217 */       return null;
/*     */     } 
/*     */     
/* 220 */     this.reader.unmark();
/* 221 */     if (!this.reader.matchConsume(";"))
/* 222 */       characterReferenceError("missing semicolon on [&%s]", new Object[] { nameRef }); 
/* 223 */     int numChars = Entities.codepointsForName(nameRef, this.multipointHolder);
/* 224 */     if (numChars == 1) {
/* 225 */       codeRef[0] = this.multipointHolder[0];
/* 226 */       return codeRef;
/* 227 */     }  if (numChars == 2) {
/* 228 */       return this.multipointHolder;
/*     */     }
/* 230 */     Validate.fail("Unexpected characters returned for " + nameRef);
/* 231 */     return this.multipointHolder; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Token.Tag createTagPending(boolean start) {
/* 237 */     this.tagPending = start ? this.startPending.reset() : this.endPending.reset();
/* 238 */     return this.tagPending;
/*     */   }
/*     */   
/*     */   void emitTagPending() {
/* 242 */     this.tagPending.finaliseTag();
/* 243 */     emit(this.tagPending);
/*     */   }
/*     */   
/*     */   void createCommentPending() {
/* 247 */     this.commentPending.reset();
/*     */   }
/*     */   
/*     */   void emitCommentPending() {
/* 251 */     emit(this.commentPending);
/*     */   }
/*     */   
/*     */   void createBogusCommentPending() {
/* 255 */     this.commentPending.reset();
/* 256 */     this.commentPending.bogus = true;
/*     */   }
/*     */   
/*     */   void createDoctypePending() {
/* 260 */     this.doctypePending.reset();
/*     */   }
/*     */   
/*     */   void emitDoctypePending() {
/* 264 */     emit(this.doctypePending);
/*     */   }
/*     */   
/*     */   void createTempBuffer() {
/* 268 */     Token.reset(this.dataBuffer);
/*     */   }
/*     */   
/*     */   boolean isAppropriateEndTagToken() {
/* 272 */     return (this.lastStartTag != null && this.tagPending.name().equalsIgnoreCase(this.lastStartTag));
/*     */   }
/*     */   
/*     */   String appropriateEndTagName() {
/* 276 */     return this.lastStartTag;
/*     */   }
/*     */ 
/*     */   
/*     */   String appropriateEndTagSeq() {
/* 281 */     if (this.lastStartCloseSeq == null)
/* 282 */       this.lastStartCloseSeq = "</" + this.lastStartTag; 
/* 283 */     return this.lastStartCloseSeq;
/*     */   }
/*     */   
/*     */   void error(TokeniserState state) {
/* 287 */     if (this.errors.canAddError())
/* 288 */       this.errors.add(new ParseError(this.reader, "Unexpected character '%s' in input state [%s]", new Object[] { Character.valueOf(this.reader.current()), state })); 
/*     */   }
/*     */   
/*     */   void eofError(TokeniserState state) {
/* 292 */     if (this.errors.canAddError())
/* 293 */       this.errors.add(new ParseError(this.reader, "Unexpectedly reached end of file (EOF) in input state [%s]", new Object[] { state })); 
/*     */   }
/*     */   
/*     */   private void characterReferenceError(String message, Object... args) {
/* 297 */     if (this.errors.canAddError())
/* 298 */       this.errors.add(new ParseError(this.reader, String.format("Invalid character reference: " + message, args))); 
/*     */   }
/*     */   
/*     */   void error(String errorMsg) {
/* 302 */     if (this.errors.canAddError())
/* 303 */       this.errors.add(new ParseError(this.reader, errorMsg)); 
/*     */   }
/*     */   
/*     */   void error(String errorMsg, Object... args) {
/* 307 */     if (this.errors.canAddError()) {
/* 308 */       this.errors.add(new ParseError(this.reader, errorMsg, args));
/*     */     }
/*     */   }
/*     */   
/*     */   boolean currentNodeInHtmlNS() {
/* 313 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String unescapeEntities(boolean inAttribute) {
/* 324 */     StringBuilder builder = StringUtil.borrowBuilder();
/* 325 */     while (!this.reader.isEmpty()) {
/* 326 */       builder.append(this.reader.consumeTo('&'));
/* 327 */       if (this.reader.matches('&')) {
/* 328 */         this.reader.consume();
/* 329 */         int[] c = consumeCharacterReference(null, inAttribute);
/* 330 */         if (c == null || c.length == 0) {
/* 331 */           builder.append('&'); continue;
/*     */         } 
/* 333 */         builder.appendCodePoint(c[0]);
/* 334 */         if (c.length == 2) {
/* 335 */           builder.appendCodePoint(c[1]);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 340 */     return StringUtil.releaseBuilder(builder);
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\parser\Tokeniser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */