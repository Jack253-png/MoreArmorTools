/*     */ package org.jsoup.parser;
/*     */ 
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.internal.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenQueue
/*     */ {
/*     */   private String queue;
/*  13 */   private int pos = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final char ESC = '\\';
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenQueue(String data) {
/*  22 */     Validate.notNull(data);
/*  23 */     this.queue = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  31 */     return (remainingLength() == 0);
/*     */   }
/*     */   
/*     */   private int remainingLength() {
/*  35 */     return this.queue.length() - this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public char peek() {
/*  45 */     return isEmpty() ? Character.MIN_VALUE : this.queue.charAt(this.pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void addFirst(Character c) {
/*  55 */     addFirst(c.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFirst(String seq) {
/*  64 */     this.queue = seq + this.queue.substring(this.pos);
/*  65 */     this.pos = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(String seq) {
/*  74 */     return this.queue.regionMatches(true, this.pos, seq, 0, seq.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean matchesCS(String seq) {
/*  85 */     return this.queue.startsWith(seq, this.pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matchesAny(String... seq) {
/*  95 */     for (String s : seq) {
/*  96 */       if (matches(s))
/*  97 */         return true; 
/*     */     } 
/*  99 */     return false;
/*     */   }
/*     */   
/*     */   public boolean matchesAny(char... seq) {
/* 103 */     if (isEmpty()) {
/* 104 */       return false;
/*     */     }
/* 106 */     for (char c : seq) {
/* 107 */       if (this.queue.charAt(this.pos) == c)
/* 108 */         return true; 
/*     */     } 
/* 110 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean matchesStartTag() {
/* 119 */     return (remainingLength() >= 2 && this.queue.charAt(this.pos) == '<' && Character.isLetter(this.queue.charAt(this.pos + 1)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matchChomp(String seq) {
/* 129 */     if (matches(seq)) {
/* 130 */       this.pos += seq.length();
/* 131 */       return true;
/*     */     } 
/* 133 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matchesWhitespace() {
/* 142 */     return (!isEmpty() && StringUtil.isWhitespace(this.queue.charAt(this.pos)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matchesWord() {
/* 150 */     return (!isEmpty() && Character.isLetterOrDigit(this.queue.charAt(this.pos)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void advance() {
/* 157 */     if (!isEmpty()) this.pos++;
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char consume() {
/* 165 */     return this.queue.charAt(this.pos++);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void consume(String seq) {
/* 176 */     if (!matches(seq))
/* 177 */       throw new IllegalStateException("Queue did not match expected sequence"); 
/* 178 */     int len = seq.length();
/* 179 */     if (len > remainingLength()) {
/* 180 */       throw new IllegalStateException("Queue not long enough to consume sequence");
/*     */     }
/* 182 */     this.pos += len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String consumeTo(String seq) {
/* 191 */     int offset = this.queue.indexOf(seq, this.pos);
/* 192 */     if (offset != -1) {
/* 193 */       String consumed = this.queue.substring(this.pos, offset);
/* 194 */       this.pos += consumed.length();
/* 195 */       return consumed;
/*     */     } 
/* 197 */     return remainder();
/*     */   }
/*     */ 
/*     */   
/*     */   public String consumeToIgnoreCase(String seq) {
/* 202 */     int start = this.pos;
/* 203 */     String first = seq.substring(0, 1);
/* 204 */     boolean canScan = first.toLowerCase().equals(first.toUpperCase());
/* 205 */     while (!isEmpty() && 
/* 206 */       !matches(seq)) {
/*     */ 
/*     */       
/* 209 */       if (canScan) {
/* 210 */         int skip = this.queue.indexOf(first, this.pos) - this.pos;
/* 211 */         if (skip == 0) {
/* 212 */           this.pos++; continue;
/* 213 */         }  if (skip < 0) {
/* 214 */           this.pos = this.queue.length(); continue;
/*     */         } 
/* 216 */         this.pos += skip;
/*     */         continue;
/*     */       } 
/* 219 */       this.pos++;
/*     */     } 
/*     */     
/* 222 */     return this.queue.substring(start, this.pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String consumeToAny(String... seq) {
/* 233 */     int start = this.pos;
/* 234 */     while (!isEmpty() && !matchesAny(seq)) {
/* 235 */       this.pos++;
/*     */     }
/*     */     
/* 238 */     return this.queue.substring(start, this.pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String chompTo(String seq) {
/* 250 */     String data = consumeTo(seq);
/* 251 */     matchChomp(seq);
/* 252 */     return data;
/*     */   }
/*     */   
/*     */   public String chompToIgnoreCase(String seq) {
/* 256 */     String data = consumeToIgnoreCase(seq);
/* 257 */     matchChomp(seq);
/* 258 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String chompBalanced(char open, char close) {
/*     */     // Byte code:
/*     */     //   0: iconst_m1
/*     */     //   1: istore_3
/*     */     //   2: iconst_m1
/*     */     //   3: istore #4
/*     */     //   5: iconst_0
/*     */     //   6: istore #5
/*     */     //   8: iconst_0
/*     */     //   9: istore #6
/*     */     //   11: iconst_0
/*     */     //   12: istore #7
/*     */     //   14: iconst_0
/*     */     //   15: istore #8
/*     */     //   17: iconst_0
/*     */     //   18: istore #9
/*     */     //   20: aload_0
/*     */     //   21: invokevirtual isEmpty : ()Z
/*     */     //   24: ifeq -> 30
/*     */     //   27: goto -> 210
/*     */     //   30: aload_0
/*     */     //   31: invokevirtual consume : ()C
/*     */     //   34: istore #10
/*     */     //   36: iload #6
/*     */     //   38: bipush #92
/*     */     //   40: if_icmpeq -> 162
/*     */     //   43: iload #10
/*     */     //   45: bipush #39
/*     */     //   47: if_icmpne -> 76
/*     */     //   50: iload #10
/*     */     //   52: iload_1
/*     */     //   53: if_icmpeq -> 76
/*     */     //   56: iload #8
/*     */     //   58: ifne -> 76
/*     */     //   61: iload #7
/*     */     //   63: ifne -> 70
/*     */     //   66: iconst_1
/*     */     //   67: goto -> 71
/*     */     //   70: iconst_0
/*     */     //   71: istore #7
/*     */     //   73: goto -> 106
/*     */     //   76: iload #10
/*     */     //   78: bipush #34
/*     */     //   80: if_icmpne -> 106
/*     */     //   83: iload #10
/*     */     //   85: iload_1
/*     */     //   86: if_icmpeq -> 106
/*     */     //   89: iload #7
/*     */     //   91: ifne -> 106
/*     */     //   94: iload #8
/*     */     //   96: ifne -> 103
/*     */     //   99: iconst_1
/*     */     //   100: goto -> 104
/*     */     //   103: iconst_0
/*     */     //   104: istore #8
/*     */     //   106: iload #7
/*     */     //   108: ifne -> 121
/*     */     //   111: iload #8
/*     */     //   113: ifne -> 121
/*     */     //   116: iload #9
/*     */     //   118: ifeq -> 128
/*     */     //   121: iload #10
/*     */     //   123: istore #6
/*     */     //   125: goto -> 205
/*     */     //   128: iload #10
/*     */     //   130: iload_1
/*     */     //   131: if_icmpne -> 150
/*     */     //   134: iinc #5, 1
/*     */     //   137: iload_3
/*     */     //   138: iconst_m1
/*     */     //   139: if_icmpne -> 185
/*     */     //   142: aload_0
/*     */     //   143: getfield pos : I
/*     */     //   146: istore_3
/*     */     //   147: goto -> 185
/*     */     //   150: iload #10
/*     */     //   152: iload_2
/*     */     //   153: if_icmpne -> 185
/*     */     //   156: iinc #5, -1
/*     */     //   159: goto -> 185
/*     */     //   162: iload #10
/*     */     //   164: bipush #81
/*     */     //   166: if_icmpne -> 175
/*     */     //   169: iconst_1
/*     */     //   170: istore #9
/*     */     //   172: goto -> 185
/*     */     //   175: iload #10
/*     */     //   177: bipush #69
/*     */     //   179: if_icmpne -> 185
/*     */     //   182: iconst_0
/*     */     //   183: istore #9
/*     */     //   185: iload #5
/*     */     //   187: ifle -> 201
/*     */     //   190: iload #6
/*     */     //   192: ifeq -> 201
/*     */     //   195: aload_0
/*     */     //   196: getfield pos : I
/*     */     //   199: istore #4
/*     */     //   201: iload #10
/*     */     //   203: istore #6
/*     */     //   205: iload #5
/*     */     //   207: ifgt -> 20
/*     */     //   210: iload #4
/*     */     //   212: iflt -> 228
/*     */     //   215: aload_0
/*     */     //   216: getfield queue : Ljava/lang/String;
/*     */     //   219: iload_3
/*     */     //   220: iload #4
/*     */     //   222: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   225: goto -> 230
/*     */     //   228: ldc ''
/*     */     //   230: astore #10
/*     */     //   232: iload #5
/*     */     //   234: ifle -> 265
/*     */     //   237: new java/lang/StringBuilder
/*     */     //   240: dup
/*     */     //   241: invokespecial <init> : ()V
/*     */     //   244: ldc 'Did not find balanced marker at ''
/*     */     //   246: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   249: aload #10
/*     */     //   251: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   254: ldc '''
/*     */     //   256: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   259: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   262: invokestatic fail : (Ljava/lang/String;)V
/*     */     //   265: aload #10
/*     */     //   267: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #271	-> 0
/*     */     //   #272	-> 2
/*     */     //   #273	-> 5
/*     */     //   #274	-> 8
/*     */     //   #275	-> 11
/*     */     //   #276	-> 14
/*     */     //   #277	-> 17
/*     */     //   #280	-> 20
/*     */     //   #281	-> 30
/*     */     //   #282	-> 36
/*     */     //   #283	-> 43
/*     */     //   #284	-> 61
/*     */     //   #285	-> 76
/*     */     //   #286	-> 94
/*     */     //   #287	-> 106
/*     */     //   #288	-> 121
/*     */     //   #289	-> 125
/*     */     //   #292	-> 128
/*     */     //   #293	-> 134
/*     */     //   #294	-> 137
/*     */     //   #295	-> 142
/*     */     //   #297	-> 150
/*     */     //   #298	-> 156
/*     */     //   #299	-> 162
/*     */     //   #300	-> 169
/*     */     //   #301	-> 175
/*     */     //   #302	-> 182
/*     */     //   #305	-> 185
/*     */     //   #306	-> 195
/*     */     //   #307	-> 201
/*     */     //   #308	-> 205
/*     */     //   #309	-> 210
/*     */     //   #310	-> 232
/*     */     //   #311	-> 237
/*     */     //   #313	-> 265
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   36	169	10	c	C
/*     */     //   0	268	0	this	Lorg/jsoup/parser/TokenQueue;
/*     */     //   0	268	1	open	C
/*     */     //   0	268	2	close	C
/*     */     //   2	266	3	start	I
/*     */     //   5	263	4	end	I
/*     */     //   8	260	5	depth	I
/*     */     //   11	257	6	last	C
/*     */     //   14	254	7	inSingleQuote	Z
/*     */     //   17	251	8	inDoubleQuote	Z
/*     */     //   20	248	9	inRegexQE	Z
/*     */     //   232	36	10	out	Ljava/lang/String;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String unescape(String in) {
/* 322 */     StringBuilder out = StringUtil.borrowBuilder();
/* 323 */     char last = Character.MIN_VALUE;
/* 324 */     for (char c : in.toCharArray()) {
/* 325 */       if (c == '\\') {
/* 326 */         if (last == '\\') {
/* 327 */           out.append(c);
/*     */         }
/*     */       } else {
/* 330 */         out.append(c);
/* 331 */       }  last = c;
/*     */     } 
/* 333 */     return StringUtil.releaseBuilder(out);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean consumeWhitespace() {
/* 341 */     boolean seen = false;
/* 342 */     while (matchesWhitespace()) {
/* 343 */       this.pos++;
/* 344 */       seen = true;
/*     */     } 
/* 346 */     return seen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String consumeWord() {
/* 354 */     int start = this.pos;
/* 355 */     while (matchesWord())
/* 356 */       this.pos++; 
/* 357 */     return this.queue.substring(start, this.pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String consumeTagName() {
/* 368 */     int start = this.pos;
/* 369 */     while (!isEmpty() && (matchesWord() || matchesAny(new char[] { ':', '_', '-' }))) {
/* 370 */       this.pos++;
/*     */     }
/* 372 */     return this.queue.substring(start, this.pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String consumeElementSelector() {
/* 381 */     int start = this.pos;
/* 382 */     while (!isEmpty() && (matchesWord() || matchesAny(new String[] { "*|", "|", "_", "-" }))) {
/* 383 */       this.pos++;
/*     */     }
/* 385 */     return this.queue.substring(start, this.pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String consumeCssIdentifier() {
/* 394 */     int start = this.pos;
/* 395 */     while (!isEmpty() && (matchesWord() || matchesAny(new char[] { '-', '_' }))) {
/* 396 */       this.pos++;
/*     */     }
/* 398 */     return this.queue.substring(start, this.pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String consumeAttributeKey() {
/* 408 */     int start = this.pos;
/* 409 */     while (!isEmpty() && (matchesWord() || matchesAny(new char[] { '-', '_', ':' }))) {
/* 410 */       this.pos++;
/*     */     }
/* 412 */     return this.queue.substring(start, this.pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String remainder() {
/* 420 */     String remainder = this.queue.substring(this.pos);
/* 421 */     this.pos = this.queue.length();
/* 422 */     return remainder;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 427 */     return this.queue.substring(this.pos);
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\parser\TokenQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */