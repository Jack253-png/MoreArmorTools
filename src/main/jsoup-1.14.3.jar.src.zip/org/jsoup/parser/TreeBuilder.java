/*     */ package org.jsoup.parser;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.annotation.ParametersAreNonnullByDefault;
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.nodes.Attributes;
/*     */ import org.jsoup.nodes.Document;
/*     */ import org.jsoup.nodes.Element;
/*     */ import org.jsoup.nodes.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class TreeBuilder
/*     */ {
/*     */   protected Parser parser;
/*     */   CharacterReader reader;
/*     */   Tokeniser tokeniser;
/*     */   protected Document doc;
/*     */   protected ArrayList<Element> stack;
/*     */   protected String baseUri;
/*     */   protected Token currentToken;
/*     */   protected ParseSettings settings;
/*     */   protected Map<String, Tag> seenTags;
/*  31 */   private Token.StartTag start = new Token.StartTag();
/*  32 */   private Token.EndTag end = new Token.EndTag();
/*     */ 
/*     */   
/*     */   @ParametersAreNonnullByDefault
/*     */   protected void initialiseParse(Reader input, String baseUri, Parser parser) {
/*  37 */     Validate.notNull(input, "String input must not be null");
/*  38 */     Validate.notNull(baseUri, "BaseURI must not be null");
/*  39 */     Validate.notNull(parser);
/*     */     
/*  41 */     this.doc = new Document(baseUri);
/*  42 */     this.doc.parser(parser);
/*  43 */     this.parser = parser;
/*  44 */     this.settings = parser.settings();
/*  45 */     this.reader = new CharacterReader(input);
/*  46 */     this.reader.trackNewlines(parser.isTrackErrors());
/*  47 */     this.currentToken = null;
/*  48 */     this.tokeniser = new Tokeniser(this.reader, parser.getErrors());
/*  49 */     this.stack = new ArrayList<>(32);
/*  50 */     this.seenTags = new HashMap<>();
/*  51 */     this.baseUri = baseUri;
/*     */   }
/*     */   abstract ParseSettings defaultSettings();
/*     */   @ParametersAreNonnullByDefault
/*     */   Document parse(Reader input, String baseUri, Parser parser) {
/*  56 */     initialiseParse(input, baseUri, parser);
/*  57 */     runParser();
/*     */ 
/*     */     
/*  60 */     this.reader.close();
/*  61 */     this.reader = null;
/*  62 */     this.tokeniser = null;
/*  63 */     this.stack = null;
/*  64 */     this.seenTags = null;
/*     */     
/*  66 */     return this.doc;
/*     */   }
/*     */ 
/*     */   
/*     */   abstract TreeBuilder newInstance();
/*     */ 
/*     */   
/*     */   abstract List<Node> parseFragment(String paramString1, Element paramElement, String paramString2, Parser paramParser);
/*     */ 
/*     */   
/*     */   protected void runParser() {
/*     */     Token token;
/*  78 */     Tokeniser tokeniser = this.tokeniser;
/*  79 */     Token.TokenType eof = Token.TokenType.EOF;
/*     */     
/*     */     do {
/*  82 */       token = tokeniser.read();
/*  83 */       process(token);
/*  84 */       token.reset();
/*     */     }
/*  86 */     while (token.type != eof);
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract boolean process(Token paramToken);
/*     */ 
/*     */   
/*     */   protected boolean processStartTag(String name) {
/*  94 */     Token.StartTag start = this.start;
/*  95 */     if (this.currentToken == start) {
/*  96 */       return process((new Token.StartTag()).name(name));
/*     */     }
/*  98 */     return process(start.reset().name(name));
/*     */   }
/*     */   
/*     */   public boolean processStartTag(String name, Attributes attrs) {
/* 102 */     Token.StartTag start = this.start;
/* 103 */     if (this.currentToken == start) {
/* 104 */       return process((new Token.StartTag()).nameAttr(name, attrs));
/*     */     }
/* 106 */     start.reset();
/* 107 */     start.nameAttr(name, attrs);
/* 108 */     return process(start);
/*     */   }
/*     */   
/*     */   protected boolean processEndTag(String name) {
/* 112 */     if (this.currentToken == this.end) {
/* 113 */       return process((new Token.EndTag()).name(name));
/*     */     }
/* 115 */     return process(this.end.reset().name(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Element currentElement() {
/* 125 */     int size = this.stack.size();
/* 126 */     return (size > 0) ? this.stack.get(size - 1) : (Element)this.doc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean currentElementIs(String normalName) {
/* 135 */     if (this.stack.size() == 0)
/* 136 */       return false; 
/* 137 */     Element current = currentElement();
/* 138 */     return (current != null && current.normalName().equals(normalName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void error(String msg) {
/* 146 */     error(msg, (Object[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void error(String msg, Object... args) {
/* 155 */     ParseErrorList errors = this.parser.getErrors();
/* 156 */     if (errors.canAddError()) {
/* 157 */       errors.add(new ParseError(this.reader, msg, args));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isContentForTagData(String normalName) {
/* 165 */     return false;
/*     */   }
/*     */   
/*     */   protected Tag tagFor(String tagName, ParseSettings settings) {
/* 169 */     Tag tag = this.seenTags.get(tagName);
/* 170 */     if (tag == null) {
/* 171 */       tag = Tag.valueOf(tagName, settings);
/* 172 */       this.seenTags.put(tagName, tag);
/*     */     } 
/* 174 */     return tag;
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\parser\TreeBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */