/*     */ package org.jsoup.parser;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.List;
/*     */ import javax.annotation.ParametersAreNonnullByDefault;
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.nodes.Attributes;
/*     */ import org.jsoup.nodes.CDataNode;
/*     */ import org.jsoup.nodes.Comment;
/*     */ import org.jsoup.nodes.Document;
/*     */ import org.jsoup.nodes.DocumentType;
/*     */ import org.jsoup.nodes.Element;
/*     */ import org.jsoup.nodes.Entities;
/*     */ import org.jsoup.nodes.Node;
/*     */ import org.jsoup.nodes.TextNode;
/*     */ import org.jsoup.nodes.XmlDeclaration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlTreeBuilder
/*     */   extends TreeBuilder
/*     */ {
/*     */   private static final int maxQueueDepth = 256;
/*     */   
/*     */   ParseSettings defaultSettings() {
/*  28 */     return ParseSettings.preserveCase;
/*     */   }
/*     */   
/*     */   @ParametersAreNonnullByDefault
/*     */   protected void initialiseParse(Reader input, String baseUri, Parser parser) {
/*  33 */     super.initialiseParse(input, baseUri, parser);
/*  34 */     this.stack.add(this.doc);
/*  35 */     this.doc.outputSettings()
/*  36 */       .syntax(Document.OutputSettings.Syntax.xml)
/*  37 */       .escapeMode(Entities.EscapeMode.xhtml)
/*  38 */       .prettyPrint(false);
/*     */   }
/*     */   
/*     */   Document parse(Reader input, String baseUri) {
/*  42 */     return parse(input, baseUri, new Parser(this));
/*     */   }
/*     */   
/*     */   Document parse(String input, String baseUri) {
/*  46 */     return parse(new StringReader(input), baseUri, new Parser(this));
/*     */   }
/*     */ 
/*     */   
/*     */   XmlTreeBuilder newInstance() {
/*  51 */     return new XmlTreeBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean process(Token token) {
/*  57 */     switch (token.type) {
/*     */       case StartTag:
/*  59 */         insert(token.asStartTag());
/*     */       
/*     */       case EndTag:
/*  62 */         popStackToClose(token.asEndTag());
/*     */       
/*     */       case Comment:
/*  65 */         insert(token.asComment());
/*     */       
/*     */       case Character:
/*  68 */         insert(token.asCharacter());
/*     */       
/*     */       case Doctype:
/*  71 */         insert(token.asDoctype());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case EOF:
/*  78 */         return true;
/*     */     } 
/*     */     Validate.fail("Unexpected token type: " + token.type);
/*     */   } private void insertNode(Node node) {
/*  82 */     currentElement().appendChild(node);
/*     */   }
/*     */   
/*     */   Element insert(Token.StartTag startTag) {
/*  86 */     Tag tag = tagFor(startTag.name(), this.settings);
/*     */     
/*  88 */     if (startTag.hasAttributes()) {
/*  89 */       startTag.attributes.deduplicate(this.settings);
/*     */     }
/*  91 */     Element el = new Element(tag, null, this.settings.normalizeAttributes(startTag.attributes));
/*  92 */     insertNode((Node)el);
/*  93 */     if (startTag.isSelfClosing()) {
/*  94 */       if (!tag.isKnownTag())
/*  95 */         tag.setSelfClosing(); 
/*     */     } else {
/*  97 */       this.stack.add(el);
/*     */     } 
/*  99 */     return el;
/*     */   }
/*     */   void insert(Token.Comment commentToken) {
/*     */     XmlDeclaration xmlDeclaration;
/* 103 */     Comment comment = new Comment(commentToken.getData());
/* 104 */     Comment comment1 = comment;
/* 105 */     if (commentToken.bogus && comment.isXmlDeclaration()) {
/*     */ 
/*     */       
/* 108 */       XmlDeclaration decl = comment.asXmlDeclaration();
/* 109 */       if (decl != null)
/* 110 */         xmlDeclaration = decl; 
/*     */     } 
/* 112 */     insertNode((Node)xmlDeclaration);
/*     */   }
/*     */   
/*     */   void insert(Token.Character token) {
/* 116 */     String data = token.getData();
/* 117 */     insertNode(token.isCData() ? (Node)new CDataNode(data) : (Node)new TextNode(data));
/*     */   }
/*     */   
/*     */   void insert(Token.Doctype d) {
/* 121 */     DocumentType doctypeNode = new DocumentType(this.settings.normalizeTag(d.getName()), d.getPublicIdentifier(), d.getSystemIdentifier());
/* 122 */     doctypeNode.setPubSysKey(d.getPubSysKey());
/* 123 */     insertNode((Node)doctypeNode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void popStackToClose(Token.EndTag endTag) {
/* 134 */     String elName = this.settings.normalizeTag(endTag.tagName);
/* 135 */     Element firstFound = null;
/*     */     
/* 137 */     int bottom = this.stack.size() - 1;
/* 138 */     int upper = (bottom >= 256) ? (bottom - 256) : 0;
/*     */     int pos;
/* 140 */     for (pos = this.stack.size() - 1; pos >= upper; pos--) {
/* 141 */       Element next = this.stack.get(pos);
/* 142 */       if (next.nodeName().equals(elName)) {
/* 143 */         firstFound = next;
/*     */         break;
/*     */       } 
/*     */     } 
/* 147 */     if (firstFound == null) {
/*     */       return;
/*     */     }
/* 150 */     for (pos = this.stack.size() - 1; pos >= 0; pos--) {
/* 151 */       Element next = this.stack.get(pos);
/* 152 */       this.stack.remove(pos);
/* 153 */       if (next == firstFound) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   List<Node> parseFragment(String inputFragment, String baseUri, Parser parser) {
/* 162 */     initialiseParse(new StringReader(inputFragment), baseUri, parser);
/* 163 */     runParser();
/* 164 */     return this.doc.childNodes();
/*     */   }
/*     */   
/*     */   List<Node> parseFragment(String inputFragment, Element context, String baseUri, Parser parser) {
/* 168 */     return parseFragment(inputFragment, baseUri, parser);
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\parser\XmlTreeBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */