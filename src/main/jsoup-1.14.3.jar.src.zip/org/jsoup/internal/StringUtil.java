/*     */ package org.jsoup.internal;
/*     */ 
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Stack;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.annotation.Nullable;
/*     */ import org.jsoup.helper.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StringUtil
/*     */ {
/*  20 */   static final String[] padding = new String[] { "", " ", "  ", "   ", "    ", "     ", "      ", "       ", "        ", "         ", "          ", "           ", "            ", "             ", "              ", "               ", "                ", "                 ", "                  ", "                   ", "                    " };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int maxPaddingWidth = 30;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String join(Collection<?> strings, String sep) {
/*  32 */     return join(strings.iterator(), sep);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String join(Iterator<?> strings, String sep) {
/*  42 */     if (!strings.hasNext()) {
/*  43 */       return "";
/*     */     }
/*  45 */     String start = strings.next().toString();
/*  46 */     if (!strings.hasNext()) {
/*  47 */       return start;
/*     */     }
/*  49 */     StringJoiner j = new StringJoiner(sep);
/*  50 */     j.add(start);
/*  51 */     while (strings.hasNext()) {
/*  52 */       j.add(strings.next());
/*     */     }
/*  54 */     return j.complete();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String join(String[] strings, String sep) {
/*  64 */     return join(Arrays.asList((Object[])strings), sep);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class StringJoiner
/*     */   {
/*     */     @Nullable
/*  72 */     StringBuilder sb = StringUtil.borrowBuilder();
/*     */ 
/*     */     
/*     */     final String separator;
/*     */ 
/*     */     
/*     */     boolean first = true;
/*     */ 
/*     */ 
/*     */     
/*     */     public StringJoiner(String separator) {
/*  83 */       this.separator = separator;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public StringJoiner add(Object stringy) {
/*  90 */       Validate.notNull(this.sb);
/*  91 */       if (!this.first)
/*  92 */         this.sb.append(this.separator); 
/*  93 */       this.sb.append(stringy);
/*  94 */       this.first = false;
/*  95 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public StringJoiner append(Object stringy) {
/* 102 */       Validate.notNull(this.sb);
/* 103 */       this.sb.append(stringy);
/* 104 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String complete() {
/* 111 */       String string = StringUtil.releaseBuilder(this.sb);
/* 112 */       this.sb = null;
/* 113 */       return string;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String padding(int width) {
/* 123 */     if (width < 0) {
/* 124 */       throw new IllegalArgumentException("width must be > 0");
/*     */     }
/* 126 */     if (width < padding.length)
/* 127 */       return padding[width]; 
/* 128 */     width = Math.min(width, 30);
/* 129 */     char[] out = new char[width];
/* 130 */     for (int i = 0; i < width; i++)
/* 131 */       out[i] = ' '; 
/* 132 */     return String.valueOf(out);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBlank(String string) {
/* 141 */     if (string == null || string.length() == 0) {
/* 142 */       return true;
/*     */     }
/* 144 */     int l = string.length();
/* 145 */     for (int i = 0; i < l; i++) {
/* 146 */       if (!isWhitespace(string.codePointAt(i)))
/* 147 */         return false; 
/*     */     } 
/* 149 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNumeric(String string) {
/* 158 */     if (string == null || string.length() == 0) {
/* 159 */       return false;
/*     */     }
/* 161 */     int l = string.length();
/* 162 */     for (int i = 0; i < l; i++) {
/* 163 */       if (!Character.isDigit(string.codePointAt(i)))
/* 164 */         return false; 
/*     */     } 
/* 166 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWhitespace(int c) {
/* 176 */     return (c == 32 || c == 9 || c == 10 || c == 12 || c == 13);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isActuallyWhitespace(int c) {
/* 185 */     return (c == 32 || c == 9 || c == 10 || c == 12 || c == 13 || c == 160);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isInvisibleChar(int c) {
/* 190 */     return (c == 8203 || c == 173);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String normaliseWhitespace(String string) {
/* 201 */     StringBuilder sb = borrowBuilder();
/* 202 */     appendNormalisedWhitespace(sb, string, false);
/* 203 */     return releaseBuilder(sb);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void appendNormalisedWhitespace(StringBuilder accum, String string, boolean stripLeading) {
/* 213 */     boolean lastWasWhite = false;
/* 214 */     boolean reachedNonWhite = false;
/*     */     
/* 216 */     int len = string.length();
/*     */     int i;
/* 218 */     for (i = 0; i < len; i += Character.charCount(c)) {
/* 219 */       int c = string.codePointAt(i);
/* 220 */       if (isActuallyWhitespace(c)) {
/* 221 */         if ((!stripLeading || reachedNonWhite) && !lastWasWhite) {
/*     */           
/* 223 */           accum.append(' ');
/* 224 */           lastWasWhite = true;
/*     */         } 
/* 226 */       } else if (!isInvisibleChar(c)) {
/* 227 */         accum.appendCodePoint(c);
/* 228 */         lastWasWhite = false;
/* 229 */         reachedNonWhite = true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean in(String needle, String... haystack) {
/* 235 */     int len = haystack.length;
/* 236 */     for (int i = 0; i < len; i++) {
/* 237 */       if (haystack[i].equals(needle))
/* 238 */         return true; 
/*     */     } 
/* 240 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean inSorted(String needle, String[] haystack) {
/* 244 */     return (Arrays.binarySearch((Object[])haystack, needle) >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAscii(String string) {
/* 253 */     Validate.notNull(string);
/* 254 */     for (int i = 0; i < string.length(); i++) {
/* 255 */       int c = string.charAt(i);
/* 256 */       if (c > 127) {
/* 257 */         return false;
/*     */       }
/*     */     } 
/* 260 */     return true;
/*     */   }
/*     */   
/* 263 */   private static final Pattern extraDotSegmentsPattern = Pattern.compile("^/((\\.{1,2}/)+)");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL resolve(URL base, String relUrl) throws MalformedURLException {
/* 273 */     if (relUrl.startsWith("?")) {
/* 274 */       relUrl = base.getPath() + relUrl;
/*     */     }
/* 276 */     URL url = new URL(base, relUrl);
/* 277 */     String fixedFile = extraDotSegmentsPattern.matcher(url.getFile()).replaceFirst("/");
/* 278 */     if (url.getRef() != null) {
/* 279 */       fixedFile = fixedFile + "#" + url.getRef();
/*     */     }
/* 281 */     return new URL(url.getProtocol(), url.getHost(), url.getPort(), fixedFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String resolve(String baseUrl, String relUrl) {
/*     */     try {
/*     */       URL base;
/*     */       try {
/* 294 */         base = new URL(baseUrl);
/* 295 */       } catch (MalformedURLException e) {
/*     */         
/* 297 */         URL abs = new URL(relUrl);
/* 298 */         return abs.toExternalForm();
/*     */       } 
/* 300 */       return resolve(base, relUrl).toExternalForm();
/* 301 */     } catch (MalformedURLException e) {
/*     */       URL base;
/*     */       
/* 304 */       return validUriScheme.matcher(relUrl).find() ? relUrl : "";
/*     */     } 
/*     */   }
/* 307 */   private static final Pattern validUriScheme = Pattern.compile("^[a-zA-Z][a-zA-Z0-9+-.]*:");
/*     */   
/* 309 */   private static final ThreadLocal<Stack<StringBuilder>> threadLocalBuilders = new ThreadLocal<Stack<StringBuilder>>()
/*     */     {
/*     */       protected Stack<StringBuilder> initialValue() {
/* 312 */         return new Stack<>();
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int MaxCachedBuilderSize = 8192;
/*     */   
/*     */   private static final int MaxIdleBuilders = 8;
/*     */ 
/*     */   
/*     */   public static StringBuilder borrowBuilder() {
/* 324 */     Stack<StringBuilder> builders = threadLocalBuilders.get();
/* 325 */     return builders.empty() ? 
/* 326 */       new StringBuilder(8192) : 
/* 327 */       builders.pop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String releaseBuilder(StringBuilder sb) {
/* 337 */     Validate.notNull(sb);
/* 338 */     String string = sb.toString();
/*     */     
/* 340 */     if (sb.length() > 8192) {
/* 341 */       sb = new StringBuilder(8192);
/*     */     } else {
/* 343 */       sb.delete(0, sb.length());
/*     */     } 
/* 345 */     Stack<StringBuilder> builders = threadLocalBuilders.get();
/* 346 */     builders.push(sb);
/*     */     
/* 348 */     while (builders.size() > 8) {
/* 349 */       builders.pop();
/*     */     }
/* 351 */     return string;
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\internal\StringUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */