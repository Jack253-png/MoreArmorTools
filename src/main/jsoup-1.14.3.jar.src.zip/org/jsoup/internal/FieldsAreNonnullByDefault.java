package org.jsoup.internal;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import javax.annotation.Nonnull;
import javax.annotation.meta.TypeQualifierDefault;

@Documented
@Nonnull
@TypeQualifierDefault({ElementType.FIELD})
@Retention(RetentionPolicy.CLASS)
public @interface FieldsAreNonnullByDefault {}


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\internal\FieldsAreNonnullByDefault.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */