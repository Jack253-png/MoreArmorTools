/*     */ package org.jsoup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import javax.annotation.Nullable;
/*     */ import org.jsoup.helper.DataUtil;
/*     */ import org.jsoup.helper.HttpConnection;
/*     */ import org.jsoup.nodes.Document;
/*     */ import org.jsoup.parser.Parser;
/*     */ import org.jsoup.safety.Cleaner;
/*     */ import org.jsoup.safety.Safelist;
/*     */ import org.jsoup.safety.Whitelist;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jsoup
/*     */ {
/*     */   public static Document parse(String html, String baseUri) {
/*  34 */     return Parser.parse(html, baseUri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parse(String html, String baseUri, Parser parser) {
/*  48 */     return parser.parseInput(html, baseUri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parse(String html, Parser parser) {
/*  62 */     return parser.parseInput(html, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parse(String html) {
/*  75 */     return Parser.parse(html, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Connection connect(String url) {
/*  92 */     return HttpConnection.connect(url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Connection newSession() {
/* 119 */     return (Connection)new HttpConnection();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parse(File file, @Nullable String charsetName, String baseUri) throws IOException {
/* 134 */     return DataUtil.load(file, charsetName, baseUri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parse(File file, @Nullable String charsetName) throws IOException {
/* 149 */     return DataUtil.load(file, charsetName, file.getAbsolutePath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parse(File file, @Nullable String charsetName, String baseUri, Parser parser) throws IOException {
/* 166 */     return DataUtil.load(file, charsetName, baseUri, parser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parse(InputStream in, @Nullable String charsetName, String baseUri) throws IOException {
/* 181 */     return DataUtil.load(in, charsetName, baseUri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parse(InputStream in, @Nullable String charsetName, String baseUri, Parser parser) throws IOException {
/* 198 */     return DataUtil.load(in, charsetName, baseUri, parser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parseBodyFragment(String bodyHtml, String baseUri) {
/* 211 */     return Parser.parseBodyFragment(bodyHtml, baseUri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parseBodyFragment(String bodyHtml) {
/* 223 */     return Parser.parseBodyFragment(bodyHtml, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parse(URL url, int timeoutMillis) throws IOException {
/* 244 */     Connection con = HttpConnection.connect(url);
/* 245 */     con.timeout(timeoutMillis);
/* 246 */     return con.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String clean(String bodyHtml, String baseUri, Safelist safelist) {
/* 261 */     Document dirty = parseBodyFragment(bodyHtml, baseUri);
/* 262 */     Cleaner cleaner = new Cleaner(safelist);
/* 263 */     Document clean = cleaner.clean(dirty);
/* 264 */     return clean.body().html();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static String clean(String bodyHtml, String baseUri, Whitelist safelist) {
/* 273 */     return clean(bodyHtml, baseUri, (Safelist)safelist);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String clean(String bodyHtml, Safelist safelist) {
/* 291 */     return clean(bodyHtml, "", safelist);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static String clean(String bodyHtml, Whitelist safelist) {
/* 300 */     return clean(bodyHtml, (Safelist)safelist);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String clean(String bodyHtml, String baseUri, Safelist safelist, Document.OutputSettings outputSettings) {
/* 318 */     Document dirty = parseBodyFragment(bodyHtml, baseUri);
/* 319 */     Cleaner cleaner = new Cleaner(safelist);
/* 320 */     Document clean = cleaner.clean(dirty);
/* 321 */     clean.outputSettings(outputSettings);
/* 322 */     return clean.body().html();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static String clean(String bodyHtml, String baseUri, Whitelist safelist, Document.OutputSettings outputSettings) {
/* 331 */     return clean(bodyHtml, baseUri, (Safelist)safelist, outputSettings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValid(String bodyHtml, Safelist safelist) {
/* 344 */     return (new Cleaner(safelist)).isValidBodyHtml(bodyHtml);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static boolean isValid(String bodyHtml, Whitelist safelist) {
/* 353 */     return isValid(bodyHtml, (Safelist)safelist);
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\Jsoup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */