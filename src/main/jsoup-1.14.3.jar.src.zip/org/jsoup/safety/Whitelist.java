/*     */ package org.jsoup.safety;
/*     */ 
/*     */ import org.jsoup.nodes.Attribute;
/*     */ import org.jsoup.nodes.Attributes;
/*     */ import org.jsoup.nodes.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class Whitelist
/*     */   extends Safelist
/*     */ {
/*     */   public Whitelist() {}
/*     */   
/*     */   public Whitelist(Safelist copy) {
/*  24 */     super(copy);
/*     */   }
/*     */   
/*     */   public static Whitelist basic() {
/*  28 */     return new Whitelist(Safelist.basic());
/*     */   }
/*     */   
/*     */   public static Whitelist basicWithImages() {
/*  32 */     return new Whitelist(Safelist.basicWithImages());
/*     */   }
/*     */   
/*     */   public static Whitelist none() {
/*  36 */     return new Whitelist(Safelist.none());
/*     */   }
/*     */   
/*     */   public static Whitelist relaxed() {
/*  40 */     return new Whitelist(Safelist.relaxed());
/*     */   }
/*     */   
/*     */   public static Whitelist simpleText() {
/*  44 */     return new Whitelist(Safelist.simpleText());
/*     */   }
/*     */ 
/*     */   
/*     */   public Whitelist addTags(String... tags) {
/*  49 */     super.addTags(tags);
/*  50 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Whitelist removeTags(String... tags) {
/*  55 */     super.removeTags(tags);
/*  56 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Whitelist addAttributes(String tag, String... attributes) {
/*  61 */     super.addAttributes(tag, attributes);
/*  62 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Whitelist removeAttributes(String tag, String... attributes) {
/*  67 */     super.removeAttributes(tag, attributes);
/*  68 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Whitelist addEnforcedAttribute(String tag, String attribute, String value) {
/*  73 */     super.addEnforcedAttribute(tag, attribute, value);
/*  74 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Whitelist removeEnforcedAttribute(String tag, String attribute) {
/*  79 */     super.removeEnforcedAttribute(tag, attribute);
/*  80 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Whitelist preserveRelativeLinks(boolean preserve) {
/*  85 */     super.preserveRelativeLinks(preserve);
/*  86 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Whitelist addProtocols(String tag, String attribute, String... protocols) {
/*  91 */     super.addProtocols(tag, attribute, protocols);
/*  92 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Whitelist removeProtocols(String tag, String attribute, String... removeProtocols) {
/*  97 */     super.removeProtocols(tag, attribute, removeProtocols);
/*  98 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isSafeTag(String tag) {
/* 103 */     return super.isSafeTag(tag);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isSafeAttribute(String tagName, Element el, Attribute attr) {
/* 108 */     return super.isSafeAttribute(tagName, el, attr);
/*     */   }
/*     */ 
/*     */   
/*     */   Attributes getEnforcedAttributes(String tagName) {
/* 113 */     return super.getEnforcedAttributes(tagName);
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\safety\Whitelist.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */