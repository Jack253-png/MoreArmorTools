/*     */ package org.jsoup.safety;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.nodes.Attribute;
/*     */ import org.jsoup.nodes.Attributes;
/*     */ import org.jsoup.nodes.DataNode;
/*     */ import org.jsoup.nodes.Document;
/*     */ import org.jsoup.nodes.Element;
/*     */ import org.jsoup.nodes.Node;
/*     */ import org.jsoup.nodes.TextNode;
/*     */ import org.jsoup.parser.ParseErrorList;
/*     */ import org.jsoup.parser.Parser;
/*     */ import org.jsoup.parser.Tag;
/*     */ import org.jsoup.select.NodeTraversor;
/*     */ import org.jsoup.select.NodeVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cleaner
/*     */ {
/*     */   private final Safelist safelist;
/*     */   
/*     */   public Cleaner(Safelist safelist) {
/*  43 */     Validate.notNull(safelist);
/*  44 */     this.safelist = safelist;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Cleaner(Whitelist whitelist) {
/*  53 */     Validate.notNull(whitelist);
/*  54 */     this.safelist = whitelist;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document clean(Document dirtyDocument) {
/*  65 */     Validate.notNull(dirtyDocument);
/*     */     
/*  67 */     Document clean = Document.createShell(dirtyDocument.baseUri());
/*  68 */     copySafeNodes(dirtyDocument.body(), clean.body());
/*  69 */     clean.outputSettings(dirtyDocument.outputSettings().clone());
/*     */     
/*  71 */     return clean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid(Document dirtyDocument) {
/*  86 */     Validate.notNull(dirtyDocument);
/*     */     
/*  88 */     Document clean = Document.createShell(dirtyDocument.baseUri());
/*  89 */     int numDiscarded = copySafeNodes(dirtyDocument.body(), clean.body());
/*  90 */     return (numDiscarded == 0 && dirtyDocument
/*  91 */       .head().childNodes().isEmpty());
/*     */   }
/*     */   
/*     */   public boolean isValidBodyHtml(String bodyHtml) {
/*  95 */     Document clean = Document.createShell("");
/*  96 */     Document dirty = Document.createShell("");
/*  97 */     ParseErrorList errorList = ParseErrorList.tracking(1);
/*  98 */     List<Node> nodes = Parser.parseFragment(bodyHtml, dirty.body(), "", errorList);
/*  99 */     dirty.body().insertChildren(0, nodes);
/* 100 */     int numDiscarded = copySafeNodes(dirty.body(), clean.body());
/* 101 */     return (numDiscarded == 0 && errorList.isEmpty());
/*     */   }
/*     */ 
/*     */   
/*     */   private final class CleaningVisitor
/*     */     implements NodeVisitor
/*     */   {
/* 108 */     private int numDiscarded = 0;
/*     */     private final Element root;
/*     */     private Element destination;
/*     */     
/*     */     private CleaningVisitor(Element root, Element destination) {
/* 113 */       this.root = root;
/* 114 */       this.destination = destination;
/*     */     }
/*     */     
/*     */     public void head(Node source, int depth) {
/* 118 */       if (source instanceof Element) {
/* 119 */         Element sourceEl = (Element)source;
/*     */         
/* 121 */         if (Cleaner.this.safelist.isSafeTag(sourceEl.normalName())) {
/* 122 */           Cleaner.ElementMeta meta = Cleaner.this.createSafeElement(sourceEl);
/* 123 */           Element destChild = meta.el;
/* 124 */           this.destination.appendChild((Node)destChild);
/*     */           
/* 126 */           this.numDiscarded += meta.numAttribsDiscarded;
/* 127 */           this.destination = destChild;
/* 128 */         } else if (source != this.root) {
/* 129 */           this.numDiscarded++;
/*     */         } 
/* 131 */       } else if (source instanceof TextNode) {
/* 132 */         TextNode sourceText = (TextNode)source;
/* 133 */         TextNode destText = new TextNode(sourceText.getWholeText());
/* 134 */         this.destination.appendChild((Node)destText);
/* 135 */       } else if (source instanceof DataNode && Cleaner.this.safelist.isSafeTag(source.parent().nodeName())) {
/* 136 */         DataNode sourceData = (DataNode)source;
/* 137 */         DataNode destData = new DataNode(sourceData.getWholeData());
/* 138 */         this.destination.appendChild((Node)destData);
/*     */       } else {
/* 140 */         this.numDiscarded++;
/*     */       } 
/*     */     }
/*     */     
/*     */     public void tail(Node source, int depth) {
/* 145 */       if (source instanceof Element && Cleaner.this.safelist.isSafeTag(source.nodeName())) {
/* 146 */         this.destination = this.destination.parent();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private int copySafeNodes(Element source, Element dest) {
/* 152 */     CleaningVisitor cleaningVisitor = new CleaningVisitor(source, dest);
/* 153 */     NodeTraversor.traverse(cleaningVisitor, (Node)source);
/* 154 */     return cleaningVisitor.numDiscarded;
/*     */   }
/*     */   
/*     */   private ElementMeta createSafeElement(Element sourceEl) {
/* 158 */     String sourceTag = sourceEl.tagName();
/* 159 */     Attributes destAttrs = new Attributes();
/* 160 */     Element dest = new Element(Tag.valueOf(sourceTag), sourceEl.baseUri(), destAttrs);
/* 161 */     int numDiscarded = 0;
/*     */     
/* 163 */     Attributes sourceAttrs = sourceEl.attributes();
/* 164 */     for (Attribute sourceAttr : sourceAttrs) {
/* 165 */       if (this.safelist.isSafeAttribute(sourceTag, sourceEl, sourceAttr)) {
/* 166 */         destAttrs.put(sourceAttr); continue;
/*     */       } 
/* 168 */       numDiscarded++;
/*     */     } 
/* 170 */     Attributes enforcedAttrs = this.safelist.getEnforcedAttributes(sourceTag);
/* 171 */     destAttrs.addAll(enforcedAttrs);
/*     */     
/* 173 */     return new ElementMeta(dest, numDiscarded);
/*     */   }
/*     */   
/*     */   private static class ElementMeta {
/*     */     Element el;
/*     */     int numAttribsDiscarded;
/*     */     
/*     */     ElementMeta(Element el, int numAttribsDiscarded) {
/* 181 */       this.el = el;
/* 182 */       this.numAttribsDiscarded = numAttribsDiscarded;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\safety\Cleaner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */