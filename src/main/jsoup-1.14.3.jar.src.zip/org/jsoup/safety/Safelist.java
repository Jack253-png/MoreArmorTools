/*     */ package org.jsoup.safety;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.internal.Normalizer;
/*     */ import org.jsoup.nodes.Attribute;
/*     */ import org.jsoup.nodes.Attributes;
/*     */ import org.jsoup.nodes.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Safelist
/*     */ {
/*     */   private Set<TagName> tagNames;
/*     */   private Map<TagName, Set<AttributeKey>> attributes;
/*     */   private Map<TagName, Map<AttributeKey, AttributeValue>> enforcedAttributes;
/*     */   private Map<TagName, Map<AttributeKey, Set<Protocol>>> protocols;
/*     */   private boolean preserveRelativeLinks;
/*     */   
/*     */   public static Safelist none() {
/*  78 */     return new Safelist();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Safelist simpleText() {
/*  88 */     return (new Safelist())
/*  89 */       .addTags(new String[] { "b", "em", "i", "strong", "u" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Safelist basic() {
/* 109 */     return (new Safelist())
/* 110 */       .addTags(new String[] { 
/*     */           "a", "b", "blockquote", "br", "cite", "code", "dd", "dl", "dt", "em",
/*     */           
/*     */           "i", "li", "ol", "p", "pre", "q", "small", "span", "strike", "strong", 
/*     */           "sub", "sup", "u", "ul"
/* 115 */         }).addAttributes("a", new String[] { "href"
/* 116 */         }).addAttributes("blockquote", new String[] { "cite"
/* 117 */         }).addAttributes("q", new String[] { "cite"
/*     */         
/* 119 */         }).addProtocols("a", "href", new String[] { "ftp", "http", "https", "mailto"
/* 120 */         }).addProtocols("blockquote", "cite", new String[] { "http", "https"
/* 121 */         }).addProtocols("cite", "cite", new String[] { "http", "https"
/*     */         
/* 123 */         }).addEnforcedAttribute("a", "rel", "nofollow");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Safelist basicWithImages() {
/* 135 */     return basic()
/* 136 */       .addTags(new String[] { "img"
/* 137 */         }).addAttributes("img", new String[] { "align", "alt", "height", "src", "title", "width"
/* 138 */         }).addProtocols("img", "src", new String[] { "http", "https" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Safelist relaxed() {
/* 153 */     return (new Safelist())
/* 154 */       .addTags(new String[] { 
/*     */           "a", "b", "blockquote", "br", "caption", "cite", "code", "col", "colgroup", "dd",
/*     */           
/*     */           "div", "dl", "dt", "em", "h1", "h2", "h3", "h4", "h5", "h6", 
/*     */           "i", "img", "li", "ol", "p", "pre", "q", "small", "span", "strike", 
/*     */           "strong", "sub", "sup", "table", "tbody", "td", "tfoot", "th", "thead", "tr", 
/*     */           "u", "ul"
/* 161 */         }).addAttributes("a", new String[] { "href", "title"
/* 162 */         }).addAttributes("blockquote", new String[] { "cite"
/* 163 */         }).addAttributes("col", new String[] { "span", "width"
/* 164 */         }).addAttributes("colgroup", new String[] { "span", "width"
/* 165 */         }).addAttributes("img", new String[] { "align", "alt", "height", "src", "title", "width"
/* 166 */         }).addAttributes("ol", new String[] { "start", "type"
/* 167 */         }).addAttributes("q", new String[] { "cite"
/* 168 */         }).addAttributes("table", new String[] { "summary", "width"
/* 169 */         }).addAttributes("td", new String[] { "abbr", "axis", "colspan", "rowspan", "width"
/* 170 */         }).addAttributes("th", new String[] {
/*     */           
/*     */           "abbr", "axis", "colspan", "rowspan", "scope", "width"
/* 173 */         }).addAttributes("ul", new String[] { "type"
/*     */         
/* 175 */         }).addProtocols("a", "href", new String[] { "ftp", "http", "https", "mailto"
/* 176 */         }).addProtocols("blockquote", "cite", new String[] { "http", "https"
/* 177 */         }).addProtocols("cite", "cite", new String[] { "http", "https"
/* 178 */         }).addProtocols("img", "src", new String[] { "http", "https"
/* 179 */         }).addProtocols("q", "cite", new String[] { "http", "https" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Safelist() {
/* 192 */     this.tagNames = new HashSet<>();
/* 193 */     this.attributes = new HashMap<>();
/* 194 */     this.enforcedAttributes = new HashMap<>();
/* 195 */     this.protocols = new HashMap<>();
/* 196 */     this.preserveRelativeLinks = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Safelist(Safelist copy) {
/* 204 */     this();
/* 205 */     this.tagNames.addAll(copy.tagNames);
/* 206 */     this.attributes.putAll(copy.attributes);
/* 207 */     this.enforcedAttributes.putAll(copy.enforcedAttributes);
/* 208 */     this.protocols.putAll(copy.protocols);
/* 209 */     this.preserveRelativeLinks = copy.preserveRelativeLinks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Safelist addTags(String... tags) {
/* 219 */     Validate.notNull(tags);
/*     */     
/* 221 */     for (String tagName : tags) {
/* 222 */       Validate.notEmpty(tagName);
/* 223 */       this.tagNames.add(TagName.valueOf(tagName));
/*     */     } 
/* 225 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Safelist removeTags(String... tags) {
/* 235 */     Validate.notNull(tags);
/*     */     
/* 237 */     for (String tag : tags) {
/* 238 */       Validate.notEmpty(tag);
/* 239 */       TagName tagName = TagName.valueOf(tag);
/*     */       
/* 241 */       if (this.tagNames.remove(tagName)) {
/* 242 */         this.attributes.remove(tagName);
/* 243 */         this.enforcedAttributes.remove(tagName);
/* 244 */         this.protocols.remove(tagName);
/*     */       } 
/*     */     } 
/* 247 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Safelist addAttributes(String tag, String... attributes) {
/* 266 */     Validate.notEmpty(tag);
/* 267 */     Validate.notNull(attributes);
/* 268 */     Validate.isTrue((attributes.length > 0), "No attribute names supplied.");
/*     */     
/* 270 */     TagName tagName = TagName.valueOf(tag);
/* 271 */     this.tagNames.add(tagName);
/* 272 */     Set<AttributeKey> attributeSet = new HashSet<>();
/* 273 */     for (String key : attributes) {
/* 274 */       Validate.notEmpty(key);
/* 275 */       attributeSet.add(AttributeKey.valueOf(key));
/*     */     } 
/* 277 */     if (this.attributes.containsKey(tagName)) {
/* 278 */       Set<AttributeKey> currentSet = this.attributes.get(tagName);
/* 279 */       currentSet.addAll(attributeSet);
/*     */     } else {
/* 281 */       this.attributes.put(tagName, attributeSet);
/*     */     } 
/* 283 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Safelist removeAttributes(String tag, String... attributes) {
/* 302 */     Validate.notEmpty(tag);
/* 303 */     Validate.notNull(attributes);
/* 304 */     Validate.isTrue((attributes.length > 0), "No attribute names supplied.");
/*     */     
/* 306 */     TagName tagName = TagName.valueOf(tag);
/* 307 */     Set<AttributeKey> attributeSet = new HashSet<>();
/* 308 */     for (String key : attributes) {
/* 309 */       Validate.notEmpty(key);
/* 310 */       attributeSet.add(AttributeKey.valueOf(key));
/*     */     } 
/* 312 */     if (this.tagNames.contains(tagName) && this.attributes.containsKey(tagName)) {
/* 313 */       Set<AttributeKey> currentSet = this.attributes.get(tagName);
/* 314 */       currentSet.removeAll(attributeSet);
/*     */       
/* 316 */       if (currentSet.isEmpty())
/* 317 */         this.attributes.remove(tagName); 
/*     */     } 
/* 319 */     if (tag.equals(":all"))
/* 320 */       for (TagName name : this.attributes.keySet()) {
/* 321 */         Set<AttributeKey> currentSet = this.attributes.get(name);
/* 322 */         currentSet.removeAll(attributeSet);
/*     */         
/* 324 */         if (currentSet.isEmpty())
/* 325 */           this.attributes.remove(name); 
/*     */       }  
/* 327 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Safelist addEnforcedAttribute(String tag, String attribute, String value) {
/* 344 */     Validate.notEmpty(tag);
/* 345 */     Validate.notEmpty(attribute);
/* 346 */     Validate.notEmpty(value);
/*     */     
/* 348 */     TagName tagName = TagName.valueOf(tag);
/* 349 */     this.tagNames.add(tagName);
/* 350 */     AttributeKey attrKey = AttributeKey.valueOf(attribute);
/* 351 */     AttributeValue attrVal = AttributeValue.valueOf(value);
/*     */     
/* 353 */     if (this.enforcedAttributes.containsKey(tagName)) {
/* 354 */       ((Map<AttributeKey, AttributeValue>)this.enforcedAttributes.get(tagName)).put(attrKey, attrVal);
/*     */     } else {
/* 356 */       Map<AttributeKey, AttributeValue> attrMap = new HashMap<>();
/* 357 */       attrMap.put(attrKey, attrVal);
/* 358 */       this.enforcedAttributes.put(tagName, attrMap);
/*     */     } 
/* 360 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Safelist removeEnforcedAttribute(String tag, String attribute) {
/* 371 */     Validate.notEmpty(tag);
/* 372 */     Validate.notEmpty(attribute);
/*     */     
/* 374 */     TagName tagName = TagName.valueOf(tag);
/* 375 */     if (this.tagNames.contains(tagName) && this.enforcedAttributes.containsKey(tagName)) {
/* 376 */       AttributeKey attrKey = AttributeKey.valueOf(attribute);
/* 377 */       Map<AttributeKey, AttributeValue> attrMap = this.enforcedAttributes.get(tagName);
/* 378 */       attrMap.remove(attrKey);
/*     */       
/* 380 */       if (attrMap.isEmpty())
/* 381 */         this.enforcedAttributes.remove(tagName); 
/*     */     } 
/* 383 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Safelist preserveRelativeLinks(boolean preserve) {
/* 402 */     this.preserveRelativeLinks = preserve;
/* 403 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Safelist addProtocols(String tag, String attribute, String... protocols) {
/*     */     Map<AttributeKey, Set<Protocol>> attrMap;
/*     */     Set<Protocol> protSet;
/* 423 */     Validate.notEmpty(tag);
/* 424 */     Validate.notEmpty(attribute);
/* 425 */     Validate.notNull(protocols);
/*     */     
/* 427 */     TagName tagName = TagName.valueOf(tag);
/* 428 */     AttributeKey attrKey = AttributeKey.valueOf(attribute);
/*     */ 
/*     */ 
/*     */     
/* 432 */     if (this.protocols.containsKey(tagName)) {
/* 433 */       attrMap = this.protocols.get(tagName);
/*     */     } else {
/* 435 */       attrMap = new HashMap<>();
/* 436 */       this.protocols.put(tagName, attrMap);
/*     */     } 
/* 438 */     if (attrMap.containsKey(attrKey)) {
/* 439 */       protSet = attrMap.get(attrKey);
/*     */     } else {
/* 441 */       protSet = new HashSet<>();
/* 442 */       attrMap.put(attrKey, protSet);
/*     */     } 
/* 444 */     for (String protocol : protocols) {
/* 445 */       Validate.notEmpty(protocol);
/* 446 */       Protocol prot = Protocol.valueOf(protocol);
/* 447 */       protSet.add(prot);
/*     */     } 
/* 449 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Safelist removeProtocols(String tag, String attribute, String... removeProtocols) {
/* 465 */     Validate.notEmpty(tag);
/* 466 */     Validate.notEmpty(attribute);
/* 467 */     Validate.notNull(removeProtocols);
/*     */     
/* 469 */     TagName tagName = TagName.valueOf(tag);
/* 470 */     AttributeKey attr = AttributeKey.valueOf(attribute);
/*     */ 
/*     */ 
/*     */     
/* 474 */     Validate.isTrue(this.protocols.containsKey(tagName), "Cannot remove a protocol that is not set.");
/* 475 */     Map<AttributeKey, Set<Protocol>> tagProtocols = this.protocols.get(tagName);
/* 476 */     Validate.isTrue(tagProtocols.containsKey(attr), "Cannot remove a protocol that is not set.");
/*     */     
/* 478 */     Set<Protocol> attrProtocols = tagProtocols.get(attr);
/* 479 */     for (String protocol : removeProtocols) {
/* 480 */       Validate.notEmpty(protocol);
/* 481 */       attrProtocols.remove(Protocol.valueOf(protocol));
/*     */     } 
/*     */     
/* 484 */     if (attrProtocols.isEmpty()) {
/* 485 */       tagProtocols.remove(attr);
/* 486 */       if (tagProtocols.isEmpty())
/* 487 */         this.protocols.remove(tagName); 
/*     */     } 
/* 489 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isSafeTag(String tag) {
/* 498 */     return this.tagNames.contains(TagName.valueOf(tag));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isSafeAttribute(String tagName, Element el, Attribute attr) {
/* 509 */     TagName tag = TagName.valueOf(tagName);
/* 510 */     AttributeKey key = AttributeKey.valueOf(attr.getKey());
/*     */     
/* 512 */     Set<AttributeKey> okSet = this.attributes.get(tag);
/* 513 */     if (okSet != null && okSet.contains(key)) {
/* 514 */       if (this.protocols.containsKey(tag)) {
/* 515 */         Map<AttributeKey, Set<Protocol>> attrProts = this.protocols.get(tag);
/*     */         
/* 517 */         return (!attrProts.containsKey(key) || testValidProtocol(el, attr, attrProts.get(key)));
/*     */       } 
/* 519 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 523 */     Map<AttributeKey, AttributeValue> enforcedSet = this.enforcedAttributes.get(tag);
/* 524 */     if (enforcedSet != null) {
/* 525 */       Attributes expect = getEnforcedAttributes(tagName);
/* 526 */       String attrKey = attr.getKey();
/* 527 */       if (expect.hasKeyIgnoreCase(attrKey)) {
/* 528 */         return expect.getIgnoreCase(attrKey).equals(attr.getValue());
/*     */       }
/*     */     } 
/*     */     
/* 532 */     return (!tagName.equals(":all") && isSafeAttribute(":all", el, attr));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean testValidProtocol(Element el, Attribute attr, Set<Protocol> protocols) {
/* 538 */     String value = el.absUrl(attr.getKey());
/* 539 */     if (value.length() == 0)
/* 540 */       value = attr.getValue(); 
/* 541 */     if (!this.preserveRelativeLinks) {
/* 542 */       attr.setValue(value);
/*     */     }
/* 544 */     for (Protocol protocol : protocols) {
/* 545 */       String prot = protocol.toString();
/*     */       
/* 547 */       if (prot.equals("#")) {
/* 548 */         if (isValidAnchor(value)) {
/* 549 */           return true;
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 555 */       prot = prot + ":";
/*     */       
/* 557 */       if (Normalizer.lowerCase(value).startsWith(prot)) {
/* 558 */         return true;
/*     */       }
/*     */     } 
/* 561 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isValidAnchor(String value) {
/* 565 */     return (value.startsWith("#") && !value.matches(".*\\s.*"));
/*     */   }
/*     */   
/*     */   Attributes getEnforcedAttributes(String tagName) {
/* 569 */     Attributes attrs = new Attributes();
/* 570 */     TagName tag = TagName.valueOf(tagName);
/* 571 */     if (this.enforcedAttributes.containsKey(tag)) {
/* 572 */       Map<AttributeKey, AttributeValue> keyVals = this.enforcedAttributes.get(tag);
/* 573 */       for (Map.Entry<AttributeKey, AttributeValue> entry : keyVals.entrySet()) {
/* 574 */         attrs.put(((AttributeKey)entry.getKey()).toString(), ((AttributeValue)entry.getValue()).toString());
/*     */       }
/*     */     } 
/* 577 */     return attrs;
/*     */   }
/*     */   
/*     */   static class TagName
/*     */     extends TypedValue
/*     */   {
/*     */     TagName(String value) {
/* 584 */       super(value);
/*     */     }
/*     */     
/*     */     static TagName valueOf(String value) {
/* 588 */       return new TagName(value);
/*     */     }
/*     */   }
/*     */   
/*     */   static class AttributeKey extends TypedValue {
/*     */     AttributeKey(String value) {
/* 594 */       super(value);
/*     */     }
/*     */     
/*     */     static AttributeKey valueOf(String value) {
/* 598 */       return new AttributeKey(value);
/*     */     }
/*     */   }
/*     */   
/*     */   static class AttributeValue extends TypedValue {
/*     */     AttributeValue(String value) {
/* 604 */       super(value);
/*     */     }
/*     */     
/*     */     static AttributeValue valueOf(String value) {
/* 608 */       return new AttributeValue(value);
/*     */     }
/*     */   }
/*     */   
/*     */   static class Protocol extends TypedValue {
/*     */     Protocol(String value) {
/* 614 */       super(value);
/*     */     }
/*     */     
/*     */     static Protocol valueOf(String value) {
/* 618 */       return new Protocol(value);
/*     */     }
/*     */   }
/*     */   
/*     */   static abstract class TypedValue {
/*     */     private String value;
/*     */     
/*     */     TypedValue(String value) {
/* 626 */       Validate.notNull(value);
/* 627 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 632 */       int prime = 31;
/* 633 */       int result = 1;
/* 634 */       result = 31 * result + ((this.value == null) ? 0 : this.value.hashCode());
/* 635 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 640 */       if (this == obj) return true; 
/* 641 */       if (obj == null) return false; 
/* 642 */       if (getClass() != obj.getClass()) return false; 
/* 643 */       TypedValue other = (TypedValue)obj;
/* 644 */       if (this.value == null)
/* 645 */         return (other.value == null); 
/* 646 */       return this.value.equals(other.value);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 651 */       return this.value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\safety\Safelist.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */