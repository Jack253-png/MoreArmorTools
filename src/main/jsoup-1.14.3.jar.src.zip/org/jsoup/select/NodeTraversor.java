/*     */ package org.jsoup.select;
/*     */ 
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.nodes.Element;
/*     */ import org.jsoup.nodes.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NodeTraversor
/*     */ {
/*     */   public static void traverse(NodeVisitor visitor, Node root) {
/*  21 */     Validate.notNull(visitor);
/*  22 */     Validate.notNull(root);
/*     */     
/*  24 */     Node node = root;
/*     */     
/*  26 */     int depth = 0;
/*     */     
/*  28 */     while (node != null) {
/*  29 */       Node parent = node.parentNode();
/*  30 */       visitor.head(node, depth);
/*  31 */       if (parent != null && !node.hasParent()) {
/*  32 */         node = parent.childNode(node.siblingIndex());
/*     */       }
/*  34 */       if (node.childNodeSize() > 0) {
/*  35 */         node = node.childNode(0);
/*  36 */         depth++; continue;
/*     */       } 
/*     */       while (true) {
/*  39 */         assert node != null;
/*  40 */         if (node.nextSibling() != null || depth <= 0)
/*  41 */           break;  visitor.tail(node, depth);
/*  42 */         node = node.parentNode();
/*  43 */         depth--;
/*     */       } 
/*  45 */       visitor.tail(node, depth);
/*  46 */       if (node == root)
/*     */         break; 
/*  48 */       node = node.nextSibling();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void traverse(NodeVisitor visitor, Elements elements) {
/*  59 */     Validate.notNull(visitor);
/*  60 */     Validate.notNull(elements);
/*  61 */     for (Element el : elements) {
/*  62 */       traverse(visitor, (Node)el);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NodeFilter.FilterResult filter(NodeFilter filter, Node root) {
/*  72 */     Node node = root;
/*  73 */     int depth = 0;
/*     */     
/*  75 */     while (node != null) {
/*  76 */       NodeFilter.FilterResult result = filter.head(node, depth);
/*  77 */       if (result == NodeFilter.FilterResult.STOP) {
/*  78 */         return result;
/*     */       }
/*  80 */       if (result == NodeFilter.FilterResult.CONTINUE && node.childNodeSize() > 0) {
/*  81 */         node = node.childNode(0);
/*  82 */         depth++;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       while (true) {
/*  87 */         assert node != null;
/*  88 */         if (node.nextSibling() != null || depth <= 0)
/*     */           break; 
/*  90 */         if (result == NodeFilter.FilterResult.CONTINUE || result == NodeFilter.FilterResult.SKIP_CHILDREN) {
/*  91 */           result = filter.tail(node, depth);
/*  92 */           if (result == NodeFilter.FilterResult.STOP)
/*  93 */             return result; 
/*     */         } 
/*  95 */         Node node1 = node;
/*  96 */         node = node.parentNode();
/*  97 */         depth--;
/*  98 */         if (result == NodeFilter.FilterResult.REMOVE)
/*  99 */           node1.remove(); 
/* 100 */         result = NodeFilter.FilterResult.CONTINUE;
/*     */       } 
/*     */       
/* 103 */       if (result == NodeFilter.FilterResult.CONTINUE || result == NodeFilter.FilterResult.SKIP_CHILDREN) {
/* 104 */         result = filter.tail(node, depth);
/* 105 */         if (result == NodeFilter.FilterResult.STOP)
/* 106 */           return result; 
/*     */       } 
/* 108 */       if (node == root)
/* 109 */         return result; 
/* 110 */       Node prev = node;
/* 111 */       node = node.nextSibling();
/* 112 */       if (result == NodeFilter.FilterResult.REMOVE) {
/* 113 */         prev.remove();
/*     */       }
/*     */     } 
/* 116 */     return NodeFilter.FilterResult.CONTINUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void filter(NodeFilter filter, Elements elements) {
/* 125 */     Validate.notNull(filter);
/* 126 */     Validate.notNull(elements);
/* 127 */     for (Element el : elements) {
/* 128 */       if (filter(filter, (Node)el) == NodeFilter.FilterResult.STOP)
/*     */         break; 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\select\NodeTraversor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */