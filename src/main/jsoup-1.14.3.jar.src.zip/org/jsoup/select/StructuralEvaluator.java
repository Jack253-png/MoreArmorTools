/*     */ package org.jsoup.select;
/*     */ 
/*     */ import org.jsoup.nodes.Element;
/*     */ import org.jsoup.nodes.Node;
/*     */ 
/*     */ abstract class StructuralEvaluator
/*     */   extends Evaluator
/*     */ {
/*     */   Evaluator evaluator;
/*     */   
/*     */   static class Root
/*     */     extends Evaluator {
/*     */     public boolean matches(Element root, Element element) {
/*  14 */       return (root == element);
/*     */     }
/*     */   }
/*     */   
/*     */   static class Has extends StructuralEvaluator {
/*     */     final Collector.FirstFinder finder;
/*     */     
/*     */     public Has(Evaluator evaluator) {
/*  22 */       this.evaluator = evaluator;
/*  23 */       this.finder = new Collector.FirstFinder(evaluator);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Element root, Element element) {
/*  28 */       for (int i = 0; i < element.childNodeSize(); i++) {
/*  29 */         Node node = element.childNode(i);
/*  30 */         if (node instanceof Element) {
/*  31 */           Element match = this.finder.find(element, (Element)node);
/*  32 */           if (match != null)
/*  33 */             return true; 
/*     */         } 
/*     */       } 
/*  36 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  41 */       return String.format(":has(%s)", new Object[] { this.evaluator });
/*     */     }
/*     */   }
/*     */   
/*     */   static class Not extends StructuralEvaluator {
/*     */     public Not(Evaluator evaluator) {
/*  47 */       this.evaluator = evaluator;
/*     */     }
/*     */     
/*     */     public boolean matches(Element root, Element node) {
/*  51 */       return !this.evaluator.matches(root, node);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  56 */       return String.format(":not(%s)", new Object[] { this.evaluator });
/*     */     }
/*     */   }
/*     */   
/*     */   static class Parent extends StructuralEvaluator {
/*     */     public Parent(Evaluator evaluator) {
/*  62 */       this.evaluator = evaluator;
/*     */     }
/*     */     
/*     */     public boolean matches(Element root, Element element) {
/*  66 */       if (root == element) {
/*  67 */         return false;
/*     */       }
/*  69 */       Element parent = element.parent();
/*  70 */       while (parent != null) {
/*  71 */         if (this.evaluator.matches(root, parent))
/*  72 */           return true; 
/*  73 */         if (parent == root)
/*     */           break; 
/*  75 */         parent = parent.parent();
/*     */       } 
/*  77 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  82 */       return String.format("%s ", new Object[] { this.evaluator });
/*     */     }
/*     */   }
/*     */   
/*     */   static class ImmediateParent extends StructuralEvaluator {
/*     */     public ImmediateParent(Evaluator evaluator) {
/*  88 */       this.evaluator = evaluator;
/*     */     }
/*     */     
/*     */     public boolean matches(Element root, Element element) {
/*  92 */       if (root == element) {
/*  93 */         return false;
/*     */       }
/*  95 */       Element parent = element.parent();
/*  96 */       return (parent != null && this.evaluator.matches(root, parent));
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 101 */       return String.format("%s > ", new Object[] { this.evaluator });
/*     */     }
/*     */   }
/*     */   
/*     */   static class PreviousSibling extends StructuralEvaluator {
/*     */     public PreviousSibling(Evaluator evaluator) {
/* 107 */       this.evaluator = evaluator;
/*     */     }
/*     */     
/*     */     public boolean matches(Element root, Element element) {
/* 111 */       if (root == element) {
/* 112 */         return false;
/*     */       }
/* 114 */       Element prev = element.previousElementSibling();
/*     */       
/* 116 */       while (prev != null) {
/* 117 */         if (this.evaluator.matches(root, prev)) {
/* 118 */           return true;
/*     */         }
/* 120 */         prev = prev.previousElementSibling();
/*     */       } 
/* 122 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 127 */       return String.format("%s ~ ", new Object[] { this.evaluator });
/*     */     }
/*     */   }
/*     */   
/*     */   static class ImmediatePreviousSibling extends StructuralEvaluator {
/*     */     public ImmediatePreviousSibling(Evaluator evaluator) {
/* 133 */       this.evaluator = evaluator;
/*     */     }
/*     */     
/*     */     public boolean matches(Element root, Element element) {
/* 137 */       if (root == element) {
/* 138 */         return false;
/*     */       }
/* 140 */       Element prev = element.previousElementSibling();
/* 141 */       return (prev != null && this.evaluator.matches(root, prev));
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 146 */       return String.format("%s + ", new Object[] { this.evaluator });
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\select\StructuralEvaluator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */