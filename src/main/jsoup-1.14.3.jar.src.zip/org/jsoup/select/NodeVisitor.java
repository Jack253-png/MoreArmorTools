package org.jsoup.select;

import org.jsoup.nodes.Node;

public interface NodeVisitor {
  void head(Node paramNode, int paramInt);
  
  void tail(Node paramNode, int paramInt);
}


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\select\NodeVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */