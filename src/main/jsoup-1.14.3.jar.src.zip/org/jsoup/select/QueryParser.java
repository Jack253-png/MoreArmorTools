/*     */ package org.jsoup.select;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.internal.Normalizer;
/*     */ import org.jsoup.internal.StringUtil;
/*     */ import org.jsoup.parser.TokenQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryParser
/*     */ {
/*  18 */   private static final String[] combinators = new String[] { ",", ">", "+", "~", " " };
/*  19 */   private static final String[] AttributeEvals = new String[] { "=", "!=", "^=", "$=", "*=", "~=" };
/*     */   
/*     */   private final TokenQueue tq;
/*     */   private final String query;
/*  23 */   private final List<Evaluator> evals = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private QueryParser(String query) {
/*  30 */     Validate.notEmpty(query);
/*  31 */     query = query.trim();
/*  32 */     this.query = query;
/*  33 */     this.tq = new TokenQueue(query);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Evaluator parse(String query) {
/*     */     try {
/*  44 */       QueryParser p = new QueryParser(query);
/*  45 */       return p.parse();
/*  46 */     } catch (IllegalArgumentException e) {
/*  47 */       throw new Selector.SelectorParseException(e.getMessage(), new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Evaluator parse() {
/*  56 */     this.tq.consumeWhitespace();
/*     */     
/*  58 */     if (this.tq.matchesAny(combinators)) {
/*  59 */       this.evals.add(new StructuralEvaluator.Root());
/*  60 */       combinator(this.tq.consume());
/*     */     } else {
/*  62 */       findElements();
/*     */     } 
/*     */     
/*  65 */     while (!this.tq.isEmpty()) {
/*     */       
/*  67 */       boolean seenWhite = this.tq.consumeWhitespace();
/*     */       
/*  69 */       if (this.tq.matchesAny(combinators)) {
/*  70 */         combinator(this.tq.consume()); continue;
/*  71 */       }  if (seenWhite) {
/*  72 */         combinator(' '); continue;
/*     */       } 
/*  74 */       findElements();
/*     */     } 
/*     */ 
/*     */     
/*  78 */     if (this.evals.size() == 1) {
/*  79 */       return this.evals.get(0);
/*     */     }
/*  81 */     return new CombiningEvaluator.And(this.evals);
/*     */   } private void combinator(char combinator) {
/*     */     Evaluator rootEval, currentEval;
/*     */     CombiningEvaluator.Or or;
/*  85 */     this.tq.consumeWhitespace();
/*  86 */     String subQuery = consumeSubQuery();
/*     */ 
/*     */ 
/*     */     
/*  90 */     Evaluator newEval = parse(subQuery);
/*  91 */     boolean replaceRightMost = false;
/*     */     
/*  93 */     if (this.evals.size() == 1) {
/*  94 */       rootEval = currentEval = this.evals.get(0);
/*     */       
/*  96 */       if (rootEval instanceof CombiningEvaluator.Or && combinator != ',') {
/*  97 */         currentEval = ((CombiningEvaluator.Or)currentEval).rightMostEvaluator();
/*  98 */         assert currentEval != null;
/*  99 */         replaceRightMost = true;
/*     */       } 
/*     */     } else {
/*     */       
/* 103 */       rootEval = currentEval = new CombiningEvaluator.And(this.evals);
/*     */     } 
/* 105 */     this.evals.clear();
/*     */ 
/*     */     
/* 108 */     switch (combinator) {
/*     */       case '>':
/* 110 */         currentEval = new CombiningEvaluator.And(new Evaluator[] { new StructuralEvaluator.ImmediateParent(currentEval), newEval });
/*     */         break;
/*     */       case ' ':
/* 113 */         currentEval = new CombiningEvaluator.And(new Evaluator[] { new StructuralEvaluator.Parent(currentEval), newEval });
/*     */         break;
/*     */       case '+':
/* 116 */         currentEval = new CombiningEvaluator.And(new Evaluator[] { new StructuralEvaluator.ImmediatePreviousSibling(currentEval), newEval });
/*     */         break;
/*     */       case '~':
/* 119 */         currentEval = new CombiningEvaluator.And(new Evaluator[] { new StructuralEvaluator.PreviousSibling(currentEval), newEval });
/*     */         break;
/*     */       
/*     */       case ',':
/* 123 */         if (currentEval instanceof CombiningEvaluator.Or) {
/* 124 */           or = (CombiningEvaluator.Or)currentEval;
/*     */         } else {
/* 126 */           or = new CombiningEvaluator.Or();
/* 127 */           or.add(currentEval);
/*     */         } 
/* 129 */         or.add(newEval);
/* 130 */         currentEval = or;
/*     */         break;
/*     */       default:
/* 133 */         throw new Selector.SelectorParseException("Unknown combinator: " + combinator, new Object[0]);
/*     */     } 
/*     */     
/* 136 */     if (replaceRightMost)
/* 137 */     { ((CombiningEvaluator.Or)rootEval).replaceRightMostEvaluator(currentEval); }
/* 138 */     else { rootEval = currentEval; }
/* 139 */      this.evals.add(rootEval);
/*     */   }
/*     */   
/*     */   private String consumeSubQuery() {
/* 143 */     StringBuilder sq = StringUtil.borrowBuilder();
/* 144 */     while (!this.tq.isEmpty()) {
/* 145 */       if (this.tq.matches("(")) {
/* 146 */         sq.append("(").append(this.tq.chompBalanced('(', ')')).append(")"); continue;
/* 147 */       }  if (this.tq.matches("[")) {
/* 148 */         sq.append("[").append(this.tq.chompBalanced('[', ']')).append("]"); continue;
/* 149 */       }  if (this.tq.matchesAny(combinators)) {
/* 150 */         if (sq.length() > 0) {
/*     */           break;
/*     */         }
/* 153 */         this.tq.consume(); continue;
/*     */       } 
/* 155 */       sq.append(this.tq.consume());
/*     */     } 
/* 157 */     return StringUtil.releaseBuilder(sq);
/*     */   }
/*     */   
/*     */   private void findElements() {
/* 161 */     if (this.tq.matchChomp("#")) {
/* 162 */       byId();
/* 163 */     } else if (this.tq.matchChomp(".")) {
/* 164 */       byClass();
/* 165 */     } else if (this.tq.matchesWord() || this.tq.matches("*|")) {
/* 166 */       byTag();
/* 167 */     } else if (this.tq.matches("[")) {
/* 168 */       byAttribute();
/* 169 */     } else if (this.tq.matchChomp("*")) {
/* 170 */       allElements();
/* 171 */     } else if (this.tq.matchChomp(":lt(")) {
/* 172 */       indexLessThan();
/* 173 */     } else if (this.tq.matchChomp(":gt(")) {
/* 174 */       indexGreaterThan();
/* 175 */     } else if (this.tq.matchChomp(":eq(")) {
/* 176 */       indexEquals();
/* 177 */     } else if (this.tq.matches(":has(")) {
/* 178 */       has();
/* 179 */     } else if (this.tq.matches(":contains(")) {
/* 180 */       contains(false);
/* 181 */     } else if (this.tq.matches(":containsOwn(")) {
/* 182 */       contains(true);
/* 183 */     } else if (this.tq.matches(":containsData(")) {
/* 184 */       containsData();
/* 185 */     } else if (this.tq.matches(":matches(")) {
/* 186 */       matches(false);
/* 187 */     } else if (this.tq.matches(":matchesOwn(")) {
/* 188 */       matches(true);
/* 189 */     } else if (this.tq.matches(":not(")) {
/* 190 */       not();
/* 191 */     } else if (this.tq.matchChomp(":nth-child(")) {
/* 192 */       cssNthChild(false, false);
/* 193 */     } else if (this.tq.matchChomp(":nth-last-child(")) {
/* 194 */       cssNthChild(true, false);
/* 195 */     } else if (this.tq.matchChomp(":nth-of-type(")) {
/* 196 */       cssNthChild(false, true);
/* 197 */     } else if (this.tq.matchChomp(":nth-last-of-type(")) {
/* 198 */       cssNthChild(true, true);
/* 199 */     } else if (this.tq.matchChomp(":first-child")) {
/* 200 */       this.evals.add(new Evaluator.IsFirstChild());
/* 201 */     } else if (this.tq.matchChomp(":last-child")) {
/* 202 */       this.evals.add(new Evaluator.IsLastChild());
/* 203 */     } else if (this.tq.matchChomp(":first-of-type")) {
/* 204 */       this.evals.add(new Evaluator.IsFirstOfType());
/* 205 */     } else if (this.tq.matchChomp(":last-of-type")) {
/* 206 */       this.evals.add(new Evaluator.IsLastOfType());
/* 207 */     } else if (this.tq.matchChomp(":only-child")) {
/* 208 */       this.evals.add(new Evaluator.IsOnlyChild());
/* 209 */     } else if (this.tq.matchChomp(":only-of-type")) {
/* 210 */       this.evals.add(new Evaluator.IsOnlyOfType());
/* 211 */     } else if (this.tq.matchChomp(":empty")) {
/* 212 */       this.evals.add(new Evaluator.IsEmpty());
/* 213 */     } else if (this.tq.matchChomp(":root")) {
/* 214 */       this.evals.add(new Evaluator.IsRoot());
/* 215 */     } else if (this.tq.matchChomp(":matchText")) {
/* 216 */       this.evals.add(new Evaluator.MatchText());
/*     */     } else {
/* 218 */       throw new Selector.SelectorParseException("Could not parse query '%s': unexpected token at '%s'", new Object[] { this.query, this.tq.remainder() });
/*     */     } 
/*     */   }
/*     */   
/*     */   private void byId() {
/* 223 */     String id = this.tq.consumeCssIdentifier();
/* 224 */     Validate.notEmpty(id);
/* 225 */     this.evals.add(new Evaluator.Id(id));
/*     */   }
/*     */   
/*     */   private void byClass() {
/* 229 */     String className = this.tq.consumeCssIdentifier();
/* 230 */     Validate.notEmpty(className);
/* 231 */     this.evals.add(new Evaluator.Class(className.trim()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void byTag() {
/* 238 */     String tagName = Normalizer.normalize(this.tq.consumeElementSelector());
/* 239 */     Validate.notEmpty(tagName);
/*     */ 
/*     */     
/* 242 */     if (tagName.startsWith("*|")) {
/* 243 */       String plainTag = tagName.substring(2);
/* 244 */       this.evals.add(new CombiningEvaluator.Or(new Evaluator[] { new Evaluator.Tag(plainTag), new Evaluator.TagEndsWith(tagName
/*     */                 
/* 246 */                 .replace("*|", ":")) }));
/*     */     }
/*     */     else {
/*     */       
/* 250 */       if (tagName.contains("|")) {
/* 251 */         tagName = tagName.replace("|", ":");
/*     */       }
/* 253 */       this.evals.add(new Evaluator.Tag(tagName));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void byAttribute() {
/* 258 */     TokenQueue cq = new TokenQueue(this.tq.chompBalanced('[', ']'));
/* 259 */     String key = cq.consumeToAny(AttributeEvals);
/* 260 */     Validate.notEmpty(key);
/* 261 */     cq.consumeWhitespace();
/*     */     
/* 263 */     if (cq.isEmpty()) {
/* 264 */       if (key.startsWith("^")) {
/* 265 */         this.evals.add(new Evaluator.AttributeStarting(key.substring(1)));
/*     */       } else {
/* 267 */         this.evals.add(new Evaluator.Attribute(key));
/*     */       } 
/* 269 */     } else if (cq.matchChomp("=")) {
/* 270 */       this.evals.add(new Evaluator.AttributeWithValue(key, cq.remainder()));
/*     */     }
/* 272 */     else if (cq.matchChomp("!=")) {
/* 273 */       this.evals.add(new Evaluator.AttributeWithValueNot(key, cq.remainder()));
/*     */     }
/* 275 */     else if (cq.matchChomp("^=")) {
/* 276 */       this.evals.add(new Evaluator.AttributeWithValueStarting(key, cq.remainder()));
/*     */     }
/* 278 */     else if (cq.matchChomp("$=")) {
/* 279 */       this.evals.add(new Evaluator.AttributeWithValueEnding(key, cq.remainder()));
/*     */     }
/* 281 */     else if (cq.matchChomp("*=")) {
/* 282 */       this.evals.add(new Evaluator.AttributeWithValueContaining(key, cq.remainder()));
/*     */     }
/* 284 */     else if (cq.matchChomp("~=")) {
/* 285 */       this.evals.add(new Evaluator.AttributeWithValueMatching(key, Pattern.compile(cq.remainder())));
/*     */     } else {
/* 287 */       throw new Selector.SelectorParseException("Could not parse attribute query '%s': unexpected token at '%s'", new Object[] { this.query, cq.remainder() });
/*     */     } 
/*     */   }
/*     */   
/*     */   private void allElements() {
/* 292 */     this.evals.add(new Evaluator.AllElements());
/*     */   }
/*     */ 
/*     */   
/*     */   private void indexLessThan() {
/* 297 */     this.evals.add(new Evaluator.IndexLessThan(consumeIndex()));
/*     */   }
/*     */   
/*     */   private void indexGreaterThan() {
/* 301 */     this.evals.add(new Evaluator.IndexGreaterThan(consumeIndex()));
/*     */   }
/*     */   
/*     */   private void indexEquals() {
/* 305 */     this.evals.add(new Evaluator.IndexEquals(consumeIndex()));
/*     */   }
/*     */ 
/*     */   
/* 309 */   private static final Pattern NTH_AB = Pattern.compile("(([+-])?(\\d+)?)n(\\s*([+-])?\\s*\\d+)?", 2);
/* 310 */   private static final Pattern NTH_B = Pattern.compile("([+-])?(\\d+)");
/*     */   private void cssNthChild(boolean backwards, boolean ofType) {
/*     */     int a, b;
/* 313 */     String argS = Normalizer.normalize(this.tq.chompTo(")"));
/* 314 */     Matcher mAB = NTH_AB.matcher(argS);
/* 315 */     Matcher mB = NTH_B.matcher(argS);
/*     */     
/* 317 */     if ("odd".equals(argS)) {
/* 318 */       a = 2;
/* 319 */       b = 1;
/* 320 */     } else if ("even".equals(argS)) {
/* 321 */       a = 2;
/* 322 */       b = 0;
/* 323 */     } else if (mAB.matches()) {
/* 324 */       a = (mAB.group(3) != null) ? Integer.parseInt(mAB.group(1).replaceFirst("^\\+", "")) : 1;
/* 325 */       b = (mAB.group(4) != null) ? Integer.parseInt(mAB.group(4).replaceFirst("^\\+", "")) : 0;
/* 326 */     } else if (mB.matches()) {
/* 327 */       a = 0;
/* 328 */       b = Integer.parseInt(mB.group().replaceFirst("^\\+", ""));
/*     */     } else {
/* 330 */       throw new Selector.SelectorParseException("Could not parse nth-index '%s': unexpected format", new Object[] { argS });
/*     */     } 
/* 332 */     if (ofType) {
/* 333 */       if (backwards) {
/* 334 */         this.evals.add(new Evaluator.IsNthLastOfType(a, b));
/*     */       } else {
/* 336 */         this.evals.add(new Evaluator.IsNthOfType(a, b));
/*     */       } 
/* 338 */     } else if (backwards) {
/* 339 */       this.evals.add(new Evaluator.IsNthLastChild(a, b));
/*     */     } else {
/* 341 */       this.evals.add(new Evaluator.IsNthChild(a, b));
/*     */     } 
/*     */   }
/*     */   
/*     */   private int consumeIndex() {
/* 346 */     String indexS = this.tq.chompTo(")").trim();
/* 347 */     Validate.isTrue(StringUtil.isNumeric(indexS), "Index must be numeric");
/* 348 */     return Integer.parseInt(indexS);
/*     */   }
/*     */ 
/*     */   
/*     */   private void has() {
/* 353 */     this.tq.consume(":has");
/* 354 */     String subQuery = this.tq.chompBalanced('(', ')');
/* 355 */     Validate.notEmpty(subQuery, ":has(selector) subselect must not be empty");
/* 356 */     this.evals.add(new StructuralEvaluator.Has(parse(subQuery)));
/*     */   }
/*     */ 
/*     */   
/*     */   private void contains(boolean own) {
/* 361 */     this.tq.consume(own ? ":containsOwn" : ":contains");
/* 362 */     String searchText = TokenQueue.unescape(this.tq.chompBalanced('(', ')'));
/* 363 */     Validate.notEmpty(searchText, ":contains(text) query must not be empty");
/* 364 */     if (own) {
/* 365 */       this.evals.add(new Evaluator.ContainsOwnText(searchText));
/*     */     } else {
/* 367 */       this.evals.add(new Evaluator.ContainsText(searchText));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void containsData() {
/* 372 */     this.tq.consume(":containsData");
/* 373 */     String searchText = TokenQueue.unescape(this.tq.chompBalanced('(', ')'));
/* 374 */     Validate.notEmpty(searchText, ":containsData(text) query must not be empty");
/* 375 */     this.evals.add(new Evaluator.ContainsData(searchText));
/*     */   }
/*     */ 
/*     */   
/*     */   private void matches(boolean own) {
/* 380 */     this.tq.consume(own ? ":matchesOwn" : ":matches");
/* 381 */     String regex = this.tq.chompBalanced('(', ')');
/* 382 */     Validate.notEmpty(regex, ":matches(regex) query must not be empty");
/*     */     
/* 384 */     if (own) {
/* 385 */       this.evals.add(new Evaluator.MatchesOwn(Pattern.compile(regex)));
/*     */     } else {
/* 387 */       this.evals.add(new Evaluator.Matches(Pattern.compile(regex)));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void not() {
/* 392 */     this.tq.consume(":not");
/* 393 */     String subQuery = this.tq.chompBalanced('(', ')');
/* 394 */     Validate.notEmpty(subQuery, ":not(selector) subselect must not be empty");
/*     */     
/* 396 */     this.evals.add(new StructuralEvaluator.Not(parse(subQuery)));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 401 */     return this.query;
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\select\QueryParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */