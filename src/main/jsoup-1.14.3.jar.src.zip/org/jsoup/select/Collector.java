/*    */ package org.jsoup.select;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ import org.jsoup.nodes.Element;
/*    */ import org.jsoup.nodes.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Collector
/*    */ {
/*    */   public static Elements collect(Evaluator eval, Element root) {
/* 27 */     Elements elements = new Elements();
/* 28 */     NodeTraversor.traverse(new Accumulator(root, elements, eval), (Node)root);
/* 29 */     return elements;
/*    */   }
/*    */   
/*    */   private static class Accumulator implements NodeVisitor {
/*    */     private final Element root;
/*    */     private final Elements elements;
/*    */     private final Evaluator eval;
/*    */     
/*    */     Accumulator(Element root, Elements elements, Evaluator eval) {
/* 38 */       this.root = root;
/* 39 */       this.elements = elements;
/* 40 */       this.eval = eval;
/*    */     }
/*    */     
/*    */     public void head(Node node, int depth) {
/* 44 */       if (node instanceof Element) {
/* 45 */         Element el = (Element)node;
/* 46 */         if (this.eval.matches(this.root, el)) {
/* 47 */           this.elements.add(el);
/*    */         }
/*    */       } 
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public void tail(Node node, int depth) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public static Element findFirst(Evaluator eval, Element root) {
/* 64 */     FirstFinder finder = new FirstFinder(eval);
/* 65 */     return finder.find(root, root);
/*    */   }
/*    */   
/*    */   static class FirstFinder implements NodeFilter { @Nullable
/* 69 */     private Element evalRoot = null; @Nullable
/* 70 */     private Element match = null;
/*    */     private final Evaluator eval;
/*    */     
/*    */     FirstFinder(Evaluator eval) {
/* 74 */       this.eval = eval;
/*    */     }
/*    */     @Nullable
/*    */     Element find(Element root, Element start) {
/* 78 */       this.evalRoot = root;
/* 79 */       this.match = null;
/* 80 */       NodeTraversor.filter(this, (Node)start);
/* 81 */       return this.match;
/*    */     }
/*    */ 
/*    */     
/*    */     public NodeFilter.FilterResult head(Node node, int depth) {
/* 86 */       if (node instanceof Element) {
/* 87 */         Element el = (Element)node;
/* 88 */         if (this.eval.matches(this.evalRoot, el)) {
/* 89 */           this.match = el;
/* 90 */           return NodeFilter.FilterResult.STOP;
/*    */         } 
/*    */       } 
/* 93 */       return NodeFilter.FilterResult.CONTINUE;
/*    */     }
/*    */ 
/*    */     
/*    */     public NodeFilter.FilterResult tail(Node node, int depth) {
/* 98 */       return NodeFilter.FilterResult.CONTINUE;
/*    */     } }
/*    */ 
/*    */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\select\Collector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */