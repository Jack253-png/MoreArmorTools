/*     */ package org.jsoup.select;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.IdentityHashMap;
/*     */ import javax.annotation.Nullable;
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.nodes.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Selector
/*     */ {
/*     */   public static Elements select(String query, Element root) {
/*  94 */     Validate.notEmpty(query);
/*  95 */     return select(QueryParser.parse(query), root);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Elements select(Evaluator evaluator, Element root) {
/* 106 */     Validate.notNull(evaluator);
/* 107 */     Validate.notNull(root);
/* 108 */     return Collector.collect(evaluator, root);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Elements select(String query, Iterable<Element> roots) {
/* 119 */     Validate.notEmpty(query);
/* 120 */     Validate.notNull(roots);
/* 121 */     Evaluator evaluator = QueryParser.parse(query);
/* 122 */     Elements elements = new Elements();
/* 123 */     IdentityHashMap<Element, Boolean> seenElements = new IdentityHashMap<>();
/*     */ 
/*     */     
/* 126 */     for (Element root : roots) {
/* 127 */       Elements found = select(evaluator, root);
/* 128 */       for (Element el : found) {
/* 129 */         if (seenElements.put(el, Boolean.TRUE) == null) {
/* 130 */           elements.add(el);
/*     */         }
/*     */       } 
/*     */     } 
/* 134 */     return elements;
/*     */   }
/*     */ 
/*     */   
/*     */   static Elements filterOut(Collection<Element> elements, Collection<Element> outs) {
/* 139 */     Elements output = new Elements();
/* 140 */     for (Element el : elements) {
/* 141 */       boolean found = false;
/* 142 */       for (Element out : outs) {
/* 143 */         if (el.equals(out)) {
/* 144 */           found = true;
/*     */           break;
/*     */         } 
/*     */       } 
/* 148 */       if (!found)
/* 149 */         output.add(el); 
/*     */     } 
/* 151 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Element selectFirst(String cssQuery, Element root) {
/* 161 */     Validate.notEmpty(cssQuery);
/* 162 */     return Collector.findFirst(QueryParser.parse(cssQuery), root);
/*     */   }
/*     */   
/*     */   public static class SelectorParseException extends IllegalStateException {
/*     */     public SelectorParseException(String msg, Object... params) {
/* 167 */       super(String.format(msg, params));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\select\Selector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */