/*    */ package org.jsoup.select;
/*    */ 
/*    */ import org.jsoup.nodes.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface NodeFilter
/*    */ {
/*    */   FilterResult head(Node paramNode, int paramInt);
/*    */   
/*    */   FilterResult tail(Node paramNode, int paramInt);
/*    */   
/*    */   public enum FilterResult
/*    */   {
/* 32 */     CONTINUE,
/*    */     
/* 34 */     SKIP_CHILDREN,
/*    */     
/* 36 */     SKIP_ENTIRELY,
/*    */     
/* 38 */     REMOVE,
/*    */     
/* 40 */     STOP;
/*    */   }
/*    */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\select\NodeFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */