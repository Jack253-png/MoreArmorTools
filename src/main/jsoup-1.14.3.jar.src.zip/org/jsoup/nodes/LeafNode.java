/*     */ package org.jsoup.nodes;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.jsoup.helper.Validate;
/*     */ 
/*     */ abstract class LeafNode
/*     */   extends Node
/*     */ {
/*     */   Object value;
/*     */   
/*     */   protected final boolean hasAttributes() {
/*  12 */     return this.value instanceof Attributes;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Attributes attributes() {
/*  17 */     ensureAttributes();
/*  18 */     return (Attributes)this.value;
/*     */   }
/*     */   
/*     */   private void ensureAttributes() {
/*  22 */     if (!hasAttributes()) {
/*  23 */       Object coreValue = this.value;
/*  24 */       Attributes attributes = new Attributes();
/*  25 */       this.value = attributes;
/*  26 */       if (coreValue != null)
/*  27 */         attributes.put(nodeName(), (String)coreValue); 
/*     */     } 
/*     */   }
/*     */   
/*     */   String coreValue() {
/*  32 */     return attr(nodeName());
/*     */   }
/*     */   
/*     */   void coreValue(String value) {
/*  36 */     attr(nodeName(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String attr(String key) {
/*  41 */     Validate.notNull(key);
/*  42 */     if (!hasAttributes()) {
/*  43 */       return key.equals(nodeName()) ? (String)this.value : "";
/*     */     }
/*  45 */     return super.attr(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node attr(String key, String value) {
/*  50 */     if (!hasAttributes() && key.equals(nodeName())) {
/*  51 */       this.value = value;
/*     */     } else {
/*  53 */       ensureAttributes();
/*  54 */       super.attr(key, value);
/*     */     } 
/*  56 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAttr(String key) {
/*  61 */     ensureAttributes();
/*  62 */     return super.hasAttr(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node removeAttr(String key) {
/*  67 */     ensureAttributes();
/*  68 */     return super.removeAttr(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public String absUrl(String key) {
/*  73 */     ensureAttributes();
/*  74 */     return super.absUrl(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public String baseUri() {
/*  79 */     return hasParent() ? parent().baseUri() : "";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doSetBaseUri(String baseUri) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public int childNodeSize() {
/*  89 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public Node empty() {
/*  94 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected List<Node> ensureChildNodes() {
/*  99 */     return EmptyNodes;
/*     */   }
/*     */ 
/*     */   
/*     */   protected LeafNode doClone(Node parent) {
/* 104 */     LeafNode clone = (LeafNode)super.doClone(parent);
/*     */ 
/*     */     
/* 107 */     if (hasAttributes()) {
/* 108 */       clone.value = ((Attributes)this.value).clone();
/*     */     }
/* 110 */     return clone;
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\nodes\LeafNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */