/*    */ package org.jsoup.nodes;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.jsoup.UncheckedIOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CDataNode
/*    */   extends TextNode
/*    */ {
/*    */   public CDataNode(String text) {
/* 12 */     super(text);
/*    */   }
/*    */ 
/*    */   
/*    */   public String nodeName() {
/* 17 */     return "#cdata";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String text() {
/* 26 */     return getWholeText();
/*    */   }
/*    */ 
/*    */   
/*    */   void outerHtmlHead(Appendable accum, int depth, Document.OutputSettings out) throws IOException {
/* 31 */     accum
/* 32 */       .append("<![CDATA[")
/* 33 */       .append(getWholeText());
/*    */   }
/*    */ 
/*    */   
/*    */   void outerHtmlTail(Appendable accum, int depth, Document.OutputSettings out) {
/*    */     try {
/* 39 */       accum.append("]]>");
/* 40 */     } catch (IOException e) {
/* 41 */       throw new UncheckedIOException(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public CDataNode clone() {
/* 47 */     return (CDataNode)super.clone();
/*    */   }
/*    */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\nodes\CDataNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */