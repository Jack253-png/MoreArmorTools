/*    */ package org.jsoup.nodes;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataNode
/*    */   extends LeafNode
/*    */ {
/*    */   public DataNode(String data) {
/* 16 */     this.value = data;
/*    */   }
/*    */   
/*    */   public String nodeName() {
/* 20 */     return "#data";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getWholeData() {
/* 28 */     return coreValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DataNode setWholeData(String data) {
/* 37 */     coreValue(data);
/* 38 */     return this;
/*    */   }
/*    */   
/*    */   void outerHtmlHead(Appendable accum, int depth, Document.OutputSettings out) throws IOException {
/* 42 */     accum.append(getWholeData());
/*    */   }
/*    */ 
/*    */   
/*    */   void outerHtmlTail(Appendable accum, int depth, Document.OutputSettings out) {}
/*    */   
/*    */   public String toString() {
/* 49 */     return outerHtml();
/*    */   }
/*    */ 
/*    */   
/*    */   public DataNode clone() {
/* 54 */     return (DataNode)super.clone();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public static DataNode createFromEncoded(String encodedData, String baseUri) {
/* 66 */     String data = Entities.unescape(encodedData);
/* 67 */     return new DataNode(data);
/*    */   }
/*    */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\nodes\DataNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */