/*     */ package org.jsoup.nodes;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import org.jsoup.Connection;
/*     */ import org.jsoup.Jsoup;
/*     */ import org.jsoup.helper.DataUtil;
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.internal.StringUtil;
/*     */ import org.jsoup.parser.ParseSettings;
/*     */ import org.jsoup.parser.Parser;
/*     */ import org.jsoup.parser.Tag;
/*     */ import org.jsoup.select.Elements;
/*     */ import org.jsoup.select.Evaluator;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Document
/*     */   extends Element
/*     */ {
/*     */   @Nullable
/*     */   private Connection connection;
/*  26 */   private OutputSettings outputSettings = new OutputSettings();
/*     */   private Parser parser;
/*  28 */   private QuirksMode quirksMode = QuirksMode.noQuirks;
/*     */ 
/*     */   
/*     */   private final String location;
/*     */ 
/*     */   
/*     */   private boolean updateMetaCharset = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public Document(String baseUri) {
/*  39 */     super(Tag.valueOf("#root", ParseSettings.htmlDefault), baseUri);
/*  40 */     this.location = baseUri;
/*  41 */     this.parser = Parser.htmlParser();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document createShell(String baseUri) {
/*  50 */     Validate.notNull(baseUri);
/*     */     
/*  52 */     Document doc = new Document(baseUri);
/*  53 */     doc.parser = doc.parser();
/*  54 */     Element html = doc.appendElement("html");
/*  55 */     html.appendElement("head");
/*  56 */     html.appendElement("body");
/*     */     
/*  58 */     return doc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String location() {
/*  68 */     return this.location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection connection() {
/*  78 */     if (this.connection == null) {
/*  79 */       return Jsoup.newSession();
/*     */     }
/*  81 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DocumentType documentType() {
/*  89 */     for (Node node : this.childNodes) {
/*  90 */       if (node instanceof DocumentType)
/*  91 */         return (DocumentType)node; 
/*  92 */       if (!(node instanceof LeafNode))
/*     */         break; 
/*     */     } 
/*  95 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Element htmlEl() {
/* 104 */     for (Element el : childElementsList()) {
/* 105 */       if (el.normalName().equals("html"))
/* 106 */         return el; 
/*     */     } 
/* 108 */     return appendElement("html");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Element head() {
/* 120 */     Element html = htmlEl();
/* 121 */     for (Element el : html.childElementsList()) {
/* 122 */       if (el.normalName().equals("head"))
/* 123 */         return el; 
/*     */     } 
/* 125 */     return html.prependElement("head");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Element body() {
/* 138 */     Element html = htmlEl();
/* 139 */     for (Element el : html.childElementsList()) {
/* 140 */       if ("body".equals(el.normalName()) || "frameset".equals(el.normalName()))
/* 141 */         return el; 
/*     */     } 
/* 143 */     return html.appendElement("body");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String title() {
/* 152 */     Element titleEl = head().selectFirst(titleEval);
/* 153 */     return (titleEl != null) ? StringUtil.normaliseWhitespace(titleEl.text()).trim() : "";
/*     */   }
/* 155 */   private static final Evaluator titleEval = (Evaluator)new Evaluator.Tag("title");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void title(String title) {
/* 163 */     Validate.notNull(title);
/* 164 */     Element titleEl = head().selectFirst(titleEval);
/* 165 */     if (titleEl == null)
/* 166 */       titleEl = head().appendElement("title"); 
/* 167 */     titleEl.text(title);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Element createElement(String tagName) {
/* 176 */     return new Element(Tag.valueOf(tagName, ParseSettings.preserveCase), baseUri());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document normalise() {
/* 185 */     Element htmlEl = htmlEl();
/* 186 */     Element head = head();
/* 187 */     body();
/*     */ 
/*     */ 
/*     */     
/* 191 */     normaliseTextNodes(head);
/* 192 */     normaliseTextNodes(htmlEl);
/* 193 */     normaliseTextNodes(this);
/*     */     
/* 195 */     normaliseStructure("head", htmlEl);
/* 196 */     normaliseStructure("body", htmlEl);
/*     */     
/* 198 */     ensureMetaCharsetElement();
/*     */     
/* 200 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   private void normaliseTextNodes(Element element) {
/* 205 */     List<Node> toMove = new ArrayList<>();
/* 206 */     for (Node node : element.childNodes) {
/* 207 */       if (node instanceof TextNode) {
/* 208 */         TextNode tn = (TextNode)node;
/* 209 */         if (!tn.isBlank()) {
/* 210 */           toMove.add(tn);
/*     */         }
/*     */       } 
/*     */     } 
/* 214 */     for (int i = toMove.size() - 1; i >= 0; i--) {
/* 215 */       Node node = toMove.get(i);
/* 216 */       element.removeChild(node);
/* 217 */       body().prependChild(new TextNode(" "));
/* 218 */       body().prependChild(node);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void normaliseStructure(String tag, Element htmlEl) {
/* 224 */     Elements elements = getElementsByTag(tag);
/* 225 */     Element master = elements.first();
/* 226 */     if (elements.size() > 1) {
/* 227 */       List<Node> toMove = new ArrayList<>();
/* 228 */       for (int i = 1; i < elements.size(); i++) {
/* 229 */         Node dupe = (Node)elements.get(i);
/* 230 */         toMove.addAll(dupe.ensureChildNodes());
/* 231 */         dupe.remove();
/*     */       } 
/*     */       
/* 234 */       for (Node dupe : toMove) {
/* 235 */         master.appendChild(dupe);
/*     */       }
/*     */     } 
/* 238 */     if (master.parent() != null && !master.parent().equals(htmlEl)) {
/* 239 */       htmlEl.appendChild(master);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String outerHtml() {
/* 245 */     return html();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Element text(String text) {
/* 255 */     body().text(text);
/* 256 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String nodeName() {
/* 261 */     return "#document";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void charset(Charset charset) {
/* 289 */     updateMetaCharsetElement(true);
/* 290 */     this.outputSettings.charset(charset);
/* 291 */     ensureMetaCharsetElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset charset() {
/* 303 */     return this.outputSettings.charset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateMetaCharsetElement(boolean update) {
/* 320 */     this.updateMetaCharset = update;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean updateMetaCharsetElement() {
/* 332 */     return this.updateMetaCharset;
/*     */   }
/*     */ 
/*     */   
/*     */   public Document clone() {
/* 337 */     Document clone = (Document)super.clone();
/* 338 */     clone.outputSettings = this.outputSettings.clone();
/* 339 */     return clone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureMetaCharsetElement() {
/* 362 */     if (this.updateMetaCharset) {
/* 363 */       OutputSettings.Syntax syntax = outputSettings().syntax();
/*     */       
/* 365 */       if (syntax == OutputSettings.Syntax.html) {
/* 366 */         Element metaCharset = selectFirst("meta[charset]");
/* 367 */         if (metaCharset != null) {
/* 368 */           metaCharset.attr("charset", charset().displayName());
/*     */         } else {
/* 370 */           head().appendElement("meta").attr("charset", charset().displayName());
/*     */         } 
/* 372 */         select("meta[name=charset]").remove();
/* 373 */       } else if (syntax == OutputSettings.Syntax.xml) {
/* 374 */         Node node = ensureChildNodes().get(0);
/* 375 */         if (node instanceof XmlDeclaration) {
/* 376 */           XmlDeclaration decl = (XmlDeclaration)node;
/* 377 */           if (decl.name().equals("xml")) {
/* 378 */             decl.attr("encoding", charset().displayName());
/* 379 */             if (decl.hasAttr("version"))
/* 380 */               decl.attr("version", "1.0"); 
/*     */           } else {
/* 382 */             decl = new XmlDeclaration("xml", false);
/* 383 */             decl.attr("version", "1.0");
/* 384 */             decl.attr("encoding", charset().displayName());
/* 385 */             prependChild(decl);
/*     */           } 
/*     */         } else {
/* 388 */           XmlDeclaration decl = new XmlDeclaration("xml", false);
/* 389 */           decl.attr("version", "1.0");
/* 390 */           decl.attr("encoding", charset().displayName());
/* 391 */           prependChild(decl);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class OutputSettings
/*     */     implements Cloneable
/*     */   {
/*     */     public enum Syntax
/*     */     {
/* 405 */       html, xml;
/*     */     }
/* 407 */     private Entities.EscapeMode escapeMode = Entities.EscapeMode.base;
/* 408 */     private Charset charset = DataUtil.UTF_8;
/* 409 */     private final ThreadLocal<CharsetEncoder> encoderThreadLocal = new ThreadLocal<>();
/*     */     @Nullable
/*     */     Entities.CoreCharset coreCharset;
/*     */     private boolean prettyPrint = true;
/*     */     private boolean outline = false;
/* 414 */     private int indentAmount = 1;
/* 415 */     private Syntax syntax = Syntax.html;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Entities.EscapeMode escapeMode() {
/* 428 */       return this.escapeMode;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public OutputSettings escapeMode(Entities.EscapeMode escapeMode) {
/* 438 */       this.escapeMode = escapeMode;
/* 439 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Charset charset() {
/* 451 */       return this.charset;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public OutputSettings charset(Charset charset) {
/* 460 */       this.charset = charset;
/* 461 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public OutputSettings charset(String charset) {
/* 470 */       charset(Charset.forName(charset));
/* 471 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     CharsetEncoder prepareEncoder() {
/* 476 */       CharsetEncoder encoder = this.charset.newEncoder();
/* 477 */       this.encoderThreadLocal.set(encoder);
/* 478 */       this.coreCharset = Entities.CoreCharset.byName(encoder.charset().name());
/* 479 */       return encoder;
/*     */     }
/*     */     
/*     */     CharsetEncoder encoder() {
/* 483 */       CharsetEncoder encoder = this.encoderThreadLocal.get();
/* 484 */       return (encoder != null) ? encoder : prepareEncoder();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Syntax syntax() {
/* 492 */       return this.syntax;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public OutputSettings syntax(Syntax syntax) {
/* 502 */       this.syntax = syntax;
/* 503 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean prettyPrint() {
/* 512 */       return this.prettyPrint;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public OutputSettings prettyPrint(boolean pretty) {
/* 521 */       this.prettyPrint = pretty;
/* 522 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean outline() {
/* 531 */       return this.outline;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public OutputSettings outline(boolean outlineMode) {
/* 540 */       this.outline = outlineMode;
/* 541 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int indentAmount() {
/* 549 */       return this.indentAmount;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public OutputSettings indentAmount(int indentAmount) {
/* 558 */       Validate.isTrue((indentAmount >= 0));
/* 559 */       this.indentAmount = indentAmount;
/* 560 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public OutputSettings clone() {
/*     */       OutputSettings clone;
/*     */       try {
/* 567 */         clone = (OutputSettings)super.clone();
/* 568 */       } catch (CloneNotSupportedException e) {
/* 569 */         throw new RuntimeException(e);
/*     */       } 
/* 571 */       clone.charset(this.charset.name());
/* 572 */       clone.escapeMode = Entities.EscapeMode.valueOf(this.escapeMode.name());
/*     */       
/* 574 */       return clone;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum Syntax {
/*     */     html, xml;
/*     */   }
/*     */   
/*     */   public OutputSettings outputSettings() {
/* 583 */     return this.outputSettings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document outputSettings(OutputSettings outputSettings) {
/* 592 */     Validate.notNull(outputSettings);
/* 593 */     this.outputSettings = outputSettings;
/* 594 */     return this;
/*     */   }
/*     */   
/*     */   public enum QuirksMode {
/* 598 */     noQuirks, quirks, limitedQuirks;
/*     */   }
/*     */   
/*     */   public QuirksMode quirksMode() {
/* 602 */     return this.quirksMode;
/*     */   }
/*     */   
/*     */   public Document quirksMode(QuirksMode quirksMode) {
/* 606 */     this.quirksMode = quirksMode;
/* 607 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Parser parser() {
/* 615 */     return this.parser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document parser(Parser parser) {
/* 625 */     this.parser = parser;
/* 626 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document connection(Connection connection) {
/* 639 */     Validate.notNull(connection);
/* 640 */     this.connection = connection;
/* 641 */     return this;
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\nodes\Document.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */