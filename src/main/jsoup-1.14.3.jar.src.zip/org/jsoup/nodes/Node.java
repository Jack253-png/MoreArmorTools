/*     */ package org.jsoup.nodes;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import org.jsoup.SerializationException;
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.internal.StringUtil;
/*     */ import org.jsoup.select.Elements;
/*     */ import org.jsoup.select.NodeFilter;
/*     */ import org.jsoup.select.NodeTraversor;
/*     */ import org.jsoup.select.NodeVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Node
/*     */   implements Cloneable
/*     */ {
/*  24 */   static final List<Node> EmptyNodes = Collections.emptyList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String EmptyString = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Node parentNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int siblingIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasParent() {
/*  52 */     return (this.parentNode != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String attr(String attributeKey) {
/*  71 */     Validate.notNull(attributeKey);
/*  72 */     if (!hasAttributes()) {
/*  73 */       return "";
/*     */     }
/*  75 */     String val = attributes().getIgnoreCase(attributeKey);
/*  76 */     if (val.length() > 0)
/*  77 */       return val; 
/*  78 */     if (attributeKey.startsWith("abs:"))
/*  79 */       return absUrl(attributeKey.substring("abs:".length())); 
/*  80 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int attributesSize() {
/*  96 */     return hasAttributes() ? attributes().size() : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node attr(String attributeKey, String attributeValue) {
/* 107 */     attributeKey = NodeUtils.parser(this).settings().normalizeAttribute(attributeKey);
/* 108 */     attributes().putIgnoreCase(attributeKey, attributeValue);
/* 109 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAttr(String attributeKey) {
/* 118 */     Validate.notNull(attributeKey);
/* 119 */     if (!hasAttributes()) {
/* 120 */       return false;
/*     */     }
/* 122 */     if (attributeKey.startsWith("abs:")) {
/* 123 */       String key = attributeKey.substring("abs:".length());
/* 124 */       if (attributes().hasKeyIgnoreCase(key) && !absUrl(key).isEmpty())
/* 125 */         return true; 
/*     */     } 
/* 127 */     return attributes().hasKeyIgnoreCase(attributeKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node removeAttr(String attributeKey) {
/* 136 */     Validate.notNull(attributeKey);
/* 137 */     if (hasAttributes())
/* 138 */       attributes().removeIgnoreCase(attributeKey); 
/* 139 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node clearAttributes() {
/* 147 */     if (hasAttributes()) {
/* 148 */       Iterator<Attribute> it = attributes().iterator();
/* 149 */       while (it.hasNext()) {
/* 150 */         it.next();
/* 151 */         it.remove();
/*     */       } 
/*     */     } 
/* 154 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBaseUri(String baseUri) {
/* 177 */     Validate.notNull(baseUri);
/* 178 */     doSetBaseUri(baseUri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String absUrl(String attributeKey) {
/* 205 */     Validate.notEmpty(attributeKey);
/* 206 */     if (!hasAttributes() || !attributes().hasKeyIgnoreCase(attributeKey)) {
/* 207 */       return "";
/*     */     }
/* 209 */     return StringUtil.resolve(baseUri(), attributes().getIgnoreCase(attributeKey));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node childNode(int index) {
/* 220 */     return ensureChildNodes().get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Node> childNodes() {
/* 229 */     if (childNodeSize() == 0) {
/* 230 */       return EmptyNodes;
/*     */     }
/* 232 */     List<Node> children = ensureChildNodes();
/* 233 */     List<Node> rewrap = new ArrayList<>(children.size());
/* 234 */     rewrap.addAll(children);
/* 235 */     return Collections.unmodifiableList(rewrap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Node> childNodesCopy() {
/* 244 */     List<Node> nodes = ensureChildNodes();
/* 245 */     ArrayList<Node> children = new ArrayList<>(nodes.size());
/* 246 */     for (Node node : nodes) {
/* 247 */       children.add(node.clone());
/*     */     }
/* 249 */     return children;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Node[] childNodesAsArray() {
/* 259 */     return ensureChildNodes().<Node>toArray(new Node[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Node parent() {
/* 275 */     return this.parentNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Node parentNode() {
/* 283 */     return this.parentNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node root() {
/* 291 */     Node node = this;
/* 292 */     while (node.parentNode != null)
/* 293 */       node = node.parentNode; 
/* 294 */     return node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Document ownerDocument() {
/* 302 */     Node root = root();
/* 303 */     return (root instanceof Document) ? (Document)root : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() {
/* 310 */     Validate.notNull(this.parentNode);
/* 311 */     this.parentNode.removeChild(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node before(String html) {
/* 321 */     addSiblingHtml(this.siblingIndex, html);
/* 322 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node before(Node node) {
/* 332 */     Validate.notNull(node);
/* 333 */     Validate.notNull(this.parentNode);
/*     */     
/* 335 */     this.parentNode.addChildren(this.siblingIndex, new Node[] { node });
/* 336 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node after(String html) {
/* 346 */     addSiblingHtml(this.siblingIndex + 1, html);
/* 347 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node after(Node node) {
/* 357 */     Validate.notNull(node);
/* 358 */     Validate.notNull(this.parentNode);
/*     */     
/* 360 */     this.parentNode.addChildren(this.siblingIndex + 1, new Node[] { node });
/* 361 */     return this;
/*     */   }
/*     */   
/*     */   private void addSiblingHtml(int index, String html) {
/* 365 */     Validate.notNull(html);
/* 366 */     Validate.notNull(this.parentNode);
/*     */     
/* 368 */     Element context = (parent() instanceof Element) ? (Element)parent() : null;
/* 369 */     List<Node> nodes = NodeUtils.parser(this).parseFragmentInput(html, context, baseUri());
/* 370 */     this.parentNode.addChildren(index, nodes.<Node>toArray(new Node[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node wrap(String html) {
/* 381 */     Validate.notEmpty(html);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 387 */     Element context = (this.parentNode != null && this.parentNode instanceof Element) ? (Element)this.parentNode : ((this instanceof Element) ? (Element)this : null);
/* 388 */     List<Node> wrapChildren = NodeUtils.parser(this).parseFragmentInput(html, context, baseUri());
/* 389 */     Node wrapNode = wrapChildren.get(0);
/* 390 */     if (!(wrapNode instanceof Element)) {
/* 391 */       return this;
/*     */     }
/* 393 */     Element wrap = (Element)wrapNode;
/* 394 */     Element deepest = getDeepChild(wrap);
/* 395 */     if (this.parentNode != null)
/* 396 */       this.parentNode.replaceChild(this, wrap); 
/* 397 */     deepest.addChildren(new Node[] { this });
/*     */ 
/*     */     
/* 400 */     if (wrapChildren.size() > 0)
/*     */     {
/* 402 */       for (int i = 0; i < wrapChildren.size(); i++) {
/* 403 */         Node remainder = wrapChildren.get(i);
/*     */         
/* 405 */         if (wrap != remainder) {
/*     */ 
/*     */           
/* 408 */           if (remainder.parentNode != null)
/* 409 */             remainder.parentNode.removeChild(remainder); 
/* 410 */           wrap.after(remainder);
/*     */         } 
/*     */       }  } 
/* 413 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Node unwrap() {
/* 432 */     Validate.notNull(this.parentNode);
/* 433 */     List<Node> childNodes = ensureChildNodes();
/* 434 */     Node firstChild = (childNodes.size() > 0) ? childNodes.get(0) : null;
/* 435 */     this.parentNode.addChildren(this.siblingIndex, childNodesAsArray());
/* 436 */     remove();
/*     */     
/* 438 */     return firstChild;
/*     */   }
/*     */   
/*     */   private Element getDeepChild(Element el) {
/* 442 */     Elements<Element> elements = el.children();
/* 443 */     if (elements.size() > 0) {
/* 444 */       return getDeepChild(elements.get(0));
/*     */     }
/* 446 */     return el;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void nodelistChanged() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceWith(Node in) {
/* 458 */     Validate.notNull(in);
/* 459 */     Validate.notNull(this.parentNode);
/* 460 */     this.parentNode.replaceChild(this, in);
/*     */   }
/*     */   
/*     */   protected void setParentNode(Node parentNode) {
/* 464 */     Validate.notNull(parentNode);
/* 465 */     if (this.parentNode != null)
/* 466 */       this.parentNode.removeChild(this); 
/* 467 */     this.parentNode = parentNode;
/*     */   }
/*     */   
/*     */   protected void replaceChild(Node out, Node in) {
/* 471 */     Validate.isTrue((out.parentNode == this));
/* 472 */     Validate.notNull(in);
/* 473 */     if (in.parentNode != null) {
/* 474 */       in.parentNode.removeChild(in);
/*     */     }
/* 476 */     int index = out.siblingIndex;
/* 477 */     ensureChildNodes().set(index, in);
/* 478 */     in.parentNode = this;
/* 479 */     in.setSiblingIndex(index);
/* 480 */     out.parentNode = null;
/*     */   }
/*     */   
/*     */   protected void removeChild(Node out) {
/* 484 */     Validate.isTrue((out.parentNode == this));
/* 485 */     int index = out.siblingIndex;
/* 486 */     ensureChildNodes().remove(index);
/* 487 */     reindexChildren(index);
/* 488 */     out.parentNode = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addChildren(Node... children) {
/* 493 */     List<Node> nodes = ensureChildNodes();
/*     */     
/* 495 */     for (Node child : children) {
/* 496 */       reparentChild(child);
/* 497 */       nodes.add(child);
/* 498 */       child.setSiblingIndex(nodes.size() - 1);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void addChildren(int index, Node... children) {
/* 503 */     Validate.notNull(children);
/* 504 */     if (children.length == 0) {
/*     */       return;
/*     */     }
/* 507 */     List<Node> nodes = ensureChildNodes();
/*     */ 
/*     */     
/* 510 */     Node firstParent = children[0].parent();
/* 511 */     if (firstParent != null && firstParent.childNodeSize() == children.length) {
/* 512 */       boolean sameList = true;
/* 513 */       List<Node> firstParentNodes = firstParent.ensureChildNodes();
/*     */       
/* 515 */       int i = children.length;
/* 516 */       while (i-- > 0) {
/* 517 */         if (children[i] != firstParentNodes.get(i)) {
/* 518 */           sameList = false;
/*     */           break;
/*     */         } 
/*     */       } 
/* 522 */       if (sameList) {
/* 523 */         boolean wasEmpty = (childNodeSize() == 0);
/* 524 */         firstParent.empty();
/* 525 */         nodes.addAll(index, Arrays.asList(children));
/* 526 */         i = children.length;
/* 527 */         while (i-- > 0) {
/* 528 */           (children[i]).parentNode = this;
/*     */         }
/* 530 */         if (!wasEmpty || (children[0]).siblingIndex != 0) {
/* 531 */           reindexChildren(index);
/*     */         }
/*     */         return;
/*     */       } 
/*     */     } 
/* 536 */     Validate.noNullElements((Object[])children);
/* 537 */     for (Node child : children) {
/* 538 */       reparentChild(child);
/*     */     }
/* 540 */     nodes.addAll(index, Arrays.asList(children));
/* 541 */     reindexChildren(index);
/*     */   }
/*     */   
/*     */   protected void reparentChild(Node child) {
/* 545 */     child.setParentNode(this);
/*     */   }
/*     */   
/*     */   private void reindexChildren(int start) {
/* 549 */     if (childNodeSize() == 0)
/* 550 */       return;  List<Node> childNodes = ensureChildNodes();
/*     */     
/* 552 */     for (int i = start; i < childNodes.size(); i++) {
/* 553 */       ((Node)childNodes.get(i)).setSiblingIndex(i);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Node> siblingNodes() {
/* 563 */     if (this.parentNode == null) {
/* 564 */       return Collections.emptyList();
/*     */     }
/* 566 */     List<Node> nodes = this.parentNode.ensureChildNodes();
/* 567 */     List<Node> siblings = new ArrayList<>(nodes.size() - 1);
/* 568 */     for (Node node : nodes) {
/* 569 */       if (node != this)
/* 570 */         siblings.add(node); 
/* 571 */     }  return siblings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Node nextSibling() {
/* 579 */     if (this.parentNode == null) {
/* 580 */       return null;
/*     */     }
/* 582 */     List<Node> siblings = this.parentNode.ensureChildNodes();
/* 583 */     int index = this.siblingIndex + 1;
/* 584 */     if (siblings.size() > index) {
/* 585 */       return siblings.get(index);
/*     */     }
/* 587 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Node previousSibling() {
/* 595 */     if (this.parentNode == null) {
/* 596 */       return null;
/*     */     }
/* 598 */     if (this.siblingIndex > 0) {
/* 599 */       return this.parentNode.ensureChildNodes().get(this.siblingIndex - 1);
/*     */     }
/* 601 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int siblingIndex() {
/* 611 */     return this.siblingIndex;
/*     */   }
/*     */   
/*     */   protected void setSiblingIndex(int siblingIndex) {
/* 615 */     this.siblingIndex = siblingIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node traverse(NodeVisitor nodeVisitor) {
/* 624 */     Validate.notNull(nodeVisitor);
/* 625 */     NodeTraversor.traverse(nodeVisitor, this);
/* 626 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node filter(NodeFilter nodeFilter) {
/* 635 */     Validate.notNull(nodeFilter);
/* 636 */     NodeTraversor.filter(nodeFilter, this);
/* 637 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String outerHtml() {
/* 647 */     StringBuilder accum = StringUtil.borrowBuilder();
/* 648 */     outerHtml(accum);
/* 649 */     return StringUtil.releaseBuilder(accum);
/*     */   }
/*     */   
/*     */   protected void outerHtml(Appendable accum) {
/* 653 */     NodeTraversor.traverse(new OuterHtmlVisitor(accum, NodeUtils.outputSettings(this)), this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Appendable> T html(T appendable) {
/* 672 */     outerHtml((Appendable)appendable);
/* 673 */     return appendable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 682 */     return outerHtml();
/*     */   }
/*     */   
/*     */   protected void indent(Appendable accum, int depth, Document.OutputSettings out) throws IOException {
/* 686 */     accum.append('\n').append(StringUtil.padding(depth * out.indentAmount()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/* 699 */     return (this == o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 710 */     return super.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasSameValue(@Nullable Object o) {
/* 720 */     if (this == o) return true; 
/* 721 */     if (o == null || getClass() != o.getClass()) return false;
/*     */     
/* 723 */     return outerHtml().equals(((Node)o).outerHtml());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node clone() {
/* 738 */     Node thisClone = doClone(null);
/*     */ 
/*     */     
/* 741 */     LinkedList<Node> nodesToProcess = new LinkedList<>();
/* 742 */     nodesToProcess.add(thisClone);
/*     */     
/* 744 */     while (!nodesToProcess.isEmpty()) {
/* 745 */       Node currParent = nodesToProcess.remove();
/*     */       
/* 747 */       int size = currParent.childNodeSize();
/* 748 */       for (int i = 0; i < size; i++) {
/* 749 */         List<Node> childNodes = currParent.ensureChildNodes();
/* 750 */         Node childClone = ((Node)childNodes.get(i)).doClone(currParent);
/* 751 */         childNodes.set(i, childClone);
/* 752 */         nodesToProcess.add(childClone);
/*     */       } 
/*     */     } 
/*     */     
/* 756 */     return thisClone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node shallowClone() {
/* 766 */     return doClone(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Node doClone(@Nullable Node parent) {
/*     */     Node clone;
/*     */     try {
/* 777 */       clone = (Node)super.clone();
/* 778 */     } catch (CloneNotSupportedException e) {
/* 779 */       throw new RuntimeException(e);
/*     */     } 
/*     */     
/* 782 */     clone.parentNode = parent;
/* 783 */     clone.siblingIndex = (parent == null) ? 0 : this.siblingIndex;
/*     */     
/* 785 */     return clone;
/*     */   } public abstract String nodeName(); protected abstract boolean hasAttributes(); public abstract Attributes attributes(); public abstract String baseUri(); protected abstract void doSetBaseUri(String paramString); protected abstract List<Node> ensureChildNodes();
/*     */   public abstract int childNodeSize();
/*     */   public abstract Node empty();
/*     */   abstract void outerHtmlHead(Appendable paramAppendable, int paramInt, Document.OutputSettings paramOutputSettings) throws IOException;
/*     */   abstract void outerHtmlTail(Appendable paramAppendable, int paramInt, Document.OutputSettings paramOutputSettings) throws IOException;
/*     */   private static class OuterHtmlVisitor implements NodeVisitor { private final Appendable accum;
/*     */     OuterHtmlVisitor(Appendable accum, Document.OutputSettings out) {
/* 793 */       this.accum = accum;
/* 794 */       this.out = out;
/* 795 */       out.prepareEncoder();
/*     */     }
/*     */     private final Document.OutputSettings out;
/*     */     public void head(Node node, int depth) {
/*     */       try {
/* 800 */         node.outerHtmlHead(this.accum, depth, this.out);
/* 801 */       } catch (IOException exception) {
/* 802 */         throw new SerializationException(exception);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void tail(Node node, int depth) {
/* 807 */       if (!node.nodeName().equals("#text"))
/*     */         try {
/* 809 */           node.outerHtmlTail(this.accum, depth, this.out);
/* 810 */         } catch (IOException exception) {
/* 811 */           throw new SerializationException(exception);
/*     */         }  
/*     */     } }
/*     */ 
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\nodes\Node.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */