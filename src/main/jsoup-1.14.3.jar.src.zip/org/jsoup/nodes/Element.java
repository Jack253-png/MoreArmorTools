/*      */ package org.jsoup.nodes;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.regex.Pattern;
/*      */ import java.util.regex.PatternSyntaxException;
/*      */ import javax.annotation.Nullable;
/*      */ import org.jsoup.helper.ChangeNotifyingArrayList;
/*      */ import org.jsoup.helper.Validate;
/*      */ import org.jsoup.internal.NonnullByDefault;
/*      */ import org.jsoup.internal.Normalizer;
/*      */ import org.jsoup.internal.StringUtil;
/*      */ import org.jsoup.parser.Tag;
/*      */ import org.jsoup.select.Collector;
/*      */ import org.jsoup.select.Elements;
/*      */ import org.jsoup.select.Evaluator;
/*      */ import org.jsoup.select.NodeFilter;
/*      */ import org.jsoup.select.NodeTraversor;
/*      */ import org.jsoup.select.NodeVisitor;
/*      */ import org.jsoup.select.QueryParser;
/*      */ import org.jsoup.select.Selector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @NonnullByDefault
/*      */ public class Element
/*      */   extends Node
/*      */ {
/*   44 */   private static final List<Element> EmptyChildren = Collections.emptyList();
/*   45 */   private static final Pattern ClassSplit = Pattern.compile("\\s+");
/*   46 */   private static final String BaseUriKey = Attributes.internalKey("baseUri");
/*      */   
/*      */   private Tag tag;
/*      */   
/*      */   @Nullable
/*      */   private WeakReference<List<Element>> shadowChildrenRef;
/*      */   List<Node> childNodes;
/*      */   @Nullable
/*      */   private Attributes attributes;
/*      */   
/*      */   public Element(String tag) {
/*   57 */     this(Tag.valueOf(tag), "", (Attributes)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element(Tag tag, @Nullable String baseUri, @Nullable Attributes attributes) {
/*   70 */     Validate.notNull(tag);
/*   71 */     this.childNodes = EmptyNodes;
/*   72 */     this.attributes = attributes;
/*   73 */     this.tag = tag;
/*   74 */     if (baseUri != null) {
/*   75 */       setBaseUri(baseUri);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element(Tag tag, @Nullable String baseUri) {
/*   86 */     this(tag, baseUri, (Attributes)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean hasChildNodes() {
/*   93 */     return (this.childNodes != EmptyNodes);
/*      */   }
/*      */   
/*      */   protected List<Node> ensureChildNodes() {
/*   97 */     if (this.childNodes == EmptyNodes) {
/*   98 */       this.childNodes = (List<Node>)new NodeList(this, 4);
/*      */     }
/*  100 */     return this.childNodes;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean hasAttributes() {
/*  105 */     return (this.attributes != null);
/*      */   }
/*      */ 
/*      */   
/*      */   public Attributes attributes() {
/*  110 */     if (this.attributes == null)
/*  111 */       this.attributes = new Attributes(); 
/*  112 */     return this.attributes;
/*      */   }
/*      */ 
/*      */   
/*      */   public String baseUri() {
/*  117 */     return searchUpForAttribute(this, BaseUriKey);
/*      */   }
/*      */   
/*      */   private static String searchUpForAttribute(Element start, String key) {
/*  121 */     Element el = start;
/*  122 */     while (el != null) {
/*  123 */       if (el.attributes != null && el.attributes.hasKey(key))
/*  124 */         return el.attributes.get(key); 
/*  125 */       el = el.parent();
/*      */     } 
/*  127 */     return "";
/*      */   }
/*      */ 
/*      */   
/*      */   protected void doSetBaseUri(String baseUri) {
/*  132 */     attributes().put(BaseUriKey, baseUri);
/*      */   }
/*      */ 
/*      */   
/*      */   public int childNodeSize() {
/*  137 */     return this.childNodes.size();
/*      */   }
/*      */ 
/*      */   
/*      */   public String nodeName() {
/*  142 */     return this.tag.getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String tagName() {
/*  152 */     return this.tag.getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String normalName() {
/*  162 */     return this.tag.normalName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element tagName(String tagName) {
/*  174 */     Validate.notEmpty(tagName, "Tag name must not be empty.");
/*  175 */     this.tag = Tag.valueOf(tagName, NodeUtils.parser(this).settings());
/*  176 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Tag tag() {
/*  185 */     return this.tag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBlock() {
/*  195 */     return this.tag.isBlock();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String id() {
/*  204 */     return (this.attributes != null) ? this.attributes.getIgnoreCase("id") : "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element id(String id) {
/*  213 */     Validate.notNull(id);
/*  214 */     attr("id", id);
/*  215 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element attr(String attributeKey, String attributeValue) {
/*  225 */     super.attr(attributeKey, attributeValue);
/*  226 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element attr(String attributeKey, boolean attributeValue) {
/*  240 */     attributes().put(attributeKey, attributeValue);
/*  241 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, String> dataset() {
/*  258 */     return attributes().dataset();
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public final Element parent() {
/*  263 */     return (Element)this.parentNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements parents() {
/*  271 */     Elements parents = new Elements();
/*  272 */     accumulateParents(this, parents);
/*  273 */     return parents;
/*      */   }
/*      */   
/*      */   private static void accumulateParents(Element el, Elements parents) {
/*  277 */     Element parent = el.parent();
/*  278 */     if (parent != null && !parent.tagName().equals("#root")) {
/*  279 */       parents.add(parent);
/*  280 */       accumulateParents(parent, parents);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element child(int index) {
/*  296 */     return childElementsList().get(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int childrenSize() {
/*  311 */     return childElementsList().size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements children() {
/*  323 */     return new Elements(childElementsList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   List<Element> childElementsList() {
/*  332 */     if (childNodeSize() == 0) {
/*  333 */       return EmptyChildren;
/*      */     }
/*      */     List<Element> children;
/*  336 */     if (this.shadowChildrenRef == null || (children = this.shadowChildrenRef.get()) == null) {
/*  337 */       int size = this.childNodes.size();
/*  338 */       children = new ArrayList<>(size);
/*      */       
/*  340 */       for (int i = 0; i < size; i++) {
/*  341 */         Node node = this.childNodes.get(i);
/*  342 */         if (node instanceof Element)
/*  343 */           children.add((Element)node); 
/*      */       } 
/*  345 */       this.shadowChildrenRef = new WeakReference<>(children);
/*      */     } 
/*  347 */     return children;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void nodelistChanged() {
/*  355 */     super.nodelistChanged();
/*  356 */     this.shadowChildrenRef = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<TextNode> textNodes() {
/*  376 */     List<TextNode> textNodes = new ArrayList<>();
/*  377 */     for (Node node : this.childNodes) {
/*  378 */       if (node instanceof TextNode)
/*  379 */         textNodes.add((TextNode)node); 
/*      */     } 
/*  381 */     return Collections.unmodifiableList(textNodes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<DataNode> dataNodes() {
/*  394 */     List<DataNode> dataNodes = new ArrayList<>();
/*  395 */     for (Node node : this.childNodes) {
/*  396 */       if (node instanceof DataNode)
/*  397 */         dataNodes.add((DataNode)node); 
/*      */     } 
/*  399 */     return Collections.unmodifiableList(dataNodes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements select(String cssQuery) {
/*  421 */     return Selector.select(cssQuery, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements select(Evaluator evaluator) {
/*  432 */     return Selector.select(evaluator, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Element selectFirst(String cssQuery) {
/*  445 */     return Selector.selectFirst(cssQuery, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Element selectFirst(Evaluator evaluator) {
/*  457 */     return Collector.findFirst(evaluator, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean is(String cssQuery) {
/*  468 */     return is(QueryParser.parse(cssQuery));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean is(Evaluator evaluator) {
/*  477 */     return evaluator.matches(root(), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Element closest(String cssQuery) {
/*  488 */     return closest(QueryParser.parse(cssQuery));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Element closest(Evaluator evaluator) {
/*  499 */     Validate.notNull(evaluator);
/*  500 */     Element el = this;
/*  501 */     Element root = root();
/*      */     while (true) {
/*  503 */       if (evaluator.matches(root, el))
/*  504 */         return el; 
/*  505 */       el = el.parent();
/*  506 */       if (el == null) {
/*  507 */         return null;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements selectXpath(String xpath) {
/*  529 */     return new Elements(NodeUtils.selectXpath(xpath, this, Element.class));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends Node> List<T> selectXpath(String xpath, Class<T> nodeType) {
/*  546 */     return NodeUtils.selectXpath(xpath, this, nodeType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element appendChild(Node child) {
/*  558 */     Validate.notNull(child);
/*      */ 
/*      */     
/*  561 */     reparentChild(child);
/*  562 */     ensureChildNodes();
/*  563 */     this.childNodes.add(child);
/*  564 */     child.setSiblingIndex(this.childNodes.size() - 1);
/*  565 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element appendChildren(Collection<? extends Node> children) {
/*  576 */     insertChildren(-1, children);
/*  577 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element appendTo(Element parent) {
/*  587 */     Validate.notNull(parent);
/*  588 */     parent.appendChild(this);
/*  589 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element prependChild(Node child) {
/*  599 */     Validate.notNull(child);
/*      */     
/*  601 */     addChildren(0, new Node[] { child });
/*  602 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element prependChildren(Collection<? extends Node> children) {
/*  613 */     insertChildren(0, children);
/*  614 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element insertChildren(int index, Collection<? extends Node> children) {
/*  628 */     Validate.notNull(children, "Children collection to be inserted must not be null.");
/*  629 */     int currentSize = childNodeSize();
/*  630 */     if (index < 0) index += currentSize + 1; 
/*  631 */     Validate.isTrue((index >= 0 && index <= currentSize), "Insert position out of bounds.");
/*      */     
/*  633 */     ArrayList<Node> nodes = new ArrayList<>(children);
/*  634 */     Node[] nodeArray = nodes.<Node>toArray(new Node[0]);
/*  635 */     addChildren(index, nodeArray);
/*  636 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element insertChildren(int index, Node... children) {
/*  649 */     Validate.notNull(children, "Children collection to be inserted must not be null.");
/*  650 */     int currentSize = childNodeSize();
/*  651 */     if (index < 0) index += currentSize + 1; 
/*  652 */     Validate.isTrue((index >= 0 && index <= currentSize), "Insert position out of bounds.");
/*      */     
/*  654 */     addChildren(index, children);
/*  655 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element appendElement(String tagName) {
/*  666 */     Element child = new Element(Tag.valueOf(tagName, NodeUtils.parser(this).settings()), baseUri());
/*  667 */     appendChild(child);
/*  668 */     return child;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element prependElement(String tagName) {
/*  679 */     Element child = new Element(Tag.valueOf(tagName, NodeUtils.parser(this).settings()), baseUri());
/*  680 */     prependChild(child);
/*  681 */     return child;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element appendText(String text) {
/*  691 */     Validate.notNull(text);
/*  692 */     TextNode node = new TextNode(text);
/*  693 */     appendChild(node);
/*  694 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element prependText(String text) {
/*  704 */     Validate.notNull(text);
/*  705 */     TextNode node = new TextNode(text);
/*  706 */     prependChild(node);
/*  707 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element append(String html) {
/*  717 */     Validate.notNull(html);
/*  718 */     List<Node> nodes = NodeUtils.parser(this).parseFragmentInput(html, this, baseUri());
/*  719 */     addChildren(nodes.<Node>toArray(new Node[0]));
/*  720 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element prepend(String html) {
/*  730 */     Validate.notNull(html);
/*  731 */     List<Node> nodes = NodeUtils.parser(this).parseFragmentInput(html, this, baseUri());
/*  732 */     addChildren(0, nodes.<Node>toArray(new Node[0]));
/*  733 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element before(String html) {
/*  745 */     return (Element)super.before(html);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element before(Node node) {
/*  756 */     return (Element)super.before(node);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element after(String html) {
/*  768 */     return (Element)super.after(html);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element after(Node node) {
/*  779 */     return (Element)super.after(node);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element empty() {
/*  788 */     this.childNodes.clear();
/*  789 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element wrap(String html) {
/*  800 */     return (Element)super.wrap(html);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String cssSelector() {
/*  814 */     if (id().length() > 0) {
/*      */       
/*  816 */       String idSel = "#" + id();
/*  817 */       Document doc = ownerDocument();
/*  818 */       if (doc != null) {
/*  819 */         Elements els = doc.select(idSel);
/*  820 */         if (els.size() == 1 && els.get(0) == this)
/*  821 */           return idSel; 
/*      */       } else {
/*  823 */         return idSel;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  828 */     String tagName = tagName().replace(':', '|');
/*  829 */     StringBuilder selector = new StringBuilder(tagName);
/*  830 */     String classes = StringUtil.join(classNames(), ".");
/*  831 */     if (classes.length() > 0) {
/*  832 */       selector.append('.').append(classes);
/*      */     }
/*  834 */     if (parent() == null || parent() instanceof Document) {
/*  835 */       return selector.toString();
/*      */     }
/*  837 */     selector.insert(0, " > ");
/*  838 */     if (parent().select(selector.toString()).size() > 1)
/*  839 */       selector.append(String.format(":nth-child(%d)", new Object[] {
/*  840 */               Integer.valueOf(elementSiblingIndex() + 1)
/*      */             })); 
/*  842 */     return parent().cssSelector() + selector.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements siblingElements() {
/*  851 */     if (this.parentNode == null) {
/*  852 */       return new Elements(0);
/*      */     }
/*  854 */     List<Element> elements = parent().childElementsList();
/*  855 */     Elements siblings = new Elements(elements.size() - 1);
/*  856 */     for (Element el : elements) {
/*  857 */       if (el != this)
/*  858 */         siblings.add(el); 
/*  859 */     }  return siblings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Element nextElementSibling() {
/*  872 */     if (this.parentNode == null) return null; 
/*  873 */     List<Element> siblings = parent().childElementsList();
/*  874 */     int index = indexInList(this, siblings);
/*  875 */     if (siblings.size() > index + 1) {
/*  876 */       return siblings.get(index + 1);
/*      */     }
/*  878 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements nextElementSiblings() {
/*  887 */     return nextElementSiblings(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Element previousElementSibling() {
/*  896 */     if (this.parentNode == null) return null; 
/*  897 */     List<Element> siblings = parent().childElementsList();
/*  898 */     int index = indexInList(this, siblings);
/*  899 */     if (index > 0) {
/*  900 */       return siblings.get(index - 1);
/*      */     }
/*  902 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements previousElementSiblings() {
/*  911 */     return nextElementSiblings(false);
/*      */   }
/*      */   
/*      */   private Elements nextElementSiblings(boolean next) {
/*  915 */     Elements els = new Elements();
/*  916 */     if (this.parentNode == null)
/*  917 */       return els; 
/*  918 */     els.add(this);
/*  919 */     return next ? els.nextAll() : els.prevAll();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element firstElementSibling() {
/*  927 */     if (parent() != null) {
/*  928 */       List<Element> siblings = parent().childElementsList();
/*  929 */       return (siblings.size() > 1) ? siblings.get(0) : this;
/*      */     } 
/*  931 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int elementSiblingIndex() {
/*  940 */     if (parent() == null) return 0; 
/*  941 */     return indexInList(this, parent().childElementsList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element lastElementSibling() {
/*  949 */     if (parent() != null) {
/*  950 */       List<Element> siblings = parent().childElementsList();
/*  951 */       return (siblings.size() > 1) ? siblings.get(siblings.size() - 1) : this;
/*      */     } 
/*  953 */     return this;
/*      */   }
/*      */   
/*      */   private static <E extends Element> int indexInList(Element search, List<E> elements) {
/*  957 */     int size = elements.size();
/*  958 */     for (int i = 0; i < size; i++) {
/*  959 */       if (elements.get(i) == search)
/*  960 */         return i; 
/*      */     } 
/*  962 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsByTag(String tagName) {
/*  973 */     Validate.notEmpty(tagName);
/*  974 */     tagName = Normalizer.normalize(tagName);
/*      */     
/*  976 */     return Collector.collect((Evaluator)new Evaluator.Tag(tagName), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Element getElementById(String id) {
/*  989 */     Validate.notEmpty(id);
/*      */     
/*  991 */     Elements elements = Collector.collect((Evaluator)new Evaluator.Id(id), this);
/*  992 */     if (elements.size() > 0) {
/*  993 */       return (Element)elements.get(0);
/*      */     }
/*  995 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsByClass(String className) {
/* 1010 */     Validate.notEmpty(className);
/*      */     
/* 1012 */     return Collector.collect((Evaluator)new Evaluator.Class(className), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsByAttribute(String key) {
/* 1022 */     Validate.notEmpty(key);
/* 1023 */     key = key.trim();
/*      */     
/* 1025 */     return Collector.collect((Evaluator)new Evaluator.Attribute(key), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsByAttributeStarting(String keyPrefix) {
/* 1035 */     Validate.notEmpty(keyPrefix);
/* 1036 */     keyPrefix = keyPrefix.trim();
/*      */     
/* 1038 */     return Collector.collect((Evaluator)new Evaluator.AttributeStarting(keyPrefix), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsByAttributeValue(String key, String value) {
/* 1049 */     return Collector.collect((Evaluator)new Evaluator.AttributeWithValue(key, value), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsByAttributeValueNot(String key, String value) {
/* 1060 */     return Collector.collect((Evaluator)new Evaluator.AttributeWithValueNot(key, value), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsByAttributeValueStarting(String key, String valuePrefix) {
/* 1071 */     return Collector.collect((Evaluator)new Evaluator.AttributeWithValueStarting(key, valuePrefix), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsByAttributeValueEnding(String key, String valueSuffix) {
/* 1082 */     return Collector.collect((Evaluator)new Evaluator.AttributeWithValueEnding(key, valueSuffix), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsByAttributeValueContaining(String key, String match) {
/* 1093 */     return Collector.collect((Evaluator)new Evaluator.AttributeWithValueContaining(key, match), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsByAttributeValueMatching(String key, Pattern pattern) {
/* 1103 */     return Collector.collect((Evaluator)new Evaluator.AttributeWithValueMatching(key, pattern), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsByAttributeValueMatching(String key, String regex) {
/*      */     Pattern pattern;
/*      */     try {
/* 1116 */       pattern = Pattern.compile(regex);
/* 1117 */     } catch (PatternSyntaxException e) {
/* 1118 */       throw new IllegalArgumentException("Pattern syntax error: " + regex, e);
/*      */     } 
/* 1120 */     return getElementsByAttributeValueMatching(key, pattern);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsByIndexLessThan(int index) {
/* 1129 */     return Collector.collect((Evaluator)new Evaluator.IndexLessThan(index), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsByIndexGreaterThan(int index) {
/* 1138 */     return Collector.collect((Evaluator)new Evaluator.IndexGreaterThan(index), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsByIndexEquals(int index) {
/* 1147 */     return Collector.collect((Evaluator)new Evaluator.IndexEquals(index), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsContainingText(String searchText) {
/* 1158 */     return Collector.collect((Evaluator)new Evaluator.ContainsText(searchText), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsContainingOwnText(String searchText) {
/* 1169 */     return Collector.collect((Evaluator)new Evaluator.ContainsOwnText(searchText), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsMatchingText(Pattern pattern) {
/* 1179 */     return Collector.collect((Evaluator)new Evaluator.Matches(pattern), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsMatchingText(String regex) {
/*      */     Pattern pattern;
/*      */     try {
/* 1191 */       pattern = Pattern.compile(regex);
/* 1192 */     } catch (PatternSyntaxException e) {
/* 1193 */       throw new IllegalArgumentException("Pattern syntax error: " + regex, e);
/*      */     } 
/* 1195 */     return getElementsMatchingText(pattern);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsMatchingOwnText(Pattern pattern) {
/* 1205 */     return Collector.collect((Evaluator)new Evaluator.MatchesOwn(pattern), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getElementsMatchingOwnText(String regex) {
/*      */     Pattern pattern;
/*      */     try {
/* 1217 */       pattern = Pattern.compile(regex);
/* 1218 */     } catch (PatternSyntaxException e) {
/* 1219 */       throw new IllegalArgumentException("Pattern syntax error: " + regex, e);
/*      */     } 
/* 1221 */     return getElementsMatchingOwnText(pattern);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Elements getAllElements() {
/* 1230 */     return Collector.collect((Evaluator)new Evaluator.AllElements(), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String text() {
/* 1250 */     final StringBuilder accum = StringUtil.borrowBuilder();
/* 1251 */     NodeTraversor.traverse(new NodeVisitor() {
/*      */           public void head(Node node, int depth) {
/* 1253 */             if (node instanceof TextNode) {
/* 1254 */               TextNode textNode = (TextNode)node;
/* 1255 */               Element.appendNormalisedText(accum, textNode);
/* 1256 */             } else if (node instanceof Element) {
/* 1257 */               Element element = (Element)node;
/* 1258 */               if (accum.length() > 0 && (element
/* 1259 */                 .isBlock() || element.tag.normalName().equals("br")) && 
/* 1260 */                 !TextNode.lastCharIsWhitespace(accum)) {
/* 1261 */                 accum.append(' ');
/*      */               }
/*      */             } 
/*      */           }
/*      */           
/*      */           public void tail(Node node, int depth) {
/* 1267 */             if (node instanceof Element) {
/* 1268 */               Element element = (Element)node;
/* 1269 */               if (element.isBlock() && node.nextSibling() instanceof TextNode && !TextNode.lastCharIsWhitespace(accum)) {
/* 1270 */                 accum.append(' ');
/*      */               }
/*      */             } 
/*      */           }
/*      */         }this);
/*      */     
/* 1276 */     return StringUtil.releaseBuilder(accum).trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String wholeText() {
/* 1287 */     final StringBuilder accum = StringUtil.borrowBuilder();
/* 1288 */     NodeTraversor.traverse(new NodeVisitor() {
/*      */           public void head(Node node, int depth) {
/* 1290 */             if (node instanceof TextNode) {
/* 1291 */               TextNode textNode = (TextNode)node;
/* 1292 */               accum.append(textNode.getWholeText());
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public void tail(Node node, int depth) {}
/*      */         },  this);
/* 1300 */     return StringUtil.releaseBuilder(accum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String ownText() {
/* 1315 */     StringBuilder sb = StringUtil.borrowBuilder();
/* 1316 */     ownText(sb);
/* 1317 */     return StringUtil.releaseBuilder(sb).trim();
/*      */   }
/*      */   
/*      */   private void ownText(StringBuilder accum) {
/* 1321 */     for (int i = 0; i < childNodeSize(); i++) {
/* 1322 */       Node child = this.childNodes.get(i);
/* 1323 */       if (child instanceof TextNode) {
/* 1324 */         TextNode textNode = (TextNode)child;
/* 1325 */         appendNormalisedText(accum, textNode);
/* 1326 */       } else if (child instanceof Element) {
/* 1327 */         appendWhitespaceIfBr((Element)child, accum);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void appendNormalisedText(StringBuilder accum, TextNode textNode) {
/* 1333 */     String text = textNode.getWholeText();
/*      */     
/* 1335 */     if (preserveWhitespace(textNode.parentNode) || textNode instanceof CDataNode) {
/* 1336 */       accum.append(text);
/*      */     } else {
/* 1338 */       StringUtil.appendNormalisedWhitespace(accum, text, TextNode.lastCharIsWhitespace(accum));
/*      */     } 
/*      */   }
/*      */   private static void appendWhitespaceIfBr(Element element, StringBuilder accum) {
/* 1342 */     if (element.tag.normalName().equals("br") && !TextNode.lastCharIsWhitespace(accum)) {
/* 1343 */       accum.append(" ");
/*      */     }
/*      */   }
/*      */   
/*      */   static boolean preserveWhitespace(@Nullable Node node) {
/* 1348 */     if (node instanceof Element) {
/* 1349 */       Element el = (Element)node;
/* 1350 */       int i = 0;
/*      */       do {
/* 1352 */         if (el.tag.preserveWhitespace())
/* 1353 */           return true; 
/* 1354 */         el = el.parent();
/* 1355 */         ++i;
/* 1356 */       } while (i < 6 && el != null);
/*      */     } 
/* 1358 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element text(String text) {
/* 1369 */     Validate.notNull(text);
/* 1370 */     empty();
/*      */     
/* 1372 */     Document owner = ownerDocument();
/*      */     
/* 1374 */     if (owner != null && owner.parser().isContentForTagData(normalName())) {
/* 1375 */       appendChild(new DataNode(text));
/*      */     } else {
/* 1377 */       appendChild(new TextNode(text));
/*      */     } 
/* 1379 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasText() {
/* 1387 */     for (Node child : this.childNodes) {
/* 1388 */       if (child instanceof TextNode) {
/* 1389 */         TextNode textNode = (TextNode)child;
/* 1390 */         if (!textNode.isBlank())
/* 1391 */           return true;  continue;
/* 1392 */       }  if (child instanceof Element) {
/* 1393 */         Element el = (Element)child;
/* 1394 */         if (el.hasText())
/* 1395 */           return true; 
/*      */       } 
/*      */     } 
/* 1398 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String data() {
/* 1411 */     StringBuilder sb = StringUtil.borrowBuilder();
/*      */     
/* 1413 */     for (Node childNode : this.childNodes) {
/* 1414 */       if (childNode instanceof DataNode) {
/* 1415 */         DataNode data = (DataNode)childNode;
/* 1416 */         sb.append(data.getWholeData()); continue;
/* 1417 */       }  if (childNode instanceof Comment) {
/* 1418 */         Comment comment = (Comment)childNode;
/* 1419 */         sb.append(comment.getData()); continue;
/* 1420 */       }  if (childNode instanceof Element) {
/* 1421 */         Element element = (Element)childNode;
/* 1422 */         String elementData = element.data();
/* 1423 */         sb.append(elementData); continue;
/* 1424 */       }  if (childNode instanceof CDataNode) {
/*      */ 
/*      */         
/* 1427 */         CDataNode cDataNode = (CDataNode)childNode;
/* 1428 */         sb.append(cDataNode.getWholeText());
/*      */       } 
/*      */     } 
/* 1431 */     return StringUtil.releaseBuilder(sb);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String className() {
/* 1440 */     return attr("class").trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> classNames() {
/* 1450 */     String[] names = ClassSplit.split(className());
/* 1451 */     Set<String> classNames = new LinkedHashSet<>(Arrays.asList(names));
/* 1452 */     classNames.remove("");
/*      */     
/* 1454 */     return classNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element classNames(Set<String> classNames) {
/* 1463 */     Validate.notNull(classNames);
/* 1464 */     if (classNames.isEmpty()) {
/* 1465 */       attributes().remove("class");
/*      */     } else {
/* 1467 */       attributes().put("class", StringUtil.join(classNames, " "));
/*      */     } 
/* 1469 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasClass(String className) {
/* 1479 */     if (this.attributes == null) {
/* 1480 */       return false;
/*      */     }
/* 1482 */     String classAttr = this.attributes.getIgnoreCase("class");
/* 1483 */     int len = classAttr.length();
/* 1484 */     int wantLen = className.length();
/*      */     
/* 1486 */     if (len == 0 || len < wantLen) {
/* 1487 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1491 */     if (len == wantLen) {
/* 1492 */       return className.equalsIgnoreCase(classAttr);
/*      */     }
/*      */ 
/*      */     
/* 1496 */     boolean inClass = false;
/* 1497 */     int start = 0;
/* 1498 */     for (int i = 0; i < len; i++) {
/* 1499 */       if (Character.isWhitespace(classAttr.charAt(i))) {
/* 1500 */         if (inClass)
/*      */         {
/* 1502 */           if (i - start == wantLen && classAttr.regionMatches(true, start, className, 0, wantLen)) {
/* 1503 */             return true;
/*      */           }
/* 1505 */           inClass = false;
/*      */         }
/*      */       
/* 1508 */       } else if (!inClass) {
/*      */         
/* 1510 */         inClass = true;
/* 1511 */         start = i;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1517 */     if (inClass && len - start == wantLen) {
/* 1518 */       return classAttr.regionMatches(true, start, className, 0, wantLen);
/*      */     }
/*      */     
/* 1521 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element addClass(String className) {
/* 1530 */     Validate.notNull(className);
/*      */     
/* 1532 */     Set<String> classes = classNames();
/* 1533 */     classes.add(className);
/* 1534 */     classNames(classes);
/*      */     
/* 1536 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element removeClass(String className) {
/* 1545 */     Validate.notNull(className);
/*      */     
/* 1547 */     Set<String> classes = classNames();
/* 1548 */     classes.remove(className);
/* 1549 */     classNames(classes);
/*      */     
/* 1551 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element toggleClass(String className) {
/* 1560 */     Validate.notNull(className);
/*      */     
/* 1562 */     Set<String> classes = classNames();
/* 1563 */     if (classes.contains(className)) {
/* 1564 */       classes.remove(className);
/*      */     } else {
/* 1566 */       classes.add(className);
/* 1567 */     }  classNames(classes);
/*      */     
/* 1569 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String val() {
/* 1577 */     if (normalName().equals("textarea")) {
/* 1578 */       return text();
/*      */     }
/* 1580 */     return attr("value");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element val(String value) {
/* 1589 */     if (normalName().equals("textarea")) {
/* 1590 */       text(value);
/*      */     } else {
/* 1592 */       attr("value", value);
/* 1593 */     }  return this;
/*      */   }
/*      */   
/*      */   void outerHtmlHead(Appendable accum, int depth, Document.OutputSettings out) throws IOException {
/* 1597 */     if (out.prettyPrint() && isFormatAsBlock(out) && !isInlineable(out)) {
/* 1598 */       if (accum instanceof StringBuilder) {
/* 1599 */         if (((StringBuilder)accum).length() > 0)
/* 1600 */           indent(accum, depth, out); 
/*      */       } else {
/* 1602 */         indent(accum, depth, out);
/*      */       } 
/*      */     }
/* 1605 */     accum.append('<').append(tagName());
/* 1606 */     if (this.attributes != null) this.attributes.html(accum, out);
/*      */ 
/*      */     
/* 1609 */     if (this.childNodes.isEmpty() && this.tag.isSelfClosing()) {
/* 1610 */       if (out.syntax() == Document.OutputSettings.Syntax.html && this.tag.isEmpty()) {
/* 1611 */         accum.append('>');
/*      */       } else {
/* 1613 */         accum.append(" />");
/*      */       } 
/*      */     } else {
/* 1616 */       accum.append('>');
/*      */     } 
/*      */   }
/*      */   void outerHtmlTail(Appendable accum, int depth, Document.OutputSettings out) throws IOException {
/* 1620 */     if (!this.childNodes.isEmpty() || !this.tag.isSelfClosing()) {
/* 1621 */       if (out.prettyPrint() && !this.childNodes.isEmpty() && (this.tag
/* 1622 */         .formatAsBlock() || (out.outline() && (this.childNodes.size() > 1 || (this.childNodes.size() == 1 && !(this.childNodes.get(0) instanceof TextNode))))))
/*      */       {
/* 1624 */         indent(accum, depth, out); } 
/* 1625 */       accum.append("</").append(tagName()).append('>');
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String html() {
/* 1637 */     StringBuilder accum = StringUtil.borrowBuilder();
/* 1638 */     html(accum);
/* 1639 */     String html = StringUtil.releaseBuilder(accum);
/* 1640 */     return NodeUtils.outputSettings(this).prettyPrint() ? html.trim() : html;
/*      */   }
/*      */ 
/*      */   
/*      */   public <T extends Appendable> T html(T appendable) {
/* 1645 */     int size = this.childNodes.size();
/* 1646 */     for (int i = 0; i < size; i++) {
/* 1647 */       ((Node)this.childNodes.get(i)).outerHtml((Appendable)appendable);
/*      */     }
/* 1649 */     return appendable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Element html(String html) {
/* 1659 */     empty();
/* 1660 */     append(html);
/* 1661 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public Element clone() {
/* 1666 */     return (Element)super.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Element shallowClone() {
/* 1672 */     return new Element(this.tag, baseUri(), (this.attributes == null) ? null : this.attributes.clone());
/*      */   }
/*      */ 
/*      */   
/*      */   protected Element doClone(@Nullable Node parent) {
/* 1677 */     Element clone = (Element)super.doClone(parent);
/* 1678 */     clone.attributes = (this.attributes != null) ? this.attributes.clone() : null;
/* 1679 */     clone.childNodes = (List<Node>)new NodeList(clone, this.childNodes.size());
/* 1680 */     clone.childNodes.addAll(this.childNodes);
/*      */     
/* 1682 */     return clone;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Element clearAttributes() {
/* 1688 */     if (this.attributes != null) {
/* 1689 */       super.clearAttributes();
/* 1690 */       this.attributes = null;
/*      */     } 
/*      */     
/* 1693 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public Element removeAttr(String attributeKey) {
/* 1698 */     return (Element)super.removeAttr(attributeKey);
/*      */   }
/*      */ 
/*      */   
/*      */   public Element root() {
/* 1703 */     return (Element)super.root();
/*      */   }
/*      */ 
/*      */   
/*      */   public Element traverse(NodeVisitor nodeVisitor) {
/* 1708 */     return (Element)super.traverse(nodeVisitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public Element filter(NodeFilter nodeFilter) {
/* 1713 */     return (Element)super.filter(nodeFilter);
/*      */   }
/*      */   
/*      */   private static final class NodeList extends ChangeNotifyingArrayList<Node> {
/*      */     private final Element owner;
/*      */     
/*      */     NodeList(Element owner, int initialCapacity) {
/* 1720 */       super(initialCapacity);
/* 1721 */       this.owner = owner;
/*      */     }
/*      */     
/*      */     public void onContentsChanged() {
/* 1725 */       this.owner.nodelistChanged();
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean isFormatAsBlock(Document.OutputSettings out) {
/* 1730 */     return (this.tag.formatAsBlock() || (parent() != null && parent().tag().formatAsBlock()) || out.outline());
/*      */   }
/*      */   
/*      */   private boolean isInlineable(Document.OutputSettings out) {
/* 1734 */     return (tag().isInline() && 
/* 1735 */       !tag().isEmpty() && (
/* 1736 */       parent() == null || parent().isBlock()) && 
/* 1737 */       previousSibling() != null && 
/* 1738 */       !out.outline());
/*      */   }
/*      */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\nodes\Element.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */