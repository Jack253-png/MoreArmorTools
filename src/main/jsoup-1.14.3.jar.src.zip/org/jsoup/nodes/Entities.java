/*     */ package org.jsoup.nodes;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import org.jsoup.SerializationException;
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.internal.StringUtil;
/*     */ import org.jsoup.parser.CharacterReader;
/*     */ import org.jsoup.parser.Parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Entities
/*     */ {
/*     */   private static final int empty = -1;
/*     */   private static final String emptyName = "";
/*     */   static final int codepointRadix = 36;
/*  27 */   private static final char[] codeDelims = new char[] { ',', ';' };
/*  28 */   private static final HashMap<String, String> multipoints = new HashMap<>();
/*  29 */   private static final Document.OutputSettings DefaultOutput = new Document.OutputSettings();
/*     */ 
/*     */ 
/*     */   
/*     */   public enum EscapeMode
/*     */   {
/*  35 */     xhtml(EntitiesData.xmlPoints, 4),
/*     */ 
/*     */ 
/*     */     
/*  39 */     base(EntitiesData.basePoints, 106),
/*     */ 
/*     */ 
/*     */     
/*  43 */     extended(EntitiesData.fullPoints, 2125);
/*     */     
/*     */     private String[] nameKeys;
/*     */     
/*     */     private int[] codeVals;
/*     */     
/*     */     private int[] codeKeys;
/*     */     
/*     */     private String[] nameVals;
/*     */     
/*     */     EscapeMode(String file, int size) {
/*  54 */       Entities.load(this, file, size);
/*     */     }
/*     */     
/*     */     int codepointForName(String name) {
/*  58 */       int index = Arrays.binarySearch((Object[])this.nameKeys, name);
/*  59 */       return (index >= 0) ? this.codeVals[index] : -1;
/*     */     }
/*     */     
/*     */     String nameForCodepoint(int codepoint) {
/*  63 */       int index = Arrays.binarySearch(this.codeKeys, codepoint);
/*  64 */       if (index >= 0)
/*     */       {
/*     */         
/*  67 */         return (index < this.nameVals.length - 1 && this.codeKeys[index + 1] == codepoint) ? 
/*  68 */           this.nameVals[index + 1] : this.nameVals[index];
/*     */       }
/*  70 */       return "";
/*     */     }
/*     */     
/*     */     private int size() {
/*  74 */       return this.nameKeys.length;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNamedEntity(String name) {
/*  88 */     return (EscapeMode.extended.codepointForName(name) != -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBaseNamedEntity(String name) {
/*  99 */     return (EscapeMode.base.codepointForName(name) != -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getByName(String name) {
/* 109 */     String val = multipoints.get(name);
/* 110 */     if (val != null)
/* 111 */       return val; 
/* 112 */     int codepoint = EscapeMode.extended.codepointForName(name);
/* 113 */     if (codepoint != -1)
/* 114 */       return new String(new int[] { codepoint }, 0, 1); 
/* 115 */     return "";
/*     */   }
/*     */   
/*     */   public static int codepointsForName(String name, int[] codepoints) {
/* 119 */     String val = multipoints.get(name);
/* 120 */     if (val != null) {
/* 121 */       codepoints[0] = val.codePointAt(0);
/* 122 */       codepoints[1] = val.codePointAt(1);
/* 123 */       return 2;
/*     */     } 
/* 125 */     int codepoint = EscapeMode.extended.codepointForName(name);
/* 126 */     if (codepoint != -1) {
/* 127 */       codepoints[0] = codepoint;
/* 128 */       return 1;
/*     */     } 
/* 130 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escape(String string, Document.OutputSettings out) {
/* 141 */     if (string == null)
/* 142 */       return ""; 
/* 143 */     StringBuilder accum = StringUtil.borrowBuilder();
/*     */     try {
/* 145 */       escape(accum, string, out, false, false, false);
/* 146 */     } catch (IOException e) {
/* 147 */       throw new SerializationException(e);
/*     */     } 
/* 149 */     return StringUtil.releaseBuilder(accum);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escape(String string) {
/* 160 */     return escape(string, DefaultOutput);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void escape(Appendable accum, String string, Document.OutputSettings out, boolean inAttribute, boolean normaliseWhite, boolean stripLeadingWhite) throws IOException {
/*     */     // Byte code:
/*     */     //   0: iconst_0
/*     */     //   1: istore #6
/*     */     //   3: iconst_0
/*     */     //   4: istore #7
/*     */     //   6: aload_2
/*     */     //   7: invokevirtual escapeMode : ()Lorg/jsoup/nodes/Entities$EscapeMode;
/*     */     //   10: astore #8
/*     */     //   12: aload_2
/*     */     //   13: invokevirtual encoder : ()Ljava/nio/charset/CharsetEncoder;
/*     */     //   16: astore #9
/*     */     //   18: aload_2
/*     */     //   19: getfield coreCharset : Lorg/jsoup/nodes/Entities$CoreCharset;
/*     */     //   22: astore #10
/*     */     //   24: aload_1
/*     */     //   25: invokevirtual length : ()I
/*     */     //   28: istore #11
/*     */     //   30: iconst_0
/*     */     //   31: istore #13
/*     */     //   33: iload #13
/*     */     //   35: iload #11
/*     */     //   37: if_icmpge -> 445
/*     */     //   40: aload_1
/*     */     //   41: iload #13
/*     */     //   43: invokevirtual codePointAt : (I)I
/*     */     //   46: istore #12
/*     */     //   48: iload #4
/*     */     //   50: ifeq -> 100
/*     */     //   53: iload #12
/*     */     //   55: invokestatic isWhitespace : (I)Z
/*     */     //   58: ifeq -> 94
/*     */     //   61: iload #5
/*     */     //   63: ifeq -> 71
/*     */     //   66: iload #7
/*     */     //   68: ifeq -> 432
/*     */     //   71: iload #6
/*     */     //   73: ifeq -> 79
/*     */     //   76: goto -> 432
/*     */     //   79: aload_0
/*     */     //   80: bipush #32
/*     */     //   82: invokeinterface append : (C)Ljava/lang/Appendable;
/*     */     //   87: pop
/*     */     //   88: iconst_1
/*     */     //   89: istore #6
/*     */     //   91: goto -> 432
/*     */     //   94: iconst_0
/*     */     //   95: istore #6
/*     */     //   97: iconst_1
/*     */     //   98: istore #7
/*     */     //   100: iload #12
/*     */     //   102: ldc 65536
/*     */     //   104: if_icmpge -> 388
/*     */     //   107: iload #12
/*     */     //   109: i2c
/*     */     //   110: istore #14
/*     */     //   112: iload #14
/*     */     //   114: lookupswitch default -> 346, 9 -> 334, 10 -> 334, 13 -> 334, 34 -> 306, 38 -> 188, 60 -> 232, 62 -> 278, 160 -> 200
/*     */     //   188: aload_0
/*     */     //   189: ldc '&amp;'
/*     */     //   191: invokeinterface append : (Ljava/lang/CharSequence;)Ljava/lang/Appendable;
/*     */     //   196: pop
/*     */     //   197: goto -> 385
/*     */     //   200: aload #8
/*     */     //   202: getstatic org/jsoup/nodes/Entities$EscapeMode.xhtml : Lorg/jsoup/nodes/Entities$EscapeMode;
/*     */     //   205: if_acmpeq -> 220
/*     */     //   208: aload_0
/*     */     //   209: ldc '&nbsp;'
/*     */     //   211: invokeinterface append : (Ljava/lang/CharSequence;)Ljava/lang/Appendable;
/*     */     //   216: pop
/*     */     //   217: goto -> 385
/*     */     //   220: aload_0
/*     */     //   221: ldc '&#xa0;'
/*     */     //   223: invokeinterface append : (Ljava/lang/CharSequence;)Ljava/lang/Appendable;
/*     */     //   228: pop
/*     */     //   229: goto -> 385
/*     */     //   232: iload_3
/*     */     //   233: ifeq -> 254
/*     */     //   236: aload #8
/*     */     //   238: getstatic org/jsoup/nodes/Entities$EscapeMode.xhtml : Lorg/jsoup/nodes/Entities$EscapeMode;
/*     */     //   241: if_acmpeq -> 254
/*     */     //   244: aload_2
/*     */     //   245: invokevirtual syntax : ()Lorg/jsoup/nodes/Document$OutputSettings$Syntax;
/*     */     //   248: getstatic org/jsoup/nodes/Document$OutputSettings$Syntax.xml : Lorg/jsoup/nodes/Document$OutputSettings$Syntax;
/*     */     //   251: if_acmpne -> 266
/*     */     //   254: aload_0
/*     */     //   255: ldc '&lt;'
/*     */     //   257: invokeinterface append : (Ljava/lang/CharSequence;)Ljava/lang/Appendable;
/*     */     //   262: pop
/*     */     //   263: goto -> 385
/*     */     //   266: aload_0
/*     */     //   267: iload #14
/*     */     //   269: invokeinterface append : (C)Ljava/lang/Appendable;
/*     */     //   274: pop
/*     */     //   275: goto -> 385
/*     */     //   278: iload_3
/*     */     //   279: ifne -> 294
/*     */     //   282: aload_0
/*     */     //   283: ldc '&gt;'
/*     */     //   285: invokeinterface append : (Ljava/lang/CharSequence;)Ljava/lang/Appendable;
/*     */     //   290: pop
/*     */     //   291: goto -> 385
/*     */     //   294: aload_0
/*     */     //   295: iload #14
/*     */     //   297: invokeinterface append : (C)Ljava/lang/Appendable;
/*     */     //   302: pop
/*     */     //   303: goto -> 385
/*     */     //   306: iload_3
/*     */     //   307: ifeq -> 322
/*     */     //   310: aload_0
/*     */     //   311: ldc '&quot;'
/*     */     //   313: invokeinterface append : (Ljava/lang/CharSequence;)Ljava/lang/Appendable;
/*     */     //   318: pop
/*     */     //   319: goto -> 385
/*     */     //   322: aload_0
/*     */     //   323: iload #14
/*     */     //   325: invokeinterface append : (C)Ljava/lang/Appendable;
/*     */     //   330: pop
/*     */     //   331: goto -> 385
/*     */     //   334: aload_0
/*     */     //   335: iload #14
/*     */     //   337: invokeinterface append : (C)Ljava/lang/Appendable;
/*     */     //   342: pop
/*     */     //   343: goto -> 385
/*     */     //   346: iload #14
/*     */     //   348: bipush #32
/*     */     //   350: if_icmplt -> 365
/*     */     //   353: aload #10
/*     */     //   355: iload #14
/*     */     //   357: aload #9
/*     */     //   359: invokestatic canEncode : (Lorg/jsoup/nodes/Entities$CoreCharset;CLjava/nio/charset/CharsetEncoder;)Z
/*     */     //   362: ifne -> 376
/*     */     //   365: aload_0
/*     */     //   366: aload #8
/*     */     //   368: iload #12
/*     */     //   370: invokestatic appendEncoded : (Ljava/lang/Appendable;Lorg/jsoup/nodes/Entities$EscapeMode;I)V
/*     */     //   373: goto -> 385
/*     */     //   376: aload_0
/*     */     //   377: iload #14
/*     */     //   379: invokeinterface append : (C)Ljava/lang/Appendable;
/*     */     //   384: pop
/*     */     //   385: goto -> 432
/*     */     //   388: new java/lang/String
/*     */     //   391: dup
/*     */     //   392: iload #12
/*     */     //   394: invokestatic toChars : (I)[C
/*     */     //   397: invokespecial <init> : ([C)V
/*     */     //   400: astore #14
/*     */     //   402: aload #9
/*     */     //   404: aload #14
/*     */     //   406: invokevirtual canEncode : (Ljava/lang/CharSequence;)Z
/*     */     //   409: ifeq -> 424
/*     */     //   412: aload_0
/*     */     //   413: aload #14
/*     */     //   415: invokeinterface append : (Ljava/lang/CharSequence;)Ljava/lang/Appendable;
/*     */     //   420: pop
/*     */     //   421: goto -> 432
/*     */     //   424: aload_0
/*     */     //   425: aload #8
/*     */     //   427: iload #12
/*     */     //   429: invokestatic appendEncoded : (Ljava/lang/Appendable;Lorg/jsoup/nodes/Entities$EscapeMode;I)V
/*     */     //   432: iload #13
/*     */     //   434: iload #12
/*     */     //   436: invokestatic charCount : (I)I
/*     */     //   439: iadd
/*     */     //   440: istore #13
/*     */     //   442: goto -> 33
/*     */     //   445: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #167	-> 0
/*     */     //   #168	-> 3
/*     */     //   #169	-> 6
/*     */     //   #170	-> 12
/*     */     //   #171	-> 18
/*     */     //   #172	-> 24
/*     */     //   #175	-> 30
/*     */     //   #176	-> 40
/*     */     //   #178	-> 48
/*     */     //   #179	-> 53
/*     */     //   #180	-> 61
/*     */     //   #181	-> 76
/*     */     //   #182	-> 79
/*     */     //   #183	-> 88
/*     */     //   #184	-> 91
/*     */     //   #186	-> 94
/*     */     //   #187	-> 97
/*     */     //   #191	-> 100
/*     */     //   #192	-> 107
/*     */     //   #194	-> 112
/*     */     //   #196	-> 188
/*     */     //   #197	-> 197
/*     */     //   #199	-> 200
/*     */     //   #200	-> 208
/*     */     //   #202	-> 220
/*     */     //   #203	-> 229
/*     */     //   #206	-> 232
/*     */     //   #207	-> 254
/*     */     //   #209	-> 266
/*     */     //   #210	-> 275
/*     */     //   #212	-> 278
/*     */     //   #213	-> 282
/*     */     //   #215	-> 294
/*     */     //   #216	-> 303
/*     */     //   #218	-> 306
/*     */     //   #219	-> 310
/*     */     //   #221	-> 322
/*     */     //   #222	-> 331
/*     */     //   #227	-> 334
/*     */     //   #228	-> 343
/*     */     //   #230	-> 346
/*     */     //   #231	-> 365
/*     */     //   #233	-> 376
/*     */     //   #235	-> 385
/*     */     //   #236	-> 388
/*     */     //   #237	-> 402
/*     */     //   #238	-> 412
/*     */     //   #240	-> 424
/*     */     //   #175	-> 432
/*     */     //   #243	-> 445
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   112	273	14	c	C
/*     */     //   402	30	14	c	Ljava/lang/String;
/*     */     //   48	397	12	codePoint	I
/*     */     //   33	412	13	offset	I
/*     */     //   0	446	0	accum	Ljava/lang/Appendable;
/*     */     //   0	446	1	string	Ljava/lang/String;
/*     */     //   0	446	2	out	Lorg/jsoup/nodes/Document$OutputSettings;
/*     */     //   0	446	3	inAttribute	Z
/*     */     //   0	446	4	normaliseWhite	Z
/*     */     //   0	446	5	stripLeadingWhite	Z
/*     */     //   3	443	6	lastWasWhite	Z
/*     */     //   6	440	7	reachedNonWhite	Z
/*     */     //   12	434	8	escapeMode	Lorg/jsoup/nodes/Entities$EscapeMode;
/*     */     //   18	428	9	encoder	Ljava/nio/charset/CharsetEncoder;
/*     */     //   24	422	10	coreCharset	Lorg/jsoup/nodes/Entities$CoreCharset;
/*     */     //   30	416	11	length	I
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void appendEncoded(Appendable accum, EscapeMode escapeMode, int codePoint) throws IOException {
/* 246 */     String name = escapeMode.nameForCodepoint(codePoint);
/* 247 */     if (!"".equals(name)) {
/* 248 */       accum.append('&').append(name).append(';');
/*     */     } else {
/* 250 */       accum.append("&#x").append(Integer.toHexString(codePoint)).append(';');
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String unescape(String string) {
/* 260 */     return unescape(string, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String unescape(String string, boolean strict) {
/* 271 */     return Parser.unescapeEntities(string, strict);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean canEncode(CoreCharset charset, char c, CharsetEncoder fallback) {
/* 289 */     switch (charset) {
/*     */       case ascii:
/* 291 */         return (c < '');
/*     */       case utf:
/* 293 */         return true;
/*     */     } 
/* 295 */     return fallback.canEncode(c);
/*     */   }
/*     */   
/*     */   enum CoreCharset
/*     */   {
/* 300 */     ascii, utf, fallback;
/*     */     
/*     */     static CoreCharset byName(String name) {
/* 303 */       if (name.equals("US-ASCII"))
/* 304 */         return ascii; 
/* 305 */       if (name.startsWith("UTF-"))
/* 306 */         return utf; 
/* 307 */       return fallback;
/*     */     }
/*     */   }
/*     */   
/*     */   private static void load(EscapeMode e, String pointsData, int size) {
/* 312 */     e.nameKeys = new String[size];
/* 313 */     e.codeVals = new int[size];
/* 314 */     e.codeKeys = new int[size];
/* 315 */     e.nameVals = new String[size];
/*     */     
/* 317 */     int i = 0;
/* 318 */     CharacterReader reader = new CharacterReader(pointsData);
/*     */     try {
/* 320 */       while (!reader.isEmpty()) {
/*     */         int cp2;
/*     */         
/* 323 */         String name = reader.consumeTo('=');
/* 324 */         reader.advance();
/* 325 */         int cp1 = Integer.parseInt(reader.consumeToAny(codeDelims), 36);
/* 326 */         char codeDelim = reader.current();
/* 327 */         reader.advance();
/*     */         
/* 329 */         if (codeDelim == ',') {
/* 330 */           cp2 = Integer.parseInt(reader.consumeTo(';'), 36);
/* 331 */           reader.advance();
/*     */         } else {
/* 333 */           cp2 = -1;
/*     */         } 
/* 335 */         String indexS = reader.consumeTo('&');
/* 336 */         int index = Integer.parseInt(indexS, 36);
/* 337 */         reader.advance();
/*     */         
/* 339 */         e.nameKeys[i] = name;
/* 340 */         e.codeVals[i] = cp1;
/* 341 */         e.codeKeys[index] = cp1;
/* 342 */         e.nameVals[index] = name;
/*     */         
/* 344 */         if (cp2 != -1) {
/* 345 */           multipoints.put(name, new String(new int[] { cp1, cp2 }, 0, 2));
/*     */         }
/* 347 */         i++;
/*     */       } 
/*     */       
/* 350 */       Validate.isTrue((i == size), "Unexpected count of entities loaded");
/*     */     } finally {
/* 352 */       reader.close();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\nodes\Entities.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */