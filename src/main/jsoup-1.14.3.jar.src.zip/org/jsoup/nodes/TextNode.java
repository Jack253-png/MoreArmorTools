/*     */ package org.jsoup.nodes;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.internal.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextNode
/*     */   extends LeafNode
/*     */ {
/*     */   public TextNode(String text) {
/*  20 */     this.value = text;
/*     */   }
/*     */   
/*     */   public String nodeName() {
/*  24 */     return "#text";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String text() {
/*  33 */     return StringUtil.normaliseWhitespace(getWholeText());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextNode text(String text) {
/*  42 */     coreValue(text);
/*  43 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getWholeText() {
/*  51 */     return coreValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBlank() {
/*  59 */     return StringUtil.isBlank(coreValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextNode splitText(int offset) {
/*  69 */     String text = coreValue();
/*  70 */     Validate.isTrue((offset >= 0), "Split offset must be not be negative");
/*  71 */     Validate.isTrue((offset < text.length()), "Split offset must not be greater than current text length");
/*     */     
/*  73 */     String head = text.substring(0, offset);
/*  74 */     String tail = text.substring(offset);
/*  75 */     text(head);
/*  76 */     TextNode tailNode = new TextNode(tail);
/*  77 */     if (parent() != null) {
/*  78 */       parent().addChildren(siblingIndex() + 1, new Node[] { tailNode });
/*     */     }
/*  80 */     return tailNode;
/*     */   }
/*     */   
/*     */   void outerHtmlHead(Appendable accum, int depth, Document.OutputSettings out) throws IOException {
/*  84 */     boolean prettyPrint = out.prettyPrint();
/*  85 */     if (prettyPrint && ((siblingIndex() == 0 && this.parentNode instanceof Element && ((Element)this.parentNode).tag().formatAsBlock() && !isBlank()) || (out.outline() && siblingNodes().size() > 0 && !isBlank()))) {
/*  86 */       indent(accum, depth, out);
/*     */     }
/*  88 */     boolean normaliseWhite = (prettyPrint && !Element.preserveWhitespace(this.parentNode));
/*  89 */     boolean stripWhite = (prettyPrint && this.parentNode instanceof Document);
/*  90 */     Entities.escape(accum, coreValue(), out, false, normaliseWhite, stripWhite);
/*     */   }
/*     */ 
/*     */   
/*     */   void outerHtmlTail(Appendable accum, int depth, Document.OutputSettings out) {}
/*     */   
/*     */   public String toString() {
/*  97 */     return outerHtml();
/*     */   }
/*     */ 
/*     */   
/*     */   public TextNode clone() {
/* 102 */     return (TextNode)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TextNode createFromEncoded(String encodedText) {
/* 111 */     String text = Entities.unescape(encodedText);
/* 112 */     return new TextNode(text);
/*     */   }
/*     */   
/*     */   static String normaliseWhitespace(String text) {
/* 116 */     text = StringUtil.normaliseWhitespace(text);
/* 117 */     return text;
/*     */   }
/*     */   
/*     */   static String stripLeadingWhitespace(String text) {
/* 121 */     return text.replaceFirst("^\\s+", "");
/*     */   }
/*     */   
/*     */   static boolean lastCharIsWhitespace(StringBuilder sb) {
/* 125 */     return (sb.length() != 0 && sb.charAt(sb.length() - 1) == ' ');
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\nodes\TextNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */