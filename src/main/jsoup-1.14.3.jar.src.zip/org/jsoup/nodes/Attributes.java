/*     */ package org.jsoup.nodes;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nullable;
/*     */ import org.jsoup.SerializationException;
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.internal.Normalizer;
/*     */ import org.jsoup.internal.StringUtil;
/*     */ import org.jsoup.parser.ParseSettings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Attributes
/*     */   implements Iterable<Attribute>, Cloneable
/*     */ {
/*     */   protected static final String dataPrefix = "data-";
/*     */   static final char InternalPrefix = '/';
/*     */   private static final int InitialCapacity = 3;
/*     */   private static final int GrowthFactor = 2;
/*     */   static final int NotFound = -1;
/*     */   private static final String EmptyString = "";
/*  50 */   private int size = 0;
/*  51 */   String[] keys = new String[3];
/*  52 */   String[] vals = new String[3];
/*     */ 
/*     */   
/*     */   private void checkCapacity(int minNewSize) {
/*  56 */     Validate.isTrue((minNewSize >= this.size));
/*  57 */     int curCap = this.keys.length;
/*  58 */     if (curCap >= minNewSize)
/*     */       return; 
/*  60 */     int newCap = (curCap >= 3) ? (this.size * 2) : 3;
/*  61 */     if (minNewSize > newCap) {
/*  62 */       newCap = minNewSize;
/*     */     }
/*  64 */     this.keys = Arrays.<String>copyOf(this.keys, newCap);
/*  65 */     this.vals = Arrays.<String>copyOf(this.vals, newCap);
/*     */   }
/*     */   
/*     */   int indexOfKey(String key) {
/*  69 */     Validate.notNull(key);
/*  70 */     for (int i = 0; i < this.size; i++) {
/*  71 */       if (key.equals(this.keys[i]))
/*  72 */         return i; 
/*     */     } 
/*  74 */     return -1;
/*     */   }
/*     */   
/*     */   private int indexOfKeyIgnoreCase(String key) {
/*  78 */     Validate.notNull(key);
/*  79 */     for (int i = 0; i < this.size; i++) {
/*  80 */       if (key.equalsIgnoreCase(this.keys[i]))
/*  81 */         return i; 
/*     */     } 
/*  83 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   static String checkNotNull(@Nullable String val) {
/*  88 */     return (val == null) ? "" : val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String get(String key) {
/*  98 */     int i = indexOfKey(key);
/*  99 */     return (i == -1) ? "" : checkNotNull(this.vals[i]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIgnoreCase(String key) {
/* 108 */     int i = indexOfKeyIgnoreCase(key);
/* 109 */     return (i == -1) ? "" : checkNotNull(this.vals[i]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attributes add(String key, @Nullable String value) {
/* 117 */     checkCapacity(this.size + 1);
/* 118 */     this.keys[this.size] = key;
/* 119 */     this.vals[this.size] = value;
/* 120 */     this.size++;
/* 121 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attributes put(String key, @Nullable String value) {
/* 131 */     Validate.notNull(key);
/* 132 */     int i = indexOfKey(key);
/* 133 */     if (i != -1) {
/* 134 */       this.vals[i] = value;
/*     */     } else {
/* 136 */       add(key, value);
/* 137 */     }  return this;
/*     */   }
/*     */   
/*     */   void putIgnoreCase(String key, @Nullable String value) {
/* 141 */     int i = indexOfKeyIgnoreCase(key);
/* 142 */     if (i != -1) {
/* 143 */       this.vals[i] = value;
/* 144 */       if (!this.keys[i].equals(key)) {
/* 145 */         this.keys[i] = key;
/*     */       }
/*     */     } else {
/* 148 */       add(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attributes put(String key, boolean value) {
/* 158 */     if (value) {
/* 159 */       putIgnoreCase(key, null);
/*     */     } else {
/* 161 */       remove(key);
/* 162 */     }  return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attributes put(Attribute attribute) {
/* 171 */     Validate.notNull(attribute);
/* 172 */     put(attribute.getKey(), attribute.getValue());
/* 173 */     attribute.parent = this;
/* 174 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void remove(int index) {
/* 180 */     Validate.isFalse((index >= this.size));
/* 181 */     int shifted = this.size - index - 1;
/* 182 */     if (shifted > 0) {
/* 183 */       System.arraycopy(this.keys, index + 1, this.keys, index, shifted);
/* 184 */       System.arraycopy(this.vals, index + 1, this.vals, index, shifted);
/*     */     } 
/* 186 */     this.size--;
/* 187 */     this.keys[this.size] = null;
/* 188 */     this.vals[this.size] = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(String key) {
/* 196 */     int i = indexOfKey(key);
/* 197 */     if (i != -1) {
/* 198 */       remove(i);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeIgnoreCase(String key) {
/* 206 */     int i = indexOfKeyIgnoreCase(key);
/* 207 */     if (i != -1) {
/* 208 */       remove(i);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasKey(String key) {
/* 217 */     return (indexOfKey(key) != -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasKeyIgnoreCase(String key) {
/* 226 */     return (indexOfKeyIgnoreCase(key) != -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDeclaredValueForKey(String key) {
/* 235 */     int i = indexOfKey(key);
/* 236 */     return (i != -1 && this.vals[i] != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDeclaredValueForKeyIgnoreCase(String key) {
/* 245 */     int i = indexOfKeyIgnoreCase(key);
/* 246 */     return (i != -1 && this.vals[i] != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 255 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 262 */     return (this.size == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAll(Attributes incoming) {
/* 270 */     if (incoming.size() == 0)
/*     */       return; 
/* 272 */     checkCapacity(this.size + incoming.size);
/*     */     
/* 274 */     for (Attribute attr : incoming)
/*     */     {
/* 276 */       put(attr);
/*     */     }
/*     */   }
/*     */   
/*     */   public Iterator<Attribute> iterator() {
/* 281 */     return new Iterator<Attribute>() {
/* 282 */         int i = 0;
/*     */ 
/*     */         
/*     */         public boolean hasNext() {
/* 286 */           while (this.i < Attributes.this.size && 
/* 287 */             Attributes.this.isInternalKey(Attributes.this.keys[this.i])) {
/* 288 */             this.i++;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 293 */           return (this.i < Attributes.this.size);
/*     */         }
/*     */ 
/*     */         
/*     */         public Attribute next() {
/* 298 */           Attribute attr = new Attribute(Attributes.this.keys[this.i], Attributes.this.vals[this.i], Attributes.this);
/* 299 */           this.i++;
/* 300 */           return attr;
/*     */         }
/*     */ 
/*     */         
/*     */         public void remove() {
/* 305 */           Attributes.this.remove(--this.i);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Attribute> asList() {
/* 315 */     ArrayList<Attribute> list = new ArrayList<>(this.size);
/* 316 */     for (int i = 0; i < this.size; i++) {
/* 317 */       if (!isInternalKey(this.keys[i])) {
/*     */         
/* 319 */         Attribute attr = new Attribute(this.keys[i], this.vals[i], this);
/* 320 */         list.add(attr);
/*     */       } 
/* 322 */     }  return Collections.unmodifiableList(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> dataset() {
/* 331 */     return new Dataset(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String html() {
/* 339 */     StringBuilder sb = StringUtil.borrowBuilder();
/*     */     try {
/* 341 */       html(sb, (new Document("")).outputSettings());
/* 342 */     } catch (IOException e) {
/* 343 */       throw new SerializationException(e);
/*     */     } 
/* 345 */     return StringUtil.releaseBuilder(sb);
/*     */   }
/*     */   
/*     */   final void html(Appendable accum, Document.OutputSettings out) throws IOException {
/* 349 */     int sz = this.size;
/* 350 */     for (int i = 0; i < sz; i++) {
/* 351 */       if (!isInternalKey(this.keys[i])) {
/*     */         
/* 353 */         String key = Attribute.getValidKey(this.keys[i], out.syntax());
/* 354 */         if (key != null)
/* 355 */           Attribute.htmlNoValidate(key, this.vals[i], accum.append(' '), out); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public String toString() {
/* 361 */     return html();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/* 372 */     if (this == o) return true; 
/* 373 */     if (o == null || getClass() != o.getClass()) return false;
/*     */     
/* 375 */     Attributes that = (Attributes)o;
/* 376 */     if (this.size != that.size) return false; 
/* 377 */     for (int i = 0; i < this.size; i++) {
/* 378 */       String key = this.keys[i];
/* 379 */       int thatI = that.indexOfKey(key);
/* 380 */       if (thatI == -1)
/* 381 */         return false; 
/* 382 */       String val = this.vals[i];
/* 383 */       String thatVal = that.vals[thatI];
/* 384 */       if (val == null) {
/* 385 */         if (thatVal != null)
/* 386 */           return false; 
/* 387 */       } else if (!val.equals(thatVal)) {
/* 388 */         return false;
/*     */       } 
/* 390 */     }  return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 399 */     int result = this.size;
/* 400 */     result = 31 * result + Arrays.hashCode((Object[])this.keys);
/* 401 */     result = 31 * result + Arrays.hashCode((Object[])this.vals);
/* 402 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Attributes clone() {
/*     */     Attributes clone;
/*     */     try {
/* 409 */       clone = (Attributes)super.clone();
/* 410 */     } catch (CloneNotSupportedException e) {
/* 411 */       throw new RuntimeException(e);
/*     */     } 
/* 413 */     clone.size = this.size;
/* 414 */     this.keys = Arrays.<String>copyOf(this.keys, this.size);
/* 415 */     this.vals = Arrays.<String>copyOf(this.vals, this.size);
/* 416 */     return clone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void normalize() {
/* 423 */     for (int i = 0; i < this.size; i++) {
/* 424 */       this.keys[i] = Normalizer.lowerCase(this.keys[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int deduplicate(ParseSettings settings) {
/* 434 */     if (isEmpty())
/* 435 */       return 0; 
/* 436 */     boolean preserve = settings.preserveAttributeCase();
/* 437 */     int dupes = 0;
/* 438 */     for (int i = 0; i < this.keys.length; i++) {
/* 439 */       for (int j = i + 1; j < this.keys.length && 
/* 440 */         this.keys[j] != null; j++) {
/*     */         
/* 442 */         if ((preserve && this.keys[i].equals(this.keys[j])) || (!preserve && this.keys[i].equalsIgnoreCase(this.keys[j]))) {
/* 443 */           dupes++;
/* 444 */           remove(j);
/* 445 */           j--;
/*     */         } 
/*     */       } 
/*     */     } 
/* 449 */     return dupes;
/*     */   }
/*     */   
/*     */   private static class Dataset extends AbstractMap<String, String> {
/*     */     private final Attributes attributes;
/*     */     
/*     */     private Dataset(Attributes attributes) {
/* 456 */       this.attributes = attributes;
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<Map.Entry<String, String>> entrySet() {
/* 461 */       return new EntrySet();
/*     */     }
/*     */ 
/*     */     
/*     */     public String put(String key, String value) {
/* 466 */       String dataKey = Attributes.dataKey(key);
/* 467 */       String oldValue = this.attributes.hasKey(dataKey) ? this.attributes.get(dataKey) : null;
/* 468 */       this.attributes.put(dataKey, value);
/* 469 */       return oldValue;
/*     */     }
/*     */     
/*     */     private class EntrySet extends AbstractSet<Map.Entry<String, String>> {
/*     */       private EntrySet() {}
/*     */       
/*     */       public Iterator<Map.Entry<String, String>> iterator() {
/* 476 */         return new Attributes.Dataset.DatasetIterator();
/*     */       }
/*     */ 
/*     */       
/*     */       public int size() {
/* 481 */         int count = 0;
/* 482 */         Iterator iter = new Attributes.Dataset.DatasetIterator();
/* 483 */         while (iter.hasNext())
/* 484 */           count++; 
/* 485 */         return count;
/*     */       } }
/*     */     private class DatasetIterator implements Iterator<Map.Entry<String, String>> { private Iterator<Attribute> attrIter;
/*     */       
/*     */       private DatasetIterator() {
/* 490 */         this.attrIter = Attributes.Dataset.this.attributes.iterator();
/*     */       } private Attribute attr;
/*     */       public boolean hasNext() {
/* 493 */         while (this.attrIter.hasNext()) {
/* 494 */           this.attr = this.attrIter.next();
/* 495 */           if (this.attr.isDataAttribute()) return true; 
/*     */         } 
/* 497 */         return false;
/*     */       }
/*     */       
/*     */       public Map.Entry<String, String> next() {
/* 501 */         return new Attribute(this.attr.getKey().substring("data-".length()), this.attr.getValue());
/*     */       }
/*     */       
/*     */       public void remove() {
/* 505 */         Attributes.Dataset.this.attributes.remove(this.attr.getKey());
/*     */       } }
/*     */   
/*     */   }
/*     */   
/*     */   private static String dataKey(String key) {
/* 511 */     return "data-" + key;
/*     */   }
/*     */   
/*     */   static String internalKey(String key) {
/* 515 */     return '/' + key;
/*     */   }
/*     */   
/*     */   private boolean isInternalKey(String key) {
/* 519 */     return (key != null && key.length() > 1 && key.charAt(0) == '/');
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\nodes\Attributes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */