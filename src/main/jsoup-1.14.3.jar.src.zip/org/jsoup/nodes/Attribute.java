/*     */ package org.jsoup.nodes;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.annotation.Nullable;
/*     */ import org.jsoup.SerializationException;
/*     */ import org.jsoup.helper.Validate;
/*     */ import org.jsoup.internal.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Attribute
/*     */   implements Map.Entry<String, String>, Cloneable
/*     */ {
/*  18 */   private static final String[] booleanAttributes = new String[] { "allowfullscreen", "async", "autofocus", "checked", "compact", "declare", "default", "defer", "disabled", "formnovalidate", "hidden", "inert", "ismap", "itemscope", "multiple", "muted", "nohref", "noresize", "noshade", "novalidate", "nowrap", "open", "readonly", "required", "reversed", "seamless", "selected", "sortable", "truespeed", "typemustmatch" };
/*     */ 
/*     */ 
/*     */   
/*     */   private String key;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String val;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Attributes parent;
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute(String key, @Nullable String value) {
/*  36 */     this(key, value, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute(String key, @Nullable String val, @Nullable Attributes parent) {
/*  46 */     Validate.notNull(key);
/*  47 */     key = key.trim();
/*  48 */     Validate.notEmpty(key);
/*  49 */     this.key = key;
/*  50 */     this.val = val;
/*  51 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/*  59 */     return this.key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKey(String key) {
/*  67 */     Validate.notNull(key);
/*  68 */     key = key.trim();
/*  69 */     Validate.notEmpty(key);
/*  70 */     if (this.parent != null) {
/*  71 */       int i = this.parent.indexOfKey(this.key);
/*  72 */       if (i != -1)
/*  73 */         this.parent.keys[i] = key; 
/*     */     } 
/*  75 */     this.key = key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue() {
/*  83 */     return Attributes.checkNotNull(this.val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDeclaredValue() {
/*  91 */     return (this.val != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String setValue(@Nullable String val) {
/* 100 */     String oldVal = this.val;
/* 101 */     if (this.parent != null) {
/* 102 */       int i = this.parent.indexOfKey(this.key);
/* 103 */       if (i != -1) {
/* 104 */         oldVal = this.parent.get(this.key);
/* 105 */         this.parent.vals[i] = val;
/*     */       } 
/*     */     } 
/* 108 */     this.val = val;
/* 109 */     return Attributes.checkNotNull(oldVal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String html() {
/* 117 */     StringBuilder sb = StringUtil.borrowBuilder();
/*     */     
/*     */     try {
/* 120 */       html(sb, (new Document("")).outputSettings());
/* 121 */     } catch (IOException exception) {
/* 122 */       throw new SerializationException(exception);
/*     */     } 
/* 124 */     return StringUtil.releaseBuilder(sb);
/*     */   }
/*     */   
/*     */   protected void html(Appendable accum, Document.OutputSettings out) throws IOException {
/* 128 */     html(this.key, this.val, accum, out);
/*     */   }
/*     */   
/*     */   protected static void html(String key, @Nullable String val, Appendable accum, Document.OutputSettings out) throws IOException {
/* 132 */     key = getValidKey(key, out.syntax());
/* 133 */     if (key == null)
/* 134 */       return;  htmlNoValidate(key, val, accum, out);
/*     */   }
/*     */ 
/*     */   
/*     */   static void htmlNoValidate(String key, @Nullable String val, Appendable accum, Document.OutputSettings out) throws IOException {
/* 139 */     accum.append(key);
/* 140 */     if (!shouldCollapseAttribute(key, val, out)) {
/* 141 */       accum.append("=\"");
/* 142 */       Entities.escape(accum, Attributes.checkNotNull(val), out, true, false, false);
/* 143 */       accum.append('"');
/*     */     } 
/*     */   }
/*     */   
/* 147 */   private static final Pattern xmlKeyValid = Pattern.compile("[a-zA-Z_:][-a-zA-Z0-9_:.]*");
/* 148 */   private static final Pattern xmlKeyReplace = Pattern.compile("[^-a-zA-Z0-9_:.]");
/* 149 */   private static final Pattern htmlKeyValid = Pattern.compile("[^\\x00-\\x1f\\x7f-\\x9f \"'/=]+");
/* 150 */   private static final Pattern htmlKeyReplace = Pattern.compile("[\\x00-\\x1f\\x7f-\\x9f \"'/=]");
/*     */   
/*     */   @Nullable
/*     */   public static String getValidKey(String key, Document.OutputSettings.Syntax syntax) {
/* 154 */     if (syntax == Document.OutputSettings.Syntax.xml && !xmlKeyValid.matcher(key).matches()) {
/* 155 */       key = xmlKeyReplace.matcher(key).replaceAll("");
/* 156 */       return xmlKeyValid.matcher(key).matches() ? key : null;
/*     */     } 
/* 158 */     if (syntax == Document.OutputSettings.Syntax.html && !htmlKeyValid.matcher(key).matches()) {
/* 159 */       key = htmlKeyReplace.matcher(key).replaceAll("");
/* 160 */       return htmlKeyValid.matcher(key).matches() ? key : null;
/*     */     } 
/* 162 */     return key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 171 */     return html();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Attribute createFromEncoded(String unencodedKey, String encodedValue) {
/* 181 */     String value = Entities.unescape(encodedValue, true);
/* 182 */     return new Attribute(unencodedKey, value, null);
/*     */   }
/*     */   
/*     */   protected boolean isDataAttribute() {
/* 186 */     return isDataAttribute(this.key);
/*     */   }
/*     */   
/*     */   protected static boolean isDataAttribute(String key) {
/* 190 */     return (key.startsWith("data-") && key.length() > "data-".length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean shouldCollapseAttribute(Document.OutputSettings out) {
/* 200 */     return shouldCollapseAttribute(this.key, this.val, out);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static boolean shouldCollapseAttribute(String key, @Nullable String val, Document.OutputSettings out) {
/* 205 */     return (out
/* 206 */       .syntax() == Document.OutputSettings.Syntax.html && (val == null || ((val
/* 207 */       .isEmpty() || val.equalsIgnoreCase(key)) && isBooleanAttribute(key))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBooleanAttribute(String key) {
/* 214 */     return (Arrays.binarySearch((Object[])booleanAttributes, key) >= 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/* 219 */     if (this == o) return true; 
/* 220 */     if (o == null || getClass() != o.getClass()) return false; 
/* 221 */     Attribute attribute = (Attribute)o;
/* 222 */     if ((this.key != null) ? !this.key.equals(attribute.key) : (attribute.key != null)) return false; 
/* 223 */     return (this.val != null) ? this.val.equals(attribute.val) : ((attribute.val == null));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 228 */     int result = (this.key != null) ? this.key.hashCode() : 0;
/* 229 */     result = 31 * result + ((this.val != null) ? this.val.hashCode() : 0);
/* 230 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Attribute clone() {
/*     */     try {
/* 236 */       return (Attribute)super.clone();
/* 237 */     } catch (CloneNotSupportedException e) {
/* 238 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\nodes\Attribute.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */