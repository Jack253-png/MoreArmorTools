/*    */ package org.jsoup.nodes;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.annotation.Nullable;
/*    */ import org.jsoup.parser.ParseSettings;
/*    */ import org.jsoup.parser.Parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Comment
/*    */   extends LeafNode
/*    */ {
/*    */   public Comment(String data) {
/* 19 */     this.value = data;
/*    */   }
/*    */   
/*    */   public String nodeName() {
/* 23 */     return "#comment";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getData() {
/* 31 */     return coreValue();
/*    */   }
/*    */   
/*    */   public Comment setData(String data) {
/* 35 */     coreValue(data);
/* 36 */     return this;
/*    */   }
/*    */   
/*    */   void outerHtmlHead(Appendable accum, int depth, Document.OutputSettings out) throws IOException {
/* 40 */     if (out.prettyPrint() && ((siblingIndex() == 0 && this.parentNode instanceof Element && ((Element)this.parentNode).tag().formatAsBlock()) || out.outline()))
/* 41 */       indent(accum, depth, out); 
/* 42 */     accum
/* 43 */       .append("<!--")
/* 44 */       .append(getData())
/* 45 */       .append("-->");
/*    */   }
/*    */ 
/*    */   
/*    */   void outerHtmlTail(Appendable accum, int depth, Document.OutputSettings out) {}
/*    */   
/*    */   public String toString() {
/* 52 */     return outerHtml();
/*    */   }
/*    */ 
/*    */   
/*    */   public Comment clone() {
/* 57 */     return (Comment)super.clone();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isXmlDeclaration() {
/* 65 */     String data = getData();
/* 66 */     return isXmlDeclarationData(data);
/*    */   }
/*    */   
/*    */   private static boolean isXmlDeclarationData(String data) {
/* 70 */     return (data.length() > 1 && (data.startsWith("!") || data.startsWith("?")));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public XmlDeclaration asXmlDeclaration() {
/* 78 */     String data = getData();
/*    */     
/* 80 */     XmlDeclaration decl = null;
/* 81 */     String declContent = data.substring(1, data.length() - 1);
/*    */     
/* 83 */     if (isXmlDeclarationData(declContent)) {
/* 84 */       return null;
/*    */     }
/* 86 */     String fragment = "<" + declContent + ">";
/*    */     
/* 88 */     Document doc = Parser.htmlParser().settings(ParseSettings.preserveCase).parseInput(fragment, baseUri());
/* 89 */     if (doc.body().children().size() > 0) {
/* 90 */       Element el = doc.body().child(0);
/* 91 */       decl = new XmlDeclaration(NodeUtils.parser(doc).settings().normalizeTag(el.tagName()), data.startsWith("!"));
/* 92 */       decl.attributes().addAll(el.attributes());
/*    */     } 
/* 94 */     return decl;
/*    */   }
/*    */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\nodes\Comment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */