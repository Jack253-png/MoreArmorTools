/*      */ package org.jsoup.helper;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedWriter;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.net.CookieManager;
/*      */ import java.net.CookieStore;
/*      */ import java.net.HttpURLConnection;
/*      */ import java.net.IDN;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.Proxy;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.net.URLEncoder;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.IllegalCharsetNameException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.regex.Pattern;
/*      */ import java.util.zip.GZIPInputStream;
/*      */ import java.util.zip.Inflater;
/*      */ import java.util.zip.InflaterInputStream;
/*      */ import javax.annotation.Nullable;
/*      */ import javax.net.ssl.HttpsURLConnection;
/*      */ import javax.net.ssl.SSLSocketFactory;
/*      */ import org.jsoup.Connection;
/*      */ import org.jsoup.HttpStatusException;
/*      */ import org.jsoup.UncheckedIOException;
/*      */ import org.jsoup.UnsupportedMimeTypeException;
/*      */ import org.jsoup.internal.ConstrainableInputStream;
/*      */ import org.jsoup.internal.Normalizer;
/*      */ import org.jsoup.internal.StringUtil;
/*      */ import org.jsoup.nodes.Document;
/*      */ import org.jsoup.parser.Parser;
/*      */ import org.jsoup.parser.TokenQueue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HttpConnection
/*      */   implements Connection
/*      */ {
/*      */   public static final String CONTENT_ENCODING = "Content-Encoding";
/*      */   public static final String DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36";
/*      */   private static final String USER_AGENT = "User-Agent";
/*      */   public static final String CONTENT_TYPE = "Content-Type";
/*      */   public static final String MULTIPART_FORM_DATA = "multipart/form-data";
/*      */   public static final String FORM_URL_ENCODED = "application/x-www-form-urlencoded";
/*      */   private static final int HTTP_TEMP_REDIR = 307;
/*      */   private static final String DefaultUploadType = "application/octet-stream";
/*   71 */   private static final Charset UTF_8 = Charset.forName("UTF-8");
/*   72 */   private static final Charset ISO_8859_1 = Charset.forName("ISO-8859-1");
/*      */   
/*      */   private Request req;
/*      */   
/*      */   @Nullable
/*      */   private Connection.Response res;
/*      */   
/*      */   public static Connection connect(String url) {
/*   80 */     Connection con = new HttpConnection();
/*   81 */     con.url(url);
/*   82 */     return con;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Connection connect(URL url) {
/*   91 */     Connection con = new HttpConnection();
/*   92 */     con.url(url);
/*   93 */     return con;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpConnection() {
/*  100 */     this.req = new Request();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   HttpConnection(Request copy) {
/*  108 */     this.req = new Request(copy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String encodeUrl(String url) {
/*      */     try {
/*  118 */       URL u = new URL(url);
/*  119 */       return encodeUrl(u).toExternalForm();
/*  120 */     } catch (Exception e) {
/*  121 */       return url;
/*      */     } 
/*      */   }
/*      */   
/*      */   static URL encodeUrl(URL u) {
/*  126 */     u = punyUrl(u);
/*      */     
/*      */     try {
/*  129 */       String urlS = u.toExternalForm();
/*  130 */       urlS = urlS.replace(" ", "%20");
/*  131 */       URI uri = new URI(urlS);
/*  132 */       return new URL(uri.toASCIIString());
/*  133 */     } catch (URISyntaxException|MalformedURLException e) {
/*      */       
/*  135 */       return u;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static URL punyUrl(URL url) {
/*  145 */     if (!StringUtil.isAscii(url.getHost())) {
/*      */       try {
/*  147 */         String puny = IDN.toASCII(url.getHost());
/*  148 */         url = new URL(url.getProtocol(), puny, url.getPort(), url.getFile());
/*  149 */       } catch (MalformedURLException e) {
/*      */         
/*  151 */         throw new IllegalArgumentException(e);
/*      */       } 
/*      */     }
/*  154 */     return url;
/*      */   }
/*      */   
/*      */   private static String encodeMimeName(String val) {
/*  158 */     return val.replace("\"", "%22");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection newRequest() {
/*  167 */     return new HttpConnection(this.req);
/*      */   }
/*      */ 
/*      */   
/*      */   private HttpConnection(Request req, Response res) {
/*  172 */     this.req = req;
/*  173 */     this.res = res;
/*      */   }
/*      */   
/*      */   public Connection url(URL url) {
/*  177 */     this.req.url(url);
/*  178 */     return this;
/*      */   }
/*      */   
/*      */   public Connection url(String url) {
/*  182 */     Validate.notEmpty(url, "Must supply a valid URL");
/*      */     try {
/*  184 */       this.req.url(new URL(encodeUrl(url)));
/*  185 */     } catch (MalformedURLException e) {
/*  186 */       throw new IllegalArgumentException("Malformed URL: " + url, e);
/*      */     } 
/*  188 */     return this;
/*      */   }
/*      */   
/*      */   public Connection proxy(@Nullable Proxy proxy) {
/*  192 */     this.req.proxy(proxy);
/*  193 */     return this;
/*      */   }
/*      */   
/*      */   public Connection proxy(String host, int port) {
/*  197 */     this.req.proxy(host, port);
/*  198 */     return this;
/*      */   }
/*      */   
/*      */   public Connection userAgent(String userAgent) {
/*  202 */     Validate.notNull(userAgent, "User agent must not be null");
/*  203 */     this.req.header("User-Agent", userAgent);
/*  204 */     return this;
/*      */   }
/*      */   
/*      */   public Connection timeout(int millis) {
/*  208 */     this.req.timeout(millis);
/*  209 */     return this;
/*      */   }
/*      */   
/*      */   public Connection maxBodySize(int bytes) {
/*  213 */     this.req.maxBodySize(bytes);
/*  214 */     return this;
/*      */   }
/*      */   
/*      */   public Connection followRedirects(boolean followRedirects) {
/*  218 */     this.req.followRedirects(followRedirects);
/*  219 */     return this;
/*      */   }
/*      */   
/*      */   public Connection referrer(String referrer) {
/*  223 */     Validate.notNull(referrer, "Referrer must not be null");
/*  224 */     this.req.header("Referer", referrer);
/*  225 */     return this;
/*      */   }
/*      */   
/*      */   public Connection method(Connection.Method method) {
/*  229 */     this.req.method(method);
/*  230 */     return this;
/*      */   }
/*      */   
/*      */   public Connection ignoreHttpErrors(boolean ignoreHttpErrors) {
/*  234 */     this.req.ignoreHttpErrors(ignoreHttpErrors);
/*  235 */     return this;
/*      */   }
/*      */   
/*      */   public Connection ignoreContentType(boolean ignoreContentType) {
/*  239 */     this.req.ignoreContentType(ignoreContentType);
/*  240 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public Connection data(String key, String value) {
/*  245 */     this.req.data(KeyVal.create(key, value));
/*  246 */     return this;
/*      */   }
/*      */   
/*      */   public Connection sslSocketFactory(SSLSocketFactory sslSocketFactory) {
/*  250 */     this.req.sslSocketFactory(sslSocketFactory);
/*  251 */     return this;
/*      */   }
/*      */   
/*      */   public Connection data(String key, String filename, InputStream inputStream) {
/*  255 */     this.req.data(KeyVal.create(key, filename, inputStream));
/*  256 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public Connection data(String key, String filename, InputStream inputStream, String contentType) {
/*  261 */     this.req.data(KeyVal.create(key, filename, inputStream).contentType(contentType));
/*  262 */     return this;
/*      */   }
/*      */   
/*      */   public Connection data(Map<String, String> data) {
/*  266 */     Validate.notNull(data, "Data map must not be null");
/*  267 */     for (Map.Entry<String, String> entry : data.entrySet()) {
/*  268 */       this.req.data(KeyVal.create(entry.getKey(), entry.getValue()));
/*      */     }
/*  270 */     return this;
/*      */   }
/*      */   
/*      */   public Connection data(String... keyvals) {
/*  274 */     Validate.notNull(keyvals, "Data key value pairs must not be null");
/*  275 */     Validate.isTrue((keyvals.length % 2 == 0), "Must supply an even number of key value pairs");
/*  276 */     for (int i = 0; i < keyvals.length; i += 2) {
/*  277 */       String key = keyvals[i];
/*  278 */       String value = keyvals[i + 1];
/*  279 */       Validate.notEmpty(key, "Data key must not be empty");
/*  280 */       Validate.notNull(value, "Data value must not be null");
/*  281 */       this.req.data(KeyVal.create(key, value));
/*      */     } 
/*  283 */     return this;
/*      */   }
/*      */   
/*      */   public Connection data(Collection<Connection.KeyVal> data) {
/*  287 */     Validate.notNull(data, "Data collection must not be null");
/*  288 */     for (Connection.KeyVal entry : data) {
/*  289 */       this.req.data(entry);
/*      */     }
/*  291 */     return this;
/*      */   }
/*      */   
/*      */   public Connection.KeyVal data(String key) {
/*  295 */     Validate.notEmpty(key, "Data key must not be empty");
/*  296 */     for (Connection.KeyVal keyVal : request().data()) {
/*  297 */       if (keyVal.key().equals(key))
/*  298 */         return keyVal; 
/*      */     } 
/*  300 */     return null;
/*      */   }
/*      */   
/*      */   public Connection requestBody(String body) {
/*  304 */     this.req.requestBody(body);
/*  305 */     return this;
/*      */   }
/*      */   
/*      */   public Connection header(String name, String value) {
/*  309 */     this.req.header(name, value);
/*  310 */     return this;
/*      */   }
/*      */   
/*      */   public Connection headers(Map<String, String> headers) {
/*  314 */     Validate.notNull(headers, "Header map must not be null");
/*  315 */     for (Map.Entry<String, String> entry : headers.entrySet()) {
/*  316 */       this.req.header(entry.getKey(), entry.getValue());
/*      */     }
/*  318 */     return this;
/*      */   }
/*      */   
/*      */   public Connection cookie(String name, String value) {
/*  322 */     this.req.cookie(name, value);
/*  323 */     return this;
/*      */   }
/*      */   
/*      */   public Connection cookies(Map<String, String> cookies) {
/*  327 */     Validate.notNull(cookies, "Cookie map must not be null");
/*  328 */     for (Map.Entry<String, String> entry : cookies.entrySet()) {
/*  329 */       this.req.cookie(entry.getKey(), entry.getValue());
/*      */     }
/*  331 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection cookieStore(CookieStore cookieStore) {
/*  337 */     this.req.cookieManager = new CookieManager(cookieStore, null);
/*  338 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public CookieStore cookieStore() {
/*  343 */     return this.req.cookieManager.getCookieStore();
/*      */   }
/*      */   
/*      */   public Connection parser(Parser parser) {
/*  347 */     this.req.parser(parser);
/*  348 */     return this;
/*      */   }
/*      */   
/*      */   public Document get() throws IOException {
/*  352 */     this.req.method(Connection.Method.GET);
/*  353 */     execute();
/*  354 */     Validate.notNull(this.res);
/*  355 */     return this.res.parse();
/*      */   }
/*      */   
/*      */   public Document post() throws IOException {
/*  359 */     this.req.method(Connection.Method.POST);
/*  360 */     execute();
/*  361 */     Validate.notNull(this.res);
/*  362 */     return this.res.parse();
/*      */   }
/*      */   
/*      */   public Connection.Response execute() throws IOException {
/*  366 */     this.res = Response.execute(this.req);
/*  367 */     return this.res;
/*      */   }
/*      */   
/*      */   public Connection.Request request() {
/*  371 */     return this.req;
/*      */   }
/*      */   
/*      */   public Connection request(Connection.Request request) {
/*  375 */     this.req = (Request)request;
/*  376 */     return this;
/*      */   }
/*      */   
/*      */   public Connection.Response response() {
/*  380 */     if (this.res == null) {
/*  381 */       throw new IllegalArgumentException("You must execute the request before getting a response.");
/*      */     }
/*  383 */     return this.res;
/*      */   }
/*      */   
/*      */   public Connection response(Connection.Response response) {
/*  387 */     this.res = response;
/*  388 */     return this;
/*      */   }
/*      */   
/*      */   public Connection postDataCharset(String charset) {
/*  392 */     this.req.postDataCharset(charset);
/*  393 */     return this;
/*      */   }
/*      */   
/*      */   private static abstract class Base<T extends Connection.Base<T>>
/*      */     implements Connection.Base<T> {
/*      */     private static final URL UnsetUrl;
/*      */     
/*      */     static {
/*      */       try {
/*  402 */         UnsetUrl = new URL("http://undefined/");
/*  403 */       } catch (MalformedURLException e) {
/*  404 */         throw new IllegalStateException(e);
/*      */       } 
/*      */     }
/*      */     
/*  408 */     URL url = UnsetUrl;
/*  409 */     Connection.Method method = Connection.Method.GET;
/*      */     Map<String, List<String>> headers;
/*      */     Map<String, String> cookies;
/*      */     
/*      */     private Base() {
/*  414 */       this.headers = new LinkedHashMap<>();
/*  415 */       this.cookies = new LinkedHashMap<>();
/*      */     }
/*      */     
/*      */     private Base(Base<T> copy) {
/*  419 */       this.url = copy.url;
/*  420 */       this.method = copy.method;
/*  421 */       this.headers = new LinkedHashMap<>();
/*  422 */       for (Map.Entry<String, List<String>> entry : copy.headers.entrySet()) {
/*  423 */         this.headers.put(entry.getKey(), new ArrayList<>(entry.getValue()));
/*      */       }
/*  425 */       this.cookies = new LinkedHashMap<>(); this.cookies.putAll(copy.cookies);
/*      */     }
/*      */     
/*      */     public URL url() {
/*  429 */       if (this.url == UnsetUrl)
/*  430 */         throw new IllegalArgumentException("URL not set. Make sure to call #url(...) before executing the request."); 
/*  431 */       return this.url;
/*      */     }
/*      */     
/*      */     public T url(URL url) {
/*  435 */       Validate.notNull(url, "URL must not be null");
/*  436 */       this.url = HttpConnection.punyUrl(url);
/*  437 */       return (T)this;
/*      */     }
/*      */     
/*      */     public Connection.Method method() {
/*  441 */       return this.method;
/*      */     }
/*      */     
/*      */     public T method(Connection.Method method) {
/*  445 */       Validate.notNull(method, "Method must not be null");
/*  446 */       this.method = method;
/*  447 */       return (T)this;
/*      */     }
/*      */     
/*      */     public String header(String name) {
/*  451 */       Validate.notNull(name, "Header name must not be null");
/*  452 */       List<String> vals = getHeadersCaseInsensitive(name);
/*  453 */       if (vals.size() > 0)
/*      */       {
/*  455 */         return StringUtil.join(vals, ", ");
/*      */       }
/*      */       
/*  458 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public T addHeader(String name, String value) {
/*  463 */       Validate.notEmpty(name);
/*      */       
/*  465 */       value = (value == null) ? "" : value;
/*      */       
/*  467 */       List<String> values = headers(name);
/*  468 */       if (values.isEmpty()) {
/*  469 */         values = new ArrayList<>();
/*  470 */         this.headers.put(name, values);
/*      */       } 
/*  472 */       values.add(fixHeaderEncoding(value));
/*      */       
/*  474 */       return (T)this;
/*      */     }
/*      */ 
/*      */     
/*      */     public List<String> headers(String name) {
/*  479 */       Validate.notEmpty(name);
/*  480 */       return getHeadersCaseInsensitive(name);
/*      */     }
/*      */     
/*      */     private static String fixHeaderEncoding(String val) {
/*  484 */       byte[] bytes = val.getBytes(HttpConnection.ISO_8859_1);
/*  485 */       if (!looksLikeUtf8(bytes))
/*  486 */         return val; 
/*  487 */       return new String(bytes, HttpConnection.UTF_8);
/*      */     }
/*      */     
/*      */     private static boolean looksLikeUtf8(byte[] input) {
/*  491 */       int i = 0;
/*      */       
/*  493 */       if (input.length >= 3 && (input[0] & 0xFF) == 239 && (input[1] & 0xFF) == 187 && (input[2] & 0xFF) == 191)
/*      */       {
/*      */ 
/*      */         
/*  497 */         i = 3;
/*      */       }
/*      */ 
/*      */       
/*  501 */       for (int j = input.length; i < j; i++) {
/*  502 */         int o = input[i];
/*  503 */         if ((o & 0x80) != 0) {
/*      */           int end;
/*      */ 
/*      */ 
/*      */           
/*  508 */           if ((o & 0xE0) == 192) {
/*  509 */             end = i + 1;
/*  510 */           } else if ((o & 0xF0) == 224) {
/*  511 */             end = i + 2;
/*  512 */           } else if ((o & 0xF8) == 240) {
/*  513 */             end = i + 3;
/*      */           } else {
/*  515 */             return false;
/*      */           } 
/*      */           
/*  518 */           if (end >= input.length) {
/*  519 */             return false;
/*      */           }
/*  521 */           while (i < end) {
/*  522 */             i++;
/*  523 */             o = input[i];
/*  524 */             if ((o & 0xC0) != 128)
/*  525 */               return false; 
/*      */           } 
/*      */         } 
/*      */       } 
/*  529 */       return true;
/*      */     }
/*      */     
/*      */     public T header(String name, String value) {
/*  533 */       Validate.notEmpty(name, "Header name must not be empty");
/*  534 */       removeHeader(name);
/*  535 */       addHeader(name, value);
/*  536 */       return (T)this;
/*      */     }
/*      */     
/*      */     public boolean hasHeader(String name) {
/*  540 */       Validate.notEmpty(name, "Header name must not be empty");
/*  541 */       return !getHeadersCaseInsensitive(name).isEmpty();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasHeaderWithValue(String name, String value) {
/*  548 */       Validate.notEmpty(name);
/*  549 */       Validate.notEmpty(value);
/*  550 */       List<String> values = headers(name);
/*  551 */       for (String candidate : values) {
/*  552 */         if (value.equalsIgnoreCase(candidate))
/*  553 */           return true; 
/*      */       } 
/*  555 */       return false;
/*      */     }
/*      */     
/*      */     public T removeHeader(String name) {
/*  559 */       Validate.notEmpty(name, "Header name must not be empty");
/*  560 */       Map.Entry<String, List<String>> entry = scanHeaders(name);
/*  561 */       if (entry != null)
/*  562 */         this.headers.remove(entry.getKey()); 
/*  563 */       return (T)this;
/*      */     }
/*      */     
/*      */     public Map<String, String> headers() {
/*  567 */       LinkedHashMap<String, String> map = new LinkedHashMap<>(this.headers.size());
/*  568 */       for (Map.Entry<String, List<String>> entry : this.headers.entrySet()) {
/*  569 */         String header = entry.getKey();
/*  570 */         List<String> values = entry.getValue();
/*  571 */         if (values.size() > 0)
/*  572 */           map.put(header, values.get(0)); 
/*      */       } 
/*  574 */       return map;
/*      */     }
/*      */ 
/*      */     
/*      */     public Map<String, List<String>> multiHeaders() {
/*  579 */       return this.headers;
/*      */     }
/*      */     
/*      */     private List<String> getHeadersCaseInsensitive(String name) {
/*  583 */       Validate.notNull(name);
/*      */       
/*  585 */       for (Map.Entry<String, List<String>> entry : this.headers.entrySet()) {
/*  586 */         if (name.equalsIgnoreCase(entry.getKey())) {
/*  587 */           return entry.getValue();
/*      */         }
/*      */       } 
/*  590 */       return Collections.emptyList();
/*      */     }
/*      */     @Nullable
/*      */     private Map.Entry<String, List<String>> scanHeaders(String name) {
/*  594 */       String lc = Normalizer.lowerCase(name);
/*  595 */       for (Map.Entry<String, List<String>> entry : this.headers.entrySet()) {
/*  596 */         if (Normalizer.lowerCase(entry.getKey()).equals(lc))
/*  597 */           return entry; 
/*      */       } 
/*  599 */       return null;
/*      */     }
/*      */     
/*      */     public String cookie(String name) {
/*  603 */       Validate.notEmpty(name, "Cookie name must not be empty");
/*  604 */       return this.cookies.get(name);
/*      */     }
/*      */     
/*      */     public T cookie(String name, String value) {
/*  608 */       Validate.notEmpty(name, "Cookie name must not be empty");
/*  609 */       Validate.notNull(value, "Cookie value must not be null");
/*  610 */       this.cookies.put(name, value);
/*  611 */       return (T)this;
/*      */     }
/*      */     
/*      */     public boolean hasCookie(String name) {
/*  615 */       Validate.notEmpty(name, "Cookie name must not be empty");
/*  616 */       return this.cookies.containsKey(name);
/*      */     }
/*      */     
/*      */     public T removeCookie(String name) {
/*  620 */       Validate.notEmpty(name, "Cookie name must not be empty");
/*  621 */       this.cookies.remove(name);
/*  622 */       return (T)this;
/*      */     }
/*      */     
/*      */     public Map<String, String> cookies() {
/*  626 */       return this.cookies;
/*      */     } }
/*      */   public static class Request extends Base<Connection.Request> implements Connection.Request { @Nullable
/*      */     private Proxy proxy; private int timeoutMilliseconds;
/*      */     
/*      */     static {
/*  632 */       System.setProperty("sun.net.http.allowRestrictedHeaders", "true");
/*      */     }
/*      */ 
/*      */     
/*      */     private int maxBodySizeBytes;
/*      */     
/*      */     private boolean followRedirects;
/*      */     private final Collection<Connection.KeyVal> data;
/*      */     @Nullable
/*  641 */     private String body = null;
/*      */     private boolean ignoreHttpErrors = false;
/*      */     private boolean ignoreContentType = false;
/*      */     private Parser parser;
/*      */     private boolean parserDefined = false;
/*  646 */     private String postDataCharset = DataUtil.defaultCharsetName;
/*      */     @Nullable
/*      */     private SSLSocketFactory sslSocketFactory;
/*      */     private CookieManager cookieManager;
/*      */     private volatile boolean executing = false;
/*      */     
/*      */     Request() {
/*  653 */       this.timeoutMilliseconds = 30000;
/*  654 */       this.maxBodySizeBytes = 2097152;
/*  655 */       this.followRedirects = true;
/*  656 */       this.data = new ArrayList<>();
/*  657 */       this.method = Connection.Method.GET;
/*  658 */       addHeader("Accept-Encoding", "gzip");
/*  659 */       addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36");
/*  660 */       this.parser = Parser.htmlParser();
/*  661 */       this.cookieManager = new CookieManager();
/*      */     }
/*      */     
/*      */     Request(Request copy) {
/*  665 */       super(copy);
/*  666 */       this.proxy = copy.proxy;
/*  667 */       this.postDataCharset = copy.postDataCharset;
/*  668 */       this.timeoutMilliseconds = copy.timeoutMilliseconds;
/*  669 */       this.maxBodySizeBytes = copy.maxBodySizeBytes;
/*  670 */       this.followRedirects = copy.followRedirects;
/*  671 */       this.data = new ArrayList<>(); this.data.addAll(copy.data());
/*  672 */       this.body = copy.body;
/*  673 */       this.ignoreHttpErrors = copy.ignoreHttpErrors;
/*  674 */       this.ignoreContentType = copy.ignoreContentType;
/*  675 */       this.parser = copy.parser.newInstance();
/*  676 */       this.parserDefined = copy.parserDefined;
/*  677 */       this.sslSocketFactory = copy.sslSocketFactory;
/*  678 */       this.cookieManager = copy.cookieManager;
/*  679 */       this.executing = false;
/*      */     }
/*      */     
/*      */     public Proxy proxy() {
/*  683 */       return this.proxy;
/*      */     }
/*      */     
/*      */     public Request proxy(@Nullable Proxy proxy) {
/*  687 */       this.proxy = proxy;
/*  688 */       return this;
/*      */     }
/*      */     
/*      */     public Request proxy(String host, int port) {
/*  692 */       this.proxy = new Proxy(Proxy.Type.HTTP, InetSocketAddress.createUnresolved(host, port));
/*  693 */       return this;
/*      */     }
/*      */     
/*      */     public int timeout() {
/*  697 */       return this.timeoutMilliseconds;
/*      */     }
/*      */     
/*      */     public Request timeout(int millis) {
/*  701 */       Validate.isTrue((millis >= 0), "Timeout milliseconds must be 0 (infinite) or greater");
/*  702 */       this.timeoutMilliseconds = millis;
/*  703 */       return this;
/*      */     }
/*      */     
/*      */     public int maxBodySize() {
/*  707 */       return this.maxBodySizeBytes;
/*      */     }
/*      */     
/*      */     public Connection.Request maxBodySize(int bytes) {
/*  711 */       Validate.isTrue((bytes >= 0), "maxSize must be 0 (unlimited) or larger");
/*  712 */       this.maxBodySizeBytes = bytes;
/*  713 */       return this;
/*      */     }
/*      */     
/*      */     public boolean followRedirects() {
/*  717 */       return this.followRedirects;
/*      */     }
/*      */     
/*      */     public Connection.Request followRedirects(boolean followRedirects) {
/*  721 */       this.followRedirects = followRedirects;
/*  722 */       return this;
/*      */     }
/*      */     
/*      */     public boolean ignoreHttpErrors() {
/*  726 */       return this.ignoreHttpErrors;
/*      */     }
/*      */     
/*      */     public SSLSocketFactory sslSocketFactory() {
/*  730 */       return this.sslSocketFactory;
/*      */     }
/*      */     
/*      */     public void sslSocketFactory(SSLSocketFactory sslSocketFactory) {
/*  734 */       this.sslSocketFactory = sslSocketFactory;
/*      */     }
/*      */     
/*      */     public Connection.Request ignoreHttpErrors(boolean ignoreHttpErrors) {
/*  738 */       this.ignoreHttpErrors = ignoreHttpErrors;
/*  739 */       return this;
/*      */     }
/*      */     
/*      */     public boolean ignoreContentType() {
/*  743 */       return this.ignoreContentType;
/*      */     }
/*      */     
/*      */     public Connection.Request ignoreContentType(boolean ignoreContentType) {
/*  747 */       this.ignoreContentType = ignoreContentType;
/*  748 */       return this;
/*      */     }
/*      */     
/*      */     public Request data(Connection.KeyVal keyval) {
/*  752 */       Validate.notNull(keyval, "Key val must not be null");
/*  753 */       this.data.add(keyval);
/*  754 */       return this;
/*      */     }
/*      */     
/*      */     public Collection<Connection.KeyVal> data() {
/*  758 */       return this.data;
/*      */     }
/*      */     
/*      */     public Connection.Request requestBody(@Nullable String body) {
/*  762 */       this.body = body;
/*  763 */       return this;
/*      */     }
/*      */     
/*      */     public String requestBody() {
/*  767 */       return this.body;
/*      */     }
/*      */     
/*      */     public Request parser(Parser parser) {
/*  771 */       this.parser = parser;
/*  772 */       this.parserDefined = true;
/*  773 */       return this;
/*      */     }
/*      */     
/*      */     public Parser parser() {
/*  777 */       return this.parser;
/*      */     }
/*      */     
/*      */     public Connection.Request postDataCharset(String charset) {
/*  781 */       Validate.notNull(charset, "Charset must not be null");
/*  782 */       if (!Charset.isSupported(charset)) throw new IllegalCharsetNameException(charset); 
/*  783 */       this.postDataCharset = charset;
/*  784 */       return this;
/*      */     }
/*      */     
/*      */     public String postDataCharset() {
/*  788 */       return this.postDataCharset;
/*      */     }
/*      */     
/*      */     CookieManager cookieManager() {
/*  792 */       return this.cookieManager;
/*      */     } }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Response
/*      */     extends Base<Connection.Response>
/*      */     implements Connection.Response
/*      */   {
/*      */     private static final int MAX_REDIRECTS = 20;
/*      */     
/*      */     private static final String LOCATION = "Location";
/*      */     private final int statusCode;
/*      */     private final String statusMessage;
/*      */     @Nullable
/*      */     private ByteBuffer byteData;
/*  808 */     private int numRedirects = 0; @Nullable
/*      */     private InputStream bodyStream; @Nullable
/*      */     private HttpURLConnection conn; @Nullable
/*      */     private String charset; @Nullable
/*      */     private final String contentType; private boolean executed = false; private boolean inputStreamRead = false;
/*      */     private final HttpConnection.Request req;
/*  814 */     private static final Pattern xmlContentTypeRxp = Pattern.compile("(application|text)/\\w*\\+?xml.*");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Response() {
/*  822 */       this.statusCode = 400;
/*  823 */       this.statusMessage = "Request not made";
/*  824 */       this.req = new HttpConnection.Request();
/*  825 */       this.contentType = null;
/*      */     }
/*      */     
/*      */     static Response execute(HttpConnection.Request req) throws IOException {
/*  829 */       return execute(req, (Response)null);
/*      */     }
/*      */     
/*      */     static Response execute(HttpConnection.Request req, @Nullable Response previousResponse) throws IOException {
/*  833 */       synchronized (req) {
/*  834 */         Validate.isFalse(req.executing, "Multiple threads were detected trying to execute the same request concurrently. Make sure to use Connection#newRequest() and do not share an executing request between threads.");
/*  835 */         req.executing = true;
/*      */       } 
/*  837 */       Validate.notNull(req, "Request must not be null");
/*  838 */       URL url = req.url();
/*  839 */       Validate.notNull(url, "URL must be specified to connect");
/*  840 */       String protocol = url.getProtocol();
/*  841 */       if (!protocol.equals("http") && !protocol.equals("https"))
/*  842 */         throw new MalformedURLException("Only http & https protocols supported"); 
/*  843 */       boolean methodHasBody = req.method().hasBody();
/*  844 */       boolean hasRequestBody = (req.requestBody() != null);
/*  845 */       if (!methodHasBody) {
/*  846 */         Validate.isFalse(hasRequestBody, "Cannot set a request body for HTTP method " + req.method());
/*      */       }
/*      */       
/*  849 */       String mimeBoundary = null;
/*  850 */       if (req.data().size() > 0 && (!methodHasBody || hasRequestBody)) {
/*  851 */         serialiseRequestUrl(req);
/*  852 */       } else if (methodHasBody) {
/*  853 */         mimeBoundary = setOutputContentType(req);
/*      */       } 
/*  855 */       long startTime = System.nanoTime();
/*  856 */       HttpURLConnection conn = createConnection(req);
/*  857 */       Response res = null;
/*      */       try {
/*  859 */         conn.connect();
/*  860 */         if (conn.getDoOutput()) {
/*  861 */           OutputStream out = conn.getOutputStream(); 
/*  862 */           try { writePost(req, out, mimeBoundary); }
/*  863 */           catch (IOException e) { conn.disconnect(); throw e; }
/*  864 */           finally { out.close(); }
/*      */         
/*      */         } 
/*  867 */         int status = conn.getResponseCode();
/*  868 */         res = new Response(conn, req, previousResponse);
/*      */ 
/*      */         
/*  871 */         if (res.hasHeader("Location") && req.followRedirects()) {
/*  872 */           if (status != 307) {
/*  873 */             req.method(Connection.Method.GET);
/*  874 */             req.data().clear();
/*  875 */             req.requestBody(null);
/*  876 */             req.removeHeader("Content-Type");
/*      */           } 
/*      */           
/*  879 */           String location = res.header("Location");
/*  880 */           Validate.notNull(location);
/*  881 */           if (location.startsWith("http:/") && location.charAt(6) != '/')
/*  882 */             location = location.substring(6); 
/*  883 */           URL redir = StringUtil.resolve(req.url(), location);
/*  884 */           req.url(HttpConnection.encodeUrl(redir));
/*      */           
/*  886 */           req.executing = false;
/*  887 */           return execute(req, res);
/*      */         } 
/*  889 */         if ((status < 200 || status >= 400) && !req.ignoreHttpErrors()) {
/*  890 */           throw new HttpStatusException("HTTP error fetching URL", status, req.url().toString());
/*      */         }
/*      */         
/*  893 */         String contentType = res.contentType();
/*  894 */         if (contentType != null && 
/*  895 */           !req.ignoreContentType() && 
/*  896 */           !contentType.startsWith("text/") && 
/*  897 */           !xmlContentTypeRxp.matcher(contentType).matches())
/*      */         {
/*  899 */           throw new UnsupportedMimeTypeException("Unhandled content type. Must be text/*, application/xml, or application/*+xml", contentType, req
/*  900 */               .url().toString());
/*      */         }
/*      */         
/*  903 */         if (contentType != null && xmlContentTypeRxp.matcher(contentType).matches() && 
/*  904 */           !req.parserDefined) req.parser(Parser.xmlParser());
/*      */ 
/*      */         
/*  907 */         res.charset = DataUtil.getCharsetFromContentType(res.contentType);
/*  908 */         if (conn.getContentLength() != 0 && req.method() != Connection.Method.HEAD) {
/*  909 */           res.bodyStream = (conn.getErrorStream() != null) ? conn.getErrorStream() : conn.getInputStream();
/*  910 */           Validate.notNull(res.bodyStream);
/*  911 */           if (res.hasHeaderWithValue("Content-Encoding", "gzip")) {
/*  912 */             res.bodyStream = new GZIPInputStream(res.bodyStream);
/*  913 */           } else if (res.hasHeaderWithValue("Content-Encoding", "deflate")) {
/*  914 */             res.bodyStream = new InflaterInputStream(res.bodyStream, new Inflater(true));
/*      */           } 
/*  916 */           res
/*      */             
/*  918 */             .bodyStream = (InputStream)ConstrainableInputStream.wrap(res.bodyStream, 32768, req.maxBodySize()).timeout(startTime, req.timeout());
/*      */         } else {
/*      */           
/*  921 */           res.byteData = DataUtil.emptyByteBuffer();
/*      */         } 
/*  923 */       } catch (IOException e) {
/*  924 */         if (res != null) res.safeClose(); 
/*  925 */         throw e;
/*      */       } finally {
/*  927 */         req.executing = false;
/*      */       } 
/*      */       
/*  930 */       res.executed = true;
/*  931 */       return res;
/*      */     }
/*      */     
/*      */     public int statusCode() {
/*  935 */       return this.statusCode;
/*      */     }
/*      */     
/*      */     public String statusMessage() {
/*  939 */       return this.statusMessage;
/*      */     }
/*      */     
/*      */     public String charset() {
/*  943 */       return this.charset;
/*      */     }
/*      */     
/*      */     public Response charset(String charset) {
/*  947 */       this.charset = charset;
/*  948 */       return this;
/*      */     }
/*      */     
/*      */     public String contentType() {
/*  952 */       return this.contentType;
/*      */     }
/*      */     
/*      */     public Document parse() throws IOException {
/*  956 */       Validate.isTrue(this.executed, "Request must be executed (with .execute(), .get(), or .post() before parsing response");
/*  957 */       if (this.byteData != null) {
/*  958 */         this.bodyStream = new ByteArrayInputStream(this.byteData.array());
/*  959 */         this.inputStreamRead = false;
/*      */       } 
/*  961 */       Validate.isFalse(this.inputStreamRead, "Input stream already read and parsed, cannot re-read.");
/*  962 */       Document doc = DataUtil.parseInputStream(this.bodyStream, this.charset, this.url.toExternalForm(), this.req.parser());
/*  963 */       doc.connection(new HttpConnection(this.req, this));
/*  964 */       this.charset = doc.outputSettings().charset().name();
/*  965 */       this.inputStreamRead = true;
/*  966 */       safeClose();
/*  967 */       return doc;
/*      */     }
/*      */     
/*      */     private void prepareByteData() {
/*  971 */       Validate.isTrue(this.executed, "Request must be executed (with .execute(), .get(), or .post() before getting response body");
/*  972 */       if (this.bodyStream != null && this.byteData == null) {
/*  973 */         Validate.isFalse(this.inputStreamRead, "Request has already been read (with .parse())");
/*      */         try {
/*  975 */           this.byteData = DataUtil.readToByteBuffer(this.bodyStream, this.req.maxBodySize());
/*  976 */         } catch (IOException e) {
/*  977 */           throw new UncheckedIOException(e);
/*      */         } finally {
/*  979 */           this.inputStreamRead = true;
/*  980 */           safeClose();
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public String body() {
/*  986 */       prepareByteData();
/*  987 */       Validate.notNull(this.byteData);
/*      */ 
/*      */       
/*  990 */       String body = ((this.charset == null) ? DataUtil.UTF_8 : Charset.forName(this.charset)).decode(this.byteData).toString();
/*  991 */       this.byteData.rewind();
/*  992 */       return body;
/*      */     }
/*      */     
/*      */     public byte[] bodyAsBytes() {
/*  996 */       prepareByteData();
/*  997 */       Validate.notNull(this.byteData);
/*  998 */       return this.byteData.array();
/*      */     }
/*      */ 
/*      */     
/*      */     public Connection.Response bufferUp() {
/* 1003 */       prepareByteData();
/* 1004 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public BufferedInputStream bodyStream() {
/* 1009 */       Validate.isTrue(this.executed, "Request must be executed (with .execute(), .get(), or .post() before getting response body");
/* 1010 */       Validate.isFalse(this.inputStreamRead, "Request has already been read");
/* 1011 */       this.inputStreamRead = true;
/* 1012 */       return (BufferedInputStream)ConstrainableInputStream.wrap(this.bodyStream, 32768, this.req.maxBodySize());
/*      */     }
/*      */ 
/*      */     
/*      */     private static HttpURLConnection createConnection(HttpConnection.Request req) throws IOException {
/* 1017 */       Proxy proxy = req.proxy();
/*      */ 
/*      */ 
/*      */       
/* 1021 */       HttpURLConnection conn = (proxy == null) ? (HttpURLConnection)req.url().openConnection() : (HttpURLConnection)req.url().openConnection(proxy);
/*      */ 
/*      */       
/* 1024 */       conn.setRequestMethod(req.method().name());
/* 1025 */       conn.setInstanceFollowRedirects(false);
/* 1026 */       conn.setConnectTimeout(req.timeout());
/* 1027 */       conn.setReadTimeout(req.timeout() / 2);
/*      */       
/* 1029 */       if (req.sslSocketFactory() != null && conn instanceof HttpsURLConnection)
/* 1030 */         ((HttpsURLConnection)conn).setSSLSocketFactory(req.sslSocketFactory()); 
/* 1031 */       if (req.method().hasBody())
/* 1032 */         conn.setDoOutput(true); 
/* 1033 */       CookieUtil.applyCookiesToRequest(req, conn);
/* 1034 */       for (Map.Entry<String, List<String>> header : (Iterable<Map.Entry<String, List<String>>>)req.multiHeaders().entrySet()) {
/* 1035 */         for (String value : header.getValue()) {
/* 1036 */           conn.addRequestProperty(header.getKey(), value);
/*      */         }
/*      */       } 
/* 1039 */       return conn;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void safeClose() {
/* 1047 */       if (this.bodyStream != null) {
/*      */         try {
/* 1049 */           this.bodyStream.close();
/* 1050 */         } catch (IOException iOException) {
/*      */         
/*      */         } finally {
/* 1053 */           this.bodyStream = null;
/*      */         } 
/*      */       }
/* 1056 */       if (this.conn != null) {
/* 1057 */         this.conn.disconnect();
/* 1058 */         this.conn = null;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private Response(HttpURLConnection conn, HttpConnection.Request request, @Nullable Response previousResponse) throws IOException {
/* 1064 */       this.conn = conn;
/* 1065 */       this.req = request;
/* 1066 */       this.method = Connection.Method.valueOf(conn.getRequestMethod());
/* 1067 */       this.url = conn.getURL();
/* 1068 */       this.statusCode = conn.getResponseCode();
/* 1069 */       this.statusMessage = conn.getResponseMessage();
/* 1070 */       this.contentType = conn.getContentType();
/*      */       
/* 1072 */       Map<String, List<String>> resHeaders = createHeaderMap(conn);
/* 1073 */       processResponseHeaders(resHeaders);
/* 1074 */       CookieUtil.storeCookies(this.req, this.url, resHeaders);
/*      */       
/* 1076 */       if (previousResponse != null) {
/*      */         
/* 1078 */         for (Map.Entry<String, String> prevCookie : (Iterable<Map.Entry<String, String>>)previousResponse.cookies().entrySet()) {
/* 1079 */           if (!hasCookie(prevCookie.getKey()))
/* 1080 */             cookie(prevCookie.getKey(), prevCookie.getValue()); 
/*      */         } 
/* 1082 */         previousResponse.safeClose();
/*      */ 
/*      */         
/* 1085 */         previousResponse.numRedirects++;
/* 1086 */         if (this.numRedirects >= 20) {
/* 1087 */           throw new IOException(String.format("Too many redirects occurred trying to load URL %s", new Object[] { previousResponse.url() }));
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     private static LinkedHashMap<String, List<String>> createHeaderMap(HttpURLConnection conn) {
/* 1093 */       LinkedHashMap<String, List<String>> headers = new LinkedHashMap<>();
/* 1094 */       int i = 0;
/*      */       while (true) {
/* 1096 */         String key = conn.getHeaderFieldKey(i);
/* 1097 */         String val = conn.getHeaderField(i);
/* 1098 */         if (key == null && val == null)
/*      */           break; 
/* 1100 */         i++;
/* 1101 */         if (key == null || val == null) {
/*      */           continue;
/*      */         }
/* 1104 */         if (headers.containsKey(key)) {
/* 1105 */           ((List<String>)headers.get(key)).add(val); continue;
/*      */         } 
/* 1107 */         ArrayList<String> vals = new ArrayList<>();
/* 1108 */         vals.add(val);
/* 1109 */         headers.put(key, vals);
/*      */       } 
/*      */       
/* 1112 */       return headers;
/*      */     }
/*      */     
/*      */     void processResponseHeaders(Map<String, List<String>> resHeaders) {
/* 1116 */       for (Map.Entry<String, List<String>> entry : resHeaders.entrySet()) {
/* 1117 */         String name = entry.getKey();
/* 1118 */         if (name == null) {
/*      */           continue;
/*      */         }
/* 1121 */         List<String> values = entry.getValue();
/* 1122 */         if (name.equalsIgnoreCase("Set-Cookie"))
/* 1123 */           for (String value : values) {
/* 1124 */             if (value == null)
/*      */               continue; 
/* 1126 */             TokenQueue cd = new TokenQueue(value);
/* 1127 */             String cookieName = cd.chompTo("=").trim();
/* 1128 */             String cookieVal = cd.consumeTo(";").trim();
/*      */ 
/*      */             
/* 1131 */             if (cookieName.length() > 0 && !this.cookies.containsKey(cookieName)) {
/* 1132 */               cookie(cookieName, cookieVal);
/*      */             }
/*      */           }  
/* 1135 */         for (String value : values)
/* 1136 */           addHeader(name, value); 
/*      */       } 
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     private static String setOutputContentType(Connection.Request req) {
/* 1142 */       String contentType = req.header("Content-Type");
/* 1143 */       String bound = null;
/* 1144 */       if (contentType != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1149 */         if (contentType.contains("multipart/form-data") && !contentType.contains("boundary")) {
/* 1150 */           bound = DataUtil.mimeBoundary();
/* 1151 */           req.header("Content-Type", "multipart/form-data; boundary=" + bound);
/*      */         }
/*      */       
/*      */       }
/* 1155 */       else if (HttpConnection.needsMultipart(req)) {
/* 1156 */         bound = DataUtil.mimeBoundary();
/* 1157 */         req.header("Content-Type", "multipart/form-data; boundary=" + bound);
/*      */       } else {
/* 1159 */         req.header("Content-Type", "application/x-www-form-urlencoded; charset=" + req.postDataCharset());
/*      */       } 
/* 1161 */       return bound;
/*      */     }
/*      */     
/*      */     private static void writePost(Connection.Request req, OutputStream outputStream, @Nullable String boundary) throws IOException {
/* 1165 */       Collection<Connection.KeyVal> data = req.data();
/* 1166 */       BufferedWriter w = new BufferedWriter(new OutputStreamWriter(outputStream, req.postDataCharset()));
/*      */       
/* 1168 */       if (boundary != null) {
/*      */         
/* 1170 */         for (Connection.KeyVal keyVal : data) {
/* 1171 */           w.write("--");
/* 1172 */           w.write(boundary);
/* 1173 */           w.write("\r\n");
/* 1174 */           w.write("Content-Disposition: form-data; name=\"");
/* 1175 */           w.write(HttpConnection.encodeMimeName(keyVal.key()));
/* 1176 */           w.write("\"");
/* 1177 */           InputStream input = keyVal.inputStream();
/* 1178 */           if (input != null) {
/* 1179 */             w.write("; filename=\"");
/* 1180 */             w.write(HttpConnection.encodeMimeName(keyVal.value()));
/* 1181 */             w.write("\"\r\nContent-Type: ");
/* 1182 */             String contentType = keyVal.contentType();
/* 1183 */             w.write((contentType != null) ? contentType : "application/octet-stream");
/* 1184 */             w.write("\r\n\r\n");
/* 1185 */             w.flush();
/* 1186 */             DataUtil.crossStreams(input, outputStream);
/* 1187 */             outputStream.flush();
/*      */           } else {
/* 1189 */             w.write("\r\n\r\n");
/* 1190 */             w.write(keyVal.value());
/*      */           } 
/* 1192 */           w.write("\r\n");
/*      */         } 
/* 1194 */         w.write("--");
/* 1195 */         w.write(boundary);
/* 1196 */         w.write("--");
/*      */       } else {
/* 1198 */         String body = req.requestBody();
/* 1199 */         if (body != null) {
/*      */           
/* 1201 */           w.write(body);
/*      */         }
/*      */         else {
/*      */           
/* 1205 */           boolean first = true;
/* 1206 */           for (Connection.KeyVal keyVal : data) {
/* 1207 */             if (!first) {
/* 1208 */               w.append('&');
/*      */             } else {
/* 1210 */               first = false;
/*      */             } 
/* 1212 */             w.write(URLEncoder.encode(keyVal.key(), req.postDataCharset()));
/* 1213 */             w.write(61);
/* 1214 */             w.write(URLEncoder.encode(keyVal.value(), req.postDataCharset()));
/*      */           } 
/*      */         } 
/*      */       } 
/* 1218 */       w.close();
/*      */     }
/*      */ 
/*      */     
/*      */     private static void serialiseRequestUrl(Connection.Request req) throws IOException {
/* 1223 */       URL in = req.url();
/* 1224 */       StringBuilder url = StringUtil.borrowBuilder();
/* 1225 */       boolean first = true;
/*      */       
/* 1227 */       url
/* 1228 */         .append(in.getProtocol())
/* 1229 */         .append("://")
/* 1230 */         .append(in.getAuthority())
/* 1231 */         .append(in.getPath())
/* 1232 */         .append("?");
/* 1233 */       if (in.getQuery() != null) {
/* 1234 */         url.append(in.getQuery());
/* 1235 */         first = false;
/*      */       } 
/* 1237 */       for (Connection.KeyVal keyVal : req.data()) {
/* 1238 */         Validate.isFalse(keyVal.hasInputStream(), "InputStream data not supported in URL query string.");
/* 1239 */         if (!first) {
/* 1240 */           url.append('&');
/*      */         } else {
/* 1242 */           first = false;
/* 1243 */         }  url
/* 1244 */           .append(URLEncoder.encode(keyVal.key(), DataUtil.defaultCharsetName))
/* 1245 */           .append('=')
/* 1246 */           .append(URLEncoder.encode(keyVal.value(), DataUtil.defaultCharsetName));
/*      */       } 
/* 1248 */       req.url(new URL(StringUtil.releaseBuilder(url)));
/* 1249 */       req.data().clear();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean needsMultipart(Connection.Request req) {
/* 1255 */     for (Connection.KeyVal keyVal : req.data()) {
/* 1256 */       if (keyVal.hasInputStream())
/* 1257 */         return true; 
/*      */     } 
/* 1259 */     return false;
/*      */   }
/*      */   public static class KeyVal implements Connection.KeyVal { private String key;
/*      */     private String value;
/*      */     @Nullable
/*      */     private InputStream stream;
/*      */     @Nullable
/*      */     private String contentType;
/*      */     
/*      */     public static KeyVal create(String key, String value) {
/* 1269 */       return new KeyVal(key, value);
/*      */     }
/*      */     
/*      */     public static KeyVal create(String key, String filename, InputStream stream) {
/* 1273 */       return (new KeyVal(key, filename))
/* 1274 */         .inputStream(stream);
/*      */     }
/*      */     
/*      */     private KeyVal(String key, String value) {
/* 1278 */       Validate.notEmpty(key, "Data key must not be empty");
/* 1279 */       Validate.notNull(value, "Data value must not be null");
/* 1280 */       this.key = key;
/* 1281 */       this.value = value;
/*      */     }
/*      */     
/*      */     public KeyVal key(String key) {
/* 1285 */       Validate.notEmpty(key, "Data key must not be empty");
/* 1286 */       this.key = key;
/* 1287 */       return this;
/*      */     }
/*      */     
/*      */     public String key() {
/* 1291 */       return this.key;
/*      */     }
/*      */     
/*      */     public KeyVal value(String value) {
/* 1295 */       Validate.notNull(value, "Data value must not be null");
/* 1296 */       this.value = value;
/* 1297 */       return this;
/*      */     }
/*      */     
/*      */     public String value() {
/* 1301 */       return this.value;
/*      */     }
/*      */     
/*      */     public KeyVal inputStream(InputStream inputStream) {
/* 1305 */       Validate.notNull(this.value, "Data input stream must not be null");
/* 1306 */       this.stream = inputStream;
/* 1307 */       return this;
/*      */     }
/*      */     
/*      */     public InputStream inputStream() {
/* 1311 */       return this.stream;
/*      */     }
/*      */     
/*      */     public boolean hasInputStream() {
/* 1315 */       return (this.stream != null);
/*      */     }
/*      */ 
/*      */     
/*      */     public Connection.KeyVal contentType(String contentType) {
/* 1320 */       Validate.notEmpty(contentType);
/* 1321 */       this.contentType = contentType;
/* 1322 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public String contentType() {
/* 1327 */       return this.contentType;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1332 */       return this.key + "=" + this.value;
/*      */     } }
/*      */ 
/*      */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\helper\HttpConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */