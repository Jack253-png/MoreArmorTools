/*     */ package org.jsoup.helper;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Validate
/*     */ {
/*     */   public static void notNull(@Nullable Object obj) {
/*  17 */     if (obj == null) {
/*  18 */       throw new IllegalArgumentException("Object must not be null");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void notNull(@Nullable Object obj, String msg) {
/*  27 */     if (obj == null) {
/*  28 */       throw new IllegalArgumentException(msg);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void isTrue(boolean val) {
/*  36 */     if (!val) {
/*  37 */       throw new IllegalArgumentException("Must be true");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void isTrue(boolean val, String msg) {
/*  46 */     if (!val) {
/*  47 */       throw new IllegalArgumentException(msg);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void isFalse(boolean val) {
/*  55 */     if (val) {
/*  56 */       throw new IllegalArgumentException("Must be false");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void isFalse(boolean val, String msg) {
/*  65 */     if (val) {
/*  66 */       throw new IllegalArgumentException(msg);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void noNullElements(Object[] objects) {
/*  74 */     noNullElements(objects, "Array must not contain any null objects");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void noNullElements(Object[] objects, String msg) {
/*  83 */     for (Object obj : objects) {
/*  84 */       if (obj == null) {
/*  85 */         throw new IllegalArgumentException(msg);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void notEmpty(@Nullable String string) {
/*  93 */     if (string == null || string.length() == 0) {
/*  94 */       throw new IllegalArgumentException("String must not be empty");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void notEmpty(@Nullable String string, String msg) {
/* 103 */     if (string == null || string.length() == 0) {
/* 104 */       throw new IllegalArgumentException(msg);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void wtf(String msg) {
/* 112 */     throw new IllegalStateException(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void fail(String msg) {
/* 120 */     throw new IllegalArgumentException(msg);
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\helper\Validate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */