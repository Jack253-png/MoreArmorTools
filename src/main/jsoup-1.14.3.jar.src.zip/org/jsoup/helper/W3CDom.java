/*     */ package org.jsoup.helper;
/*     */ 
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Stack;
/*     */ import javax.annotation.Nullable;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.xpath.XPathConstants;
/*     */ import javax.xml.xpath.XPathException;
/*     */ import javax.xml.xpath.XPathExpression;
/*     */ import javax.xml.xpath.XPathExpressionException;
/*     */ import javax.xml.xpath.XPathFactory;
/*     */ import org.jsoup.internal.StringUtil;
/*     */ import org.jsoup.nodes.Attribute;
/*     */ import org.jsoup.nodes.Attributes;
/*     */ import org.jsoup.nodes.Comment;
/*     */ import org.jsoup.nodes.DataNode;
/*     */ import org.jsoup.nodes.Document;
/*     */ import org.jsoup.nodes.DocumentType;
/*     */ import org.jsoup.nodes.Element;
/*     */ import org.jsoup.nodes.Node;
/*     */ import org.jsoup.nodes.TextNode;
/*     */ import org.jsoup.select.NodeTraversor;
/*     */ import org.jsoup.select.NodeVisitor;
/*     */ import org.jsoup.select.Selector;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.DOMImplementation;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.DocumentType;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class W3CDom
/*     */ {
/*     */   public static final String SourceProperty = "jsoupSource";
/*     */   public static final String XPathFactoryProperty = "javax.xml.xpath.XPathFactory:jsoup";
/*     */   protected DocumentBuilderFactory factory;
/*     */   
/*     */   public W3CDom() {
/*  63 */     this.factory = DocumentBuilderFactory.newInstance();
/*  64 */     this.factory.setNamespaceAware(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document convert(Document in) {
/*  74 */     return (new W3CDom()).fromJsoup(in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String asString(Document doc, @Nullable Map<String, String> properties) {
/*     */     try {
/* 100 */       DOMSource domSource = new DOMSource(doc);
/* 101 */       StringWriter writer = new StringWriter();
/* 102 */       StreamResult result = new StreamResult(writer);
/* 103 */       TransformerFactory tf = TransformerFactory.newInstance();
/* 104 */       Transformer transformer = tf.newTransformer();
/* 105 */       if (properties != null) {
/* 106 */         transformer.setOutputProperties(propertiesFromMap(properties));
/*     */       }
/* 108 */       if (doc.getDoctype() != null) {
/* 109 */         DocumentType doctype = doc.getDoctype();
/* 110 */         if (!StringUtil.isBlank(doctype.getPublicId()))
/* 111 */           transformer.setOutputProperty("doctype-public", doctype.getPublicId()); 
/* 112 */         if (!StringUtil.isBlank(doctype.getSystemId())) {
/* 113 */           transformer.setOutputProperty("doctype-system", doctype.getSystemId());
/*     */         }
/* 115 */         else if (doctype.getName().equalsIgnoreCase("html") && 
/* 116 */           StringUtil.isBlank(doctype.getPublicId()) && 
/* 117 */           StringUtil.isBlank(doctype.getSystemId())) {
/* 118 */           transformer.setOutputProperty("doctype-system", "about:legacy-compat");
/*     */         } 
/*     */       } 
/* 121 */       transformer.transform(domSource, result);
/* 122 */       return writer.toString();
/*     */     }
/* 124 */     catch (TransformerException e) {
/* 125 */       throw new IllegalStateException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   static Properties propertiesFromMap(Map<String, String> map) {
/* 130 */     Properties props = new Properties();
/* 131 */     props.putAll(map);
/* 132 */     return props;
/*     */   }
/*     */ 
/*     */   
/*     */   public static HashMap<String, String> OutputHtml() {
/* 137 */     return methodMap("html");
/*     */   }
/*     */ 
/*     */   
/*     */   public static HashMap<String, String> OutputXml() {
/* 142 */     return methodMap("xml");
/*     */   }
/*     */   
/*     */   private static HashMap<String, String> methodMap(String method) {
/* 146 */     HashMap<String, String> map = new HashMap<>();
/* 147 */     map.put("method", method);
/* 148 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document fromJsoup(Document in) {
/* 161 */     return fromJsoup((Element)in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document fromJsoup(Element in) {
/* 173 */     Validate.notNull(in);
/*     */     
/*     */     try {
/* 176 */       DocumentBuilder builder = this.factory.newDocumentBuilder();
/* 177 */       DOMImplementation impl = builder.getDOMImplementation();
/*     */ 
/*     */       
/* 180 */       Document out = builder.newDocument();
/* 181 */       Document inDoc = in.ownerDocument();
/* 182 */       DocumentType doctype = (inDoc != null) ? inDoc.documentType() : null;
/* 183 */       if (doctype != null) {
/* 184 */         DocumentType documentType = impl.createDocumentType(doctype.name(), doctype.publicId(), doctype.systemId());
/* 185 */         out.appendChild(documentType);
/*     */       } 
/* 187 */       out.setXmlStandalone(true);
/*     */       
/* 189 */       convert(in, out);
/* 190 */       return out;
/* 191 */     } catch (ParserConfigurationException e) {
/* 192 */       throw new IllegalStateException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void convert(Document in, Document out) {
/* 206 */     convert((Element)in, out);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void convert(Element in, Document out) {
/* 218 */     Document inDoc = in.ownerDocument();
/* 219 */     if (inDoc != null && 
/* 220 */       !StringUtil.isBlank(inDoc.location())) {
/* 221 */       out.setDocumentURI(inDoc.location());
/*     */     }
/*     */     
/* 224 */     Element rootEl = (in instanceof Document) ? in.child(0) : in;
/* 225 */     NodeTraversor.traverse(new W3CBuilder(out), (Node)rootEl);
/*     */   }
/*     */   public NodeList selectXpath(String xpath, Document doc) {
/*     */     NodeList nodeList;
/* 229 */     Validate.notEmpty(xpath);
/* 230 */     Validate.notNull(doc);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 235 */       String property = System.getProperty("javax.xml.xpath.XPathFactory:jsoup");
/*     */ 
/*     */       
/* 238 */       XPathFactory xPathFactory = (property != null) ? XPathFactory.newInstance("jsoup") : XPathFactory.newInstance();
/*     */       
/* 240 */       XPathExpression expression = xPathFactory.newXPath().compile(xpath);
/* 241 */       nodeList = (NodeList)expression.evaluate(doc, XPathConstants.NODESET);
/* 242 */       Validate.notNull(nodeList);
/* 243 */     } catch (XPathExpressionException|javax.xml.xpath.XPathFactoryConfigurationException e) {
/* 244 */       throw new Selector.SelectorParseException("Could not evaluate XPath query [%s]: %s", new Object[] { xpath, e.getMessage() });
/*     */     } 
/* 246 */     return nodeList;
/*     */   }
/*     */   
/*     */   public <T extends Node> List<T> sourceNodes(NodeList nodeList, Class<T> nodeType) {
/* 250 */     Validate.notNull(nodeList);
/* 251 */     Validate.notNull(nodeType);
/* 252 */     List<T> nodes = new ArrayList<>(nodeList.getLength());
/*     */     
/* 254 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 255 */       Node node = nodeList.item(i);
/* 256 */       Object source = node.getUserData("jsoupSource");
/* 257 */       if (nodeType.isInstance(source)) {
/* 258 */         nodes.add(nodeType.cast(source));
/*     */       }
/*     */     } 
/* 261 */     return nodes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String asString(Document doc) {
/* 272 */     return asString(doc, null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static class W3CBuilder
/*     */     implements NodeVisitor
/*     */   {
/*     */     private static final String xmlnsKey = "xmlns";
/*     */     
/*     */     private static final String xmlnsPrefix = "xmlns:";
/*     */     private final Document doc;
/* 283 */     private final Stack<HashMap<String, String>> namespacesStack = new Stack<>();
/*     */     private Node dest;
/*     */     
/*     */     public W3CBuilder(Document doc) {
/* 287 */       this.doc = doc;
/* 288 */       this.namespacesStack.push(new HashMap<>());
/* 289 */       this.dest = doc;
/*     */     }
/*     */     
/*     */     public void head(Node source, int depth) {
/* 293 */       this.namespacesStack.push(new HashMap<>(this.namespacesStack.peek()));
/* 294 */       if (source instanceof Element) {
/* 295 */         Element sourceEl = (Element)source;
/*     */         
/* 297 */         String prefix = updateNamespaces(sourceEl);
/* 298 */         String namespace = (String)((HashMap)this.namespacesStack.peek()).get(prefix);
/* 299 */         String tagName = sourceEl.tagName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 308 */           Element el = (namespace == null && tagName.contains(":")) ? this.doc.createElementNS("", tagName) : this.doc.createElementNS(namespace, tagName);
/* 309 */           copyAttributes((Node)sourceEl, el);
/* 310 */           append(el, (Node)sourceEl);
/* 311 */           this.dest = el;
/* 312 */         } catch (DOMException e) {
/* 313 */           append(this.doc.createTextNode("<" + tagName + ">"), (Node)sourceEl);
/*     */         } 
/* 315 */       } else if (source instanceof TextNode) {
/* 316 */         TextNode sourceText = (TextNode)source;
/* 317 */         Text text = this.doc.createTextNode(sourceText.getWholeText());
/* 318 */         append(text, (Node)sourceText);
/* 319 */       } else if (source instanceof Comment) {
/* 320 */         Comment sourceComment = (Comment)source;
/* 321 */         Comment comment = this.doc.createComment(sourceComment.getData());
/* 322 */         append(comment, (Node)sourceComment);
/* 323 */       } else if (source instanceof DataNode) {
/* 324 */         DataNode sourceData = (DataNode)source;
/* 325 */         Text node = this.doc.createTextNode(sourceData.getWholeData());
/* 326 */         append(node, (Node)sourceData);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void append(Node append, Node source) {
/* 333 */       append.setUserData("jsoupSource", source, null);
/* 334 */       this.dest.appendChild(append);
/*     */     }
/*     */     
/*     */     public void tail(Node source, int depth) {
/* 338 */       if (source instanceof Element && this.dest.getParentNode() instanceof Element) {
/* 339 */         this.dest = this.dest.getParentNode();
/*     */       }
/* 341 */       this.namespacesStack.pop();
/*     */     }
/*     */     
/*     */     private void copyAttributes(Node source, Element el) {
/* 345 */       for (Attribute attribute : source.attributes()) {
/* 346 */         String key = Attribute.getValidKey(attribute.getKey(), Document.OutputSettings.Syntax.xml);
/* 347 */         if (key != null) {
/* 348 */           el.setAttribute(key, attribute.getValue());
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String updateNamespaces(Element el) {
/* 359 */       Attributes attributes = el.attributes();
/* 360 */       for (Attribute attr : attributes) {
/* 361 */         String prefix, key = attr.getKey();
/*     */         
/* 363 */         if (key.equals("xmlns")) {
/* 364 */           prefix = "";
/* 365 */         } else if (key.startsWith("xmlns:")) {
/* 366 */           prefix = key.substring("xmlns:".length());
/*     */         } else {
/*     */           continue;
/*     */         } 
/* 370 */         ((HashMap<String, String>)this.namespacesStack.peek()).put(prefix, attr.getValue());
/*     */       } 
/*     */ 
/*     */       
/* 374 */       int pos = el.tagName().indexOf(':');
/* 375 */       return (pos > 0) ? el.tagName().substring(0, pos) : "";
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\helper\W3CDom.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */