/*     */ package org.jsoup.helper;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.CharArrayReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.IllegalCharsetNameException;
/*     */ import java.util.Locale;
/*     */ import java.util.Random;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import javax.annotation.Nullable;
/*     */ import org.jsoup.UncheckedIOException;
/*     */ import org.jsoup.internal.ConstrainableInputStream;
/*     */ import org.jsoup.internal.Normalizer;
/*     */ import org.jsoup.internal.StringUtil;
/*     */ import org.jsoup.nodes.Comment;
/*     */ import org.jsoup.nodes.Document;
/*     */ import org.jsoup.nodes.Element;
/*     */ import org.jsoup.nodes.Node;
/*     */ import org.jsoup.nodes.XmlDeclaration;
/*     */ import org.jsoup.parser.Parser;
/*     */ import org.jsoup.select.Elements;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DataUtil
/*     */ {
/*  41 */   private static final Pattern charsetPattern = Pattern.compile("(?i)\\bcharset=\\s*(?:[\"'])?([^\\s,;\"']*)");
/*  42 */   public static final Charset UTF_8 = Charset.forName("UTF-8");
/*  43 */   static final String defaultCharsetName = UTF_8.name();
/*     */   private static final int firstReadBufferSize = 5120;
/*     */   static final int bufferSize = 32768;
/*  46 */   private static final char[] mimeBoundaryChars = "-_1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
/*  47 */     .toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int boundaryLength = 32;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document load(File file, @Nullable String charsetName, String baseUri) throws IOException {
/*  64 */     return load(file, charsetName, baseUri, Parser.htmlParser());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document load(File file, @Nullable String charsetName, String baseUri, Parser parser) throws IOException {
/*  82 */     InputStream stream = new FileInputStream(file);
/*  83 */     String name = Normalizer.lowerCase(file.getName());
/*  84 */     if (name.endsWith(".gz") || name.endsWith(".z")) {
/*     */       boolean zipped;
/*     */       
/*     */       try {
/*  88 */         zipped = (stream.read() == 31 && stream.read() == 139);
/*     */       } finally {
/*  90 */         stream.close();
/*     */       } 
/*     */       
/*  93 */       stream = zipped ? new GZIPInputStream(new FileInputStream(file)) : new FileInputStream(file);
/*     */     } 
/*  95 */     return parseInputStream(stream, charsetName, baseUri, parser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document load(InputStream in, @Nullable String charsetName, String baseUri) throws IOException {
/* 107 */     return parseInputStream(in, charsetName, baseUri, Parser.htmlParser());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document load(InputStream in, @Nullable String charsetName, String baseUri, Parser parser) throws IOException {
/* 120 */     return parseInputStream(in, charsetName, baseUri, parser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void crossStreams(InputStream in, OutputStream out) throws IOException {
/* 130 */     byte[] buffer = new byte[32768];
/*     */     int len;
/* 132 */     while ((len = in.read(buffer)) != -1) {
/* 133 */       out.write(buffer, 0, len);
/*     */     }
/*     */   }
/*     */   
/*     */   static Document parseInputStream(@Nullable InputStream input, @Nullable String charsetName, String baseUri, Parser parser) throws IOException {
/* 138 */     if (input == null)
/* 139 */       return new Document(baseUri); 
/* 140 */     ConstrainableInputStream constrainableInputStream = ConstrainableInputStream.wrap(input, 32768, 0);
/*     */     
/* 142 */     Document doc = null;
/*     */ 
/*     */     
/*     */     try {
/* 146 */       constrainableInputStream.mark(32768);
/* 147 */       ByteBuffer firstBytes = readToByteBuffer((InputStream)constrainableInputStream, 5119);
/* 148 */       boolean fullyRead = (constrainableInputStream.read() == -1);
/* 149 */       constrainableInputStream.reset();
/*     */ 
/*     */       
/* 152 */       BomCharset bomCharset = detectCharsetFromBom(firstBytes);
/* 153 */       if (bomCharset != null) {
/* 154 */         charsetName = bomCharset.charset;
/*     */       }
/* 156 */       if (charsetName == null) {
/*     */         try {
/* 158 */           CharBuffer defaultDecoded = UTF_8.decode(firstBytes);
/* 159 */           if (defaultDecoded.hasArray())
/* 160 */           { doc = parser.parseInput(new CharArrayReader(defaultDecoded.array(), defaultDecoded.arrayOffset(), defaultDecoded.limit()), baseUri); }
/*     */           else
/* 162 */           { doc = parser.parseInput(defaultDecoded.toString(), baseUri); } 
/* 163 */         } catch (UncheckedIOException e) {
/* 164 */           throw e.ioException();
/*     */         } 
/*     */ 
/*     */         
/* 168 */         Elements metaElements = doc.select("meta[http-equiv=content-type], meta[charset]");
/* 169 */         String foundCharset = null;
/* 170 */         for (Element meta : metaElements) {
/* 171 */           if (meta.hasAttr("http-equiv"))
/* 172 */             foundCharset = getCharsetFromContentType(meta.attr("content")); 
/* 173 */           if (foundCharset == null && meta.hasAttr("charset"))
/* 174 */             foundCharset = meta.attr("charset"); 
/* 175 */           if (foundCharset != null) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */         
/* 180 */         if (foundCharset == null && doc.childNodeSize() > 0) {
/* 181 */           Node first = doc.childNode(0);
/* 182 */           XmlDeclaration decl = null;
/* 183 */           if (first instanceof XmlDeclaration) {
/* 184 */             decl = (XmlDeclaration)first;
/* 185 */           } else if (first instanceof Comment) {
/* 186 */             Comment comment = (Comment)first;
/* 187 */             if (comment.isXmlDeclaration())
/* 188 */               decl = comment.asXmlDeclaration(); 
/*     */           } 
/* 190 */           if (decl != null && 
/* 191 */             decl.name().equalsIgnoreCase("xml")) {
/* 192 */             foundCharset = decl.attr("encoding");
/*     */           }
/*     */         } 
/* 195 */         foundCharset = validateCharset(foundCharset);
/* 196 */         if (foundCharset != null && !foundCharset.equalsIgnoreCase(defaultCharsetName)) {
/* 197 */           foundCharset = foundCharset.trim().replaceAll("[\"']", "");
/* 198 */           charsetName = foundCharset;
/* 199 */           doc = null;
/* 200 */         } else if (!fullyRead) {
/* 201 */           doc = null;
/*     */         } 
/*     */       } else {
/* 204 */         Validate.notEmpty(charsetName, "Must set charset arg to character set of file to parse. Set to null to attempt to detect from HTML");
/*     */       } 
/* 206 */       if (doc == null) {
/* 207 */         if (charsetName == null)
/* 208 */           charsetName = defaultCharsetName; 
/* 209 */         BufferedReader reader = new BufferedReader(new InputStreamReader((InputStream)constrainableInputStream, charsetName), 32768);
/*     */         try {
/* 211 */           if (bomCharset != null && bomCharset.offset) {
/* 212 */             long skipped = reader.skip(1L);
/* 213 */             Validate.isTrue((skipped == 1L));
/*     */           } 
/*     */           try {
/* 216 */             doc = parser.parseInput(reader, baseUri);
/* 217 */           } catch (UncheckedIOException e) {
/*     */             
/* 219 */             throw e.ioException();
/*     */           } 
/* 221 */           Charset charset = charsetName.equals(defaultCharsetName) ? UTF_8 : Charset.forName(charsetName);
/* 222 */           doc.outputSettings().charset(charset);
/* 223 */           if (!charset.canEncode())
/*     */           {
/* 225 */             doc.charset(UTF_8);
/*     */           }
/*     */         } finally {
/*     */           
/* 229 */           reader.close();
/*     */         } 
/*     */       } 
/*     */     } finally {
/*     */       
/* 234 */       constrainableInputStream.close();
/*     */     } 
/* 236 */     return doc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBuffer readToByteBuffer(InputStream inStream, int maxSize) throws IOException {
/* 248 */     Validate.isTrue((maxSize >= 0), "maxSize must be 0 (unlimited) or larger");
/* 249 */     ConstrainableInputStream input = ConstrainableInputStream.wrap(inStream, 32768, maxSize);
/* 250 */     return input.readToByteBuffer(maxSize);
/*     */   }
/*     */   
/*     */   static ByteBuffer emptyByteBuffer() {
/* 254 */     return ByteBuffer.allocate(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   static String getCharsetFromContentType(@Nullable String contentType) {
/* 264 */     if (contentType == null) return null; 
/* 265 */     Matcher m = charsetPattern.matcher(contentType);
/* 266 */     if (m.find()) {
/* 267 */       String charset = m.group(1).trim();
/* 268 */       charset = charset.replace("charset=", "");
/* 269 */       return validateCharset(charset);
/*     */     } 
/* 271 */     return null;
/*     */   }
/*     */   @Nullable
/*     */   private static String validateCharset(@Nullable String cs) {
/* 275 */     if (cs == null || cs.length() == 0) return null; 
/* 276 */     cs = cs.trim().replaceAll("[\"']", "");
/*     */     try {
/* 278 */       if (Charset.isSupported(cs)) return cs; 
/* 279 */       cs = cs.toUpperCase(Locale.ENGLISH);
/* 280 */       if (Charset.isSupported(cs)) return cs; 
/* 281 */     } catch (IllegalCharsetNameException illegalCharsetNameException) {}
/*     */ 
/*     */     
/* 284 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String mimeBoundary() {
/* 291 */     StringBuilder mime = StringUtil.borrowBuilder();
/* 292 */     Random rand = new Random();
/* 293 */     for (int i = 0; i < 32; i++) {
/* 294 */       mime.append(mimeBoundaryChars[rand.nextInt(mimeBoundaryChars.length)]);
/*     */     }
/* 296 */     return StringUtil.releaseBuilder(mime);
/*     */   }
/*     */   @Nullable
/*     */   private static BomCharset detectCharsetFromBom(ByteBuffer byteData) {
/* 300 */     Buffer buffer = byteData;
/* 301 */     buffer.mark();
/* 302 */     byte[] bom = new byte[4];
/* 303 */     if (byteData.remaining() >= bom.length) {
/* 304 */       byteData.get(bom);
/* 305 */       buffer.rewind();
/*     */     } 
/* 307 */     if ((bom[0] == 0 && bom[1] == 0 && bom[2] == -2 && bom[3] == -1) || (bom[0] == -1 && bom[1] == -2 && bom[2] == 0 && bom[3] == 0))
/*     */     {
/* 309 */       return new BomCharset("UTF-32", false); } 
/* 310 */     if ((bom[0] == -2 && bom[1] == -1) || (bom[0] == -1 && bom[1] == -2))
/*     */     {
/* 312 */       return new BomCharset("UTF-16", false); } 
/* 313 */     if (bom[0] == -17 && bom[1] == -69 && bom[2] == -65) {
/* 314 */       return new BomCharset("UTF-8", true);
/*     */     }
/*     */     
/* 317 */     return null;
/*     */   }
/*     */   
/*     */   private static class BomCharset {
/*     */     private final String charset;
/*     */     private final boolean offset;
/*     */     
/*     */     public BomCharset(String charset, boolean offset) {
/* 325 */       this.charset = charset;
/* 326 */       this.offset = offset;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\mods\fabric-example-mod-1.18\src\main\resources\assets\libs\org\jsoup\jsoup-1.14.3.jar!\org\jsoup\helper\DataUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */